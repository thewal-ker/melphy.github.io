/**
 * scripts/probe-url.mjs — 直接看某个 URL 的加载现场（不等待 __app，用于复现失败）
 *   node scripts/probe-url.mjs <url> [cdpPort]
 */
import { attach, sleep } from './cdp.mjs';

const url = process.argv[2];
const port = process.argv[3] || '9333';
const { probe, logs, close } = await attach({ page: url, port, waitForApp: false });
await sleep(2500);

console.log('URL:', url);
console.log('window.__app 存在:', await probe('!!window.__app'));
console.log('WebGL 画布存在  :', await probe(`!!document.querySelector('canvas')`));
console.log('状态栏         :', JSON.stringify(await probe(`document.getElementById('status').textContent`)));
console.log('读数(点云点数) :', JSON.stringify(await probe(`document.getElementById('vCloudN').textContent`)));
console.log('曲线是否绘制   :', await probe(`(() => {
  const c = document.getElementById('chart');
  const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
  let n = 0; for (let i = 0; i < d.length; i += 4 * 97) if (d[i] + d[i+1] + d[i+2] > 30) n++;
  return n;
})()`));
const bad = logs.filter((l) => l.level === 'error' || l.level === 'exception');
console.log('控制台错误条数 :', bad.length);
for (const b of bad.slice(0, 6)) console.log(`  [${b.level}] ${b.text.slice(0, 220)}`);
await close();
process.exit(0);   // 页面还在跑 rAF，直接退出，避免等 WebSocket 自然关闭
