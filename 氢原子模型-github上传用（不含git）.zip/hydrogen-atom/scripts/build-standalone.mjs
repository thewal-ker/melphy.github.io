/**
 * scripts/build-standalone.mjs — 打包成单文件 HTML
 *   node scripts/build-standalone.mjs [输出名]
 *
 * 为什么需要它：ES 模块在 file:// 协议下会被浏览器的 CORS 策略拦掉
 * （Access to script ... has been blocked by CORS policy），
 * 因此双击 index.html 只能看到静态外壳、看不到模型。
 * 这里把 three.js + 各模块按依赖顺序内联进一个 <script>，双击即可运行。
 *
 * 做法：不引入任何构建工具，只做最小改写——
 *   · 去掉 import 行，改成从命名空间对象解构（每个模块一个 const 命名空间）
 *   · 去掉 export 关键字，令声明落在同一个 IIFE 作用域内，彼此直接可见
 *   · 最后把 window.__app = ... 暴露出来，便于自动化测试
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const OUT = path.join(ROOT, process.argv[2] || '氢原子3D模型-单文件版.html');

/** 按依赖顺序排列；每个模块的源码都在同一个 IIFE 作用域里顺序执行 */
const MODULES = [
  { name: 'three', file: 'vendor/three.module.js' },
  { name: 'physics', file: 'js/physics.js' },
  { name: 'orbital', file: 'js/orbital.js' },
  { name: 'colormap', file: 'js/colormap.js' },
  { name: 'scene', file: 'js/scene.js' },
  { name: 'chart', file: 'js/chart.js' },
  { name: 'main', file: 'js/main.js' },
];

const fileToName = new Map(MODULES.map((m) => [m.file, m.name]));

/** 把相对导入说明符解析成模块名 */
function resolveSpec(spec, fromFile) {
  if (spec.startsWith('.')) {
    const p = path.posix.normalize(path.posix.join(path.posix.dirname(fromFile), spec));
    if (fileToName.has(p)) return fileToName.get(p);
    throw new Error(`无法解析导入 "${spec}"（来自 ${fromFile}）→ ${p}`);
  }
  throw new Error(`不支持的裸导入 "${spec}"（来自 ${fromFile}）`);
}

/**
 * 单条 import 语句的正则。前提（对现代模块化代码都成立）：
 *   · 具名导入列表可以跨行，但不含字符串
 *   · 语句里唯一的字符串字面量就是模块说明符，且必然含 "/"（.js 路径）
 *   · 同一行末尾可有 // 注释
 * 三种形态：import {a,b as c} from '...' / import * as X from '...' / import D from '...'
 */
const IMPORT_RE = /^[ \t]*import[ \t]+(?:(\{[^}]*\})|\*\s*as\s*([A-Za-z_$][\w$]*)|([A-Za-z_$][\w$]*))[ \t]*\r?\n?[ \t]*from[ \t]*['"]([^'"]+)['"][ \t]*;[ \t]*(?:\/\/[^\n]*)?\r?\n/gm;

function toPropList(inner) {
  return inner.split(',').map((s) => s.trim()).filter(Boolean).map((s) => {
    const as = s.split(/\s+as\s+/);
    return as[1] ? `${as[0].trim()}: ${as[1].trim()}` : s;
  }).join(', ');
}

/** 收集模块导出的名字（用于生成命名空间对象） */
function collectExports(src) {
  const names = new Set();
  const decl = /^[ \t]*export\s+(?:async\s+)?(?:function\s*\*?|class|const|let|var)\s+([A-Za-z_$][\w$]*)/gm;
  for (const m of src.matchAll(decl)) names.add(m[1]);
  const list = /^[ \t]*export\s*\{([^}]*)\}/gm;
  for (const m of src.matchAll(list)) {
    for (const part of m[1].split(',')) {
      const t = part.trim();
      if (!t) continue;
      const as = t.split(/\s+as\s+/);
      names.add((as[1] || as[0]).trim());
    }
  }
  if (/^[ \t]*export\s+default\b/m.test(src)) names.add('default');
  return [...names];
}

/** 改写一个模块：记录导出 → 去 import → 去 export 关键字 */
function transform(name, file) {
  let src = fs.readFileSync(path.join(ROOT, file), 'utf8');
  if (/^[ \t]*export\s+default\b/m.test(src)) throw new Error(`${file} 使用了 export default，本打包器未支持`);
  if (/^[ \t]*export\s+\*/m.test(src)) throw new Error(`${file} 使用了 export *，本打包器未支持`);

  const exports = collectExports(src);
  const deps = [];
  const nsImports = [];   // 本模块以 `import * as X` 形式导入的别名

  // 1) import 语句 → 命名空间解构
  src = src.replace(IMPORT_RE, (whole, named, ns, def, spec) => {
    if (whole.includes('/js/') && !spec) throw new Error(`${file} 中 import 解析失败: ${whole.slice(0, 80)}`);
    const mod = resolveSpec(spec, file);
    deps.push(mod);
    if (named) return `const { ${toPropList(named.slice(1, -1))} } = __ns.${mod};\n`;
    if (ns) {
      nsImports.push({ ns, mod });
      return `/* import * as ${ns} ← ${mod}（别名在本模块末尾绑定） */\n`;
    }
    if (def) return `const ${def} = __ns.${mod}.default;\n`;
    return `/* 副作用导入 ${spec} */\n`;
  });

  // 2) 去 export 关键字（保留声明本身）
  src = src.replace(/^([ \t]*)export\s+(?=(?:async\s+)?(?:function|class|const|let|var)\b)/gm, '$1');
  src = src.replace(/^[ \t]*export\s*\{[^}]*\}[ \t]*;?[ \t]*\r?\n/gm, '');

  // 3) 残留的 export 说明有漏网
  const left = src.match(/^[ \t]*export\b/m);
  if (left) throw new Error(`${file} 仍残留 export：${left[0]}`);

  return { name, file, exports, deps, nsImports, code: src };
}

const mods = MODULES.map((m) => transform(m.name, m.file));
for (const m of mods) {
  for (const d of m.deps) {
    if (!mods.some((x) => x.name === d)) throw new Error(`${m.file} 依赖了未列出的模块 ${d}`);
  }
}

/* ------------------------------ 组装 ------------------------------ */

const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
let out = html
  // 注意：String.replace 的替换值里 $&、$'、$` 等是特殊模式（$' = 匹配之后的全部内容）。
  // 这里必须用**函数式替换**，否则 index.html/three.js 中任何 `$'` 都会把文件内容复制进来。
  .replace(/\n?<script type="module" src="js\/main\.js"><\/script>\n?/, () => '\n<!--BUNDLE-->\n')
  .replace(
    /<p>点云中每个点[\s\S]*?<\/p>/,
    () => '<p>点云中每个点 = 用 |ψ<sub>nlm</sub>|² 抽样出的一次“电子出现位置”'
      + '　·　单文件版，双击即可运行</p>'
  );

const parts = [];
parts.push('/* ============================================================');
parts.push('   氢原子 3D 量子模型 — 单文件版（由 scripts/build-standalone.mjs 生成）');
parts.push('   源码：index.html + js/*.js（模块化，需 http 服务）；此处按依赖顺序内联。');
parts.push('   每个模块仍保有独立作用域（IIFE），因此同名声明互不干扰。');
parts.push('   ============================================================ */');
parts.push('(function () {');
parts.push("'use strict';");
parts.push('const __ns = {};');
for (const m of mods) {
  parts.push(`\n/* ======================= ${m.file} ======================= */`);
  parts.push(`__ns['${m.name}'] = (function () {`);
  parts.push(m.code.trimEnd());
  // 命名空间导入（import * as X）在本模块作用域内绑定，与外层无关
  for (const { ns, mod } of m.nsImports) parts.push(`var ${ns} = __ns['${mod}'];`);
  parts.push(`return { ${m.exports.join(', ')} };`);
  parts.push('})();');
}
parts.push('\n})();');

// 关键：内联 <script> 里不允许出现 "</" + 标签名 的序列。
// three.js 的正则字面量中含有 `</body>`、`</html>` 这类片段（HTML 解析器特征嗅探），
// 若不转义，HTML 解析器会把它当成真正的结束标签，从中间截断整个脚本。
// 在 JS 里 `<\/` 与 `</` 完全等价（仅多一个无意义的转义反斜杠），故可安全替换。
const escapeForInlineScript = (js) => js.replace(/<\//g, '<\\/');

const bundle = escapeForInlineScript(parts.join('\n'));
if (!out.includes('<!--BUNDLE-->')) throw new Error('index.html 中找不到 main.js 的 script 标签');
out = out.replace('<!--BUNDLE-->', () => `<script>\n${bundle}\n</script>`);

fs.writeFileSync(OUT, out, 'utf8');
const kb = (n) => (n / 1024).toFixed(0) + ' KB';
console.log(`已生成单文件版: ${path.relative(ROOT, OUT)}  (${kb(Buffer.byteLength(out))})`);
console.log('内联模块顺序: ' + mods.map((m) => `${m.name}(${m.exports.length})`).join(' → '));
console.log('用法: 双击打开即可，无需服务器。');
console.log('校验: node scripts/inspect-bundle.mjs && node scripts/probe-url.mjs "file:///.../本文件"');
