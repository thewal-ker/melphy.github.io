/**
 * scripts/shot-file.mjs — 给"单文件版"在 file:// 下截图，作为可双击运行的证据
 *   node scripts/shot-file.mjs <fileUrl> [cdpPort]
 */
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { attach, sleep } from './cdp.mjs';

const url = process.argv[2];
const port = process.argv[3] || '9333';
const OUT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'renders', 'views');
const { probe, shot, logs, close } = await attach({ page: url, port, shotsDir: OUT });
await sleep(2500);
await probe(`(window.__app.view.setView(0.6, 0.25), 1)`);
await sleep(1200);
console.log('截图:', await shot('F-单文件版-file协议.png'));
console.log('点云点数:', await probe(`document.getElementById('vCloudN').textContent`));
console.log('自检读数:', await probe(`document.getElementById('vCloudMean').textContent`));
console.log('协议:', await probe('location.protocol'));
const bad = logs.filter((l) => l.level === 'error' || l.level === 'exception');
console.log('控制台错误:', bad.length);
for (const b of bad.slice(0, 5)) console.log('  ', b.text.slice(0, 200));
await close();
process.exit(bad.length ? 2 : 0);
