/**
 * scripts/check-sampling.mjs — 点云抽样与截面的统计自检
 *   node scripts/check-sampling.mjs
 * 核心命题：抽样得到的径向分布、角分布是否严格等于解析 |ψ|²。
 * 这是"电子云密度 = 出现概率密度"这一教学主张的可验证依据。
 */
import { sampleCloud, samplePosition, buildSlice, describe } from '../js/orbital.js';
import { radialDensity, meanRadius, realY, radialR, A0_PM } from '../js/physics.js';

let pass = 0, fail = 0;
const ok = (cond, msg, extra = '') => {
  if (cond) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${msg}${extra ? '  ' + extra : ''}`); }
  else { fail++; console.log(`  \x1b[31m✗\x1b[0m ${msg}${extra ? '  ' + extra : ''}`); }
};
const rel = (a, b) => Math.abs(a - b) / Math.max(1e-12, Math.abs(b));

/** n 点 Gauss–Legendre 节点与权重（Newton 迭代 + Legendre 三项递推） */
function gaussLegendre(n) {
  const x = new Float64Array(n), w = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    let z = Math.cos(Math.PI * (i + 0.75) / (n + 0.5));
    let pp = 0;
    for (let it = 0; it < 100; it++) {
      let p0 = 1, p1 = 0;
      for (let k = 0; k < n; k++) {
        const p2 = p1;
        p1 = p0;
        p0 = ((2 * k + 1) * z * p1 - k * p2) / (k + 1);
      }
      pp = n * (z * p0 - p1) / (z * z - 1);
      const dz = p0 / pp;
      z -= dz;
      if (Math.abs(dz) < 1e-16) break;
    }
    x[i] = z;
    w[i] = 2 / ((1 - z * z) * pp * pp);
  }
  return { x, w };
}
const stats = (arr, N) => {
  let s = 0, s2 = 0;
  for (let i = 0; i < N; i++) { s += arr[i]; s2 += arr[i] * arr[i]; }
  const m = s / N;
  return { mean: m, sd: Math.sqrt(Math.max(0, s2 / N - m * m)) };
};

console.log('\n[1] 点云 ⟨r⟩ vs 解析式 (3n²-l(l+1))/2');
for (const [n, l, m] of [[1, 0, 0], [2, 0, 0], [2, 1, 0], [3, 0, 0], [3, 2, 0], [4, 3, 3]]) {
  const t0 = Date.now();
  const c = sampleCloud({ n, l, m, count: 200000, seed: 7 });
  const st = stats(c.radii, c.count);
  const ana = meanRadius(n, l);
  const se = st.sd / Math.sqrt(c.count);
  const sigma = Math.abs(st.mean - ana) / se;
  ok(sigma < 4,
    `${n}${'spdf'[l]}(m=${m}): 抽样 ⟨r⟩ = ${st.mean.toFixed(4)} a0，解析 ${ana} a0，` +
    `偏离 ${sigma.toFixed(2)}σ（MC 标准误 ${se.toFixed(4)}）`,
    `[${Date.now() - t0} ms]`);
}

console.log('\n[2] 径向分布逐 bin 比对解析 D(r)=r²|R|²（3s，含 2 个径向节点）');
{
  const n = 3, l = 0, count = 400000;
  const cloud = sampleCloud({ n, l, m: 0, count, seed: 99 });
  const R = 40, bins = 100, h = new Float64Array(bins);
  for (let i = 0; i < cloud.count; i++) {
    const b = Math.min(bins - 1, Math.floor(cloud.radii[i] / R * bins));
    h[b]++;
  }
  // 用 Poisson 偏差统计量比对；期望值按 bin 精确积分（节点附近中点法会失真）
  let dev = 0, dof = 0, worst = 0;
  for (let b = 0; b < bins; b++) {
    const r0 = b * R / bins, r1 = (b + 1) * R / bins;
    const M = 400;
    let p = 0;
    for (let q = 0; q < M; q++) p += radialDensity(n, l, r0 + (r1 - r0) * (q + 0.5) / M) * (r1 - r0) / M;
    const exp = p * cloud.count;
    if (exp < 30) continue;
    const obs = h[b];
    dev += 2 * (obs * Math.log(obs / exp) - (obs - exp));   // Poisson deviance
    dof++;
    worst = Math.max(worst, Math.abs(obs - exp) / exp);
  }
  const st = stats(cloud.radii, cloud.count);
  ok(rel(st.mean, 13.5) < 0.01, `3s 抽样 ⟨r⟩ = ${st.mean.toFixed(4)} a0（解析 3n²/2 = 13.5）`);
  ok(dev / dof < 1.5,
    `3s 径向直方图 Poisson 偏差/dof = ${(dev / dof).toFixed(3)}（${dof} 个足够计数的 bin，期望 ≈1）`,
    `最大单 bin 偏差 ${(worst * 100).toFixed(1)}%`);
}

console.log('\n[3] 角分布直方图 vs 解析 |Y_lm|²（含 m≠0 的 √2 归一化）');
{
  const cases = [[1, 0], [1, 1], [1, -1], [2, 0], [2, -2], [3, 1]];
  for (const [l, m] of cases) {
    const cloud = sampleCloud({ n: l + 1, l, m, count: 150000, seed: 21 });
    const NB = 40;
    const hMu = new Float64Array(NB), hPhi = new Float64Array(NB);
    for (let i = 0; i < cloud.count; i++) {
      const x = cloud.positions[i * 3], y = cloud.positions[i * 3 + 1], z = cloud.positions[i * 3 + 2];
      const r = Math.hypot(x, y, z);
      const mu = y / r;
      let phi = Math.atan2(z, x); if (phi < 0) phi += 2 * Math.PI;
      hMu[Math.min(NB - 1, Math.floor((mu + 1) / 2 * NB))]++;
      hPhi[Math.min(NB - 1, Math.floor(phi / (2 * Math.PI) * NB))]++;
    }
    // 解析期望：48 点 Gauss–Legendre 求积（不手推权重，避免自身笔误）
    //   dΩ = dμ dφ ；极角边缘分布 = (1/2π)∮|Y|²dφ，方位边缘分布 = (1/2)∫|Y|²dμ
    const { x: gx, w: gw } = gaussLegendre(48);
    const Y2 = (mu, phi) => realY(l, m, mu, phi) ** 2;
    let tot = 0;                                   // ∮|Y|²dΩ = ∫dμ ∫dφ |Y|²
    for (let a = 0; a < 48; a++) {
      for (let c = 0; c < 48; c++) tot += gw[a] * gw[c] * Y2(gx[a], Math.PI * (gx[c] + 1)) * Math.PI;
    }
    const expMu = new Float64Array(NB), expPhi = new Float64Array(NB);
    for (let b2 = 0; b2 < NB; b2++) {
      const mu0 = -1 + 2 * b2 / NB, mu1 = -1 + 2 * (b2 + 1) / NB;
      let acc = 0;
      for (let a = 0; a < 48; a++) {
        const mu = 0.5 * (mu1 - mu0) * gx[a] + 0.5 * (mu0 + mu1);
        let inner = 0;
        for (let c = 0; c < 48; c++) inner += gw[c] * Y2(mu, Math.PI * (gx[c] + 1)) * Math.PI;
        acc += gw[a] * inner / (2 * Math.PI) * (2 * Math.PI);   // 边缘分布需 ∮dφ，故乘回 2π
      }
      expMu[b2] = acc * (mu1 - mu0) / 2;

      const p0 = 2 * Math.PI * b2 / NB, p1 = 2 * Math.PI * (b2 + 1) / NB;
      let acc2 = 0;
      for (let a = 0; a < 48; a++) {
        const phi = 0.5 * (p1 - p0) * gx[a] + 0.5 * (p0 + p1);
        let inner = 0;
        for (let c = 0; c < 48; c++) inner += gw[c] * Y2(gx[c], phi);
        acc2 += gw[a] * inner / 2 * (2 * Math.PI);              // 边缘分布需 ∫dμ 后再乘 2π
      }
      expPhi[b2] = acc2 * (p1 - p0) / (2 * Math.PI);
    }
    const sumMu = expMu.reduce((a, v) => a + v, 0);
    const sumPhi = expPhi.reduce((a, v) => a + v, 0);
    if (Math.abs(tot - 1) > 1e-9 || Math.abs(sumMu - 1) > 1e-9 || Math.abs(sumPhi - 1) > 1e-9) {
      ok(false, `测试自身有误：∮|Y|²dΩ=${tot.toFixed(9)}，Σμ=${sumMu.toFixed(9)}，Σφ=${sumPhi.toFixed(9)}`);
      continue;
    }
    let chi2 = 0, dof = 0;
    for (let b = 0; b < NB; b++) {
      const e = expMu[b] * cloud.count;
      if (e > 40) { chi2 += (hMu[b] - e) ** 2 / e; dof++; }
    }
    let chi2p = 0, dofp = 0;
    for (let b = 0; b < NB; b++) {
      const e = expPhi[b] * cloud.count;
      if (e > 40) { chi2p += (hPhi[b] - e) ** 2 / e; dofp++; }
    }
    ok(chi2 / dof < 2.0 && chi2p / dofp < 2.0,
      `Y_${l},${m}: 极角 χ²/dof = ${(chi2 / dof).toFixed(2)}，方位角 χ²/dof = ${(chi2p / dofp).toFixed(2)}（期望 ≈1）`);
  }
}

console.log('\n[4] 节面结构：|ψ|² 在节面上必须为 0');
{
  const pz = sampleCloud({ n: 2, l: 1, m: 0, count: 150000, seed: 3 });
  let maxAbsMu = 0, wrong = 0;
  for (let i = 0; i < pz.count; i++) {
    const x = pz.positions[i * 3], y = pz.positions[i * 3 + 1], z = pz.positions[i * 3 + 2];
    const r = Math.hypot(x, y, z);
    const mu = y / r;
    if (Math.abs(mu) < Math.abs(maxAbsMu)) maxAbsMu = mu;   // 应趋近 0⁺ 一侧
    if ((y > 0) !== (pz.phase[i] > 0)) wrong++;
  }
  let minAbsMu = Infinity;
  for (let i = 0; i < pz.count; i++) {
    const x = pz.positions[i * 3], y = pz.positions[i * 3 + 1], z = pz.positions[i * 3 + 2];
    const r = Math.hypot(x, y, z);
    minAbsMu = Math.min(minAbsMu, Math.abs(y / r));
  }
  ok(minAbsMu < 0.05, `p_z 节面（xy 平面）最近点 |cosθ| = ${minAbsMu.toFixed(5)}（∝1/√N，节面上无点）`);
  ok(wrong === 0, `p_z 相位与 cosθ 符号完全一致（错配 0 / ${pz.count}）`);

  const dxy = sampleCloud({ n: 3, l: 2, m: -2, count: 150000, seed: 5 });
  // 节面处 |ψ|² ∝ 到节面距离的平方，抽样点会任意接近节面，但**相对典型值**必须极小：
  // 用 median(比值) 归一，避免与浮点最小非零值比较这种无意义的断言。
  const ratios = [];
  for (let i = 0; i < dxy.count; i++) {
    const x = dxy.positions[i * 3], y = dxy.positions[i * 3 + 1], z = dxy.positions[i * 3 + 2];
    const r = Math.hypot(x, y, z);
    ratios.push(Math.min(Math.abs(x), Math.abs(y)) / r);
  }
  ratios.sort((a, b) => a - b);
  const med = ratios[Math.floor(ratios.length / 2)];
  ok(ratios[0] / med < 5e-4,
    `d_xy：到节面的最小相对距离 ${ratios[0].toExponential(1)} vs 典型值 ${med.toFixed(3)}`
    + `（比值 ${(ratios[0] / med).toExponential(1)}，符合 |ψ|²∝d² 的稀疏律）`);
}

console.log('\n[5] 截面场 |ψ|²（xz 平面）逐点比对解析值');
{
  const s = buildSlice({ n: 1, l: 0, m: 0, res: 1200 });
  const idx = (j, i) => s.data[j * s.res + i];
  let best = Infinity, bestV = 0;
  for (let j = 0; j < s.res; j++) {
    for (let i = 0; i < s.res; i++) {
      const x = (2 * (i + 0.5) / s.res - 1) * s.rMax;
      const z = (2 * (j + 0.5) / s.res - 1) * s.rMax;
      const d = Math.abs(Math.hypot(x, z) - 1);
      if (d < best) { best = d; bestV = idx(j, i); }
    }
  }
  const expect = Math.exp(-2) / Math.PI;
  ok(Math.abs(bestV - expect) / expect < 5e-3,
    `1s：r≈a0 处 |ψ|² = ${bestV.toFixed(6)}，解析 e^{-2}/π = ${expect.toFixed(6)}（像素离散 ${best.toFixed(4)} a0）`);

  const p = buildSlice({ n: 2, l: 1, m: 1, res: 600 });   // p_x：节面为平面 x=0
  let maxAtNode = 0, maxOffNode = 0;
  for (let j = 0; j < p.res; j++) {
    for (let i = 0; i < p.res; i++) {
      const x = (2 * (i + 0.5) / p.res - 1) * p.rMax;
      const z = (2 * (j + 0.5) / p.res - 1) * p.rMax;
      const v = p.data[j * p.res + i];
      if (Math.abs(x) < 1e-9) maxAtNode = Math.max(maxAtNode, v);     // 节面 x=0（截面内为竖直线）
      if (Math.abs(x) > 3 && Math.abs(x) < 8) maxOffNode = Math.max(maxOffNode, v);
    }
  }
  ok(maxAtNode <= 1e-12, `p_x 截面：节面 x=0 上最大 |ψ|² = ${maxAtNode.toExponential(2)}（严格 0）`);
  ok(maxOffNode > 1e-3, `p_x 截面：瓣内最大 |ψ|² = ${maxOffNode.toExponential(2)}`);

  // d_z²：P_2(cosθ) = (3cos²θ-1)/2 → 角向节点在 cosθ = ±1/√3（54.7° 圆锥）。
  // 直接与解析 |ψ|² 逐像素比对（比"某角度上最大值"稳健得多）。
  const dz2 = buildSlice({ n: 3, l: 2, m: 0, res: 600, rMax: 12 });
  let worstRel = 0, atNode = 0, atPole = 0, atEq = 0, count = 0;
  for (let j = 0; j < dz2.res; j++) {
    for (let i = 0; i < dz2.res; i++) {
      const x = (2 * (i + 0.5) / dz2.res - 1) * dz2.rMax;
      const z = (2 * (j + 0.5) / dz2.res - 1) * dz2.rMax;
      const rr = Math.hypot(x, z);
      if (rr < 1e-9 || rr > 8) continue;
      const mu = z / rr;
      const exact = (radialR(3, 2, rr, 1) * realY(2, 0, mu, 0)) ** 2;
      const v = dz2.data[j * dz2.res + i];
      worstRel = Math.max(worstRel, Math.abs(v - exact) / Math.max(exact, 1e-12));
      if (Math.abs(mu) < 0.02) atEq = Math.max(atEq, v);
      if (Math.abs(Math.abs(mu) - 1) < 0.02) atPole = Math.max(atPole, v);
      if (Math.abs(Math.abs(mu) - 1 / Math.sqrt(3)) < 0.02) atNode = Math.max(atNode, v);
      count++;
    }
  }
  ok(worstRel < 0.02,
    `d_z² 截面逐像素 vs 解析 |ψ|²：最大相对偏差 ${(worstRel * 100).toFixed(2)}%（${count} 个像素）`);
  ok(atEq > 0 && atPole > 0 && atNode / Math.min(atEq, atPole) < 0.02,
    `d_z² 结构：赤道 ${atEq.toExponential(2)}（理论 |P_2(0)|²=1/4）、极轴 ${atPole.toExponential(2)}（=1）、` +
    `54.7° 节锥上 ${atNode.toExponential(2)}`);
}

console.log('\n[6] 单次"测量"（samplePosition）与解析分布自洽');
{
  const N = 20000;
  let sum = 0;
  for (let i = 0; i < N; i++) sum += samplePosition(2, 1, 0, 1000 + i).r;
  ok(rel(sum / N, 5) < 0.03, `2p 连续 ${N} 次测量平均半径 = ${(sum / N).toFixed(4)} a0（解析 5 a0）`);
  const t0 = Date.now();
  for (let i = 0; i < 2000; i++) samplePosition(3, 2, 1, i);
  ok((Date.now() - t0) < 2000, `2000 次测量耗时 ${Date.now() - t0} ms（抽样表已缓存，可支持交互）`);
}

console.log('\n[7] describe() 汇总量');
{
  const d = describe(3, 2, 0);
  ok(d.label === '3dz²', `标签 = ${d.label}`);
  ok(rel(d.meanRadiusNumeric, 10.5) < 1e-3, `3d ⟨r⟩ = ${d.meanRadiusNumeric.toFixed(4)} a0`);
  ok(Math.abs(d.energyEV - (-1.511743)) < 1e-4, `3d 能量 = ${d.energyEV.toFixed(6)} eV`);
  ok(d.radialNodes === 0 && d.angularNodes === 2, `节点：径向 ${d.radialNodes}，角向 ${d.angularNodes}`);
  ok(rel(d.meanRadius * A0_PM, 555.6) < 0.01, `3d ⟨r⟩ = ${(d.meanRadius * A0_PM).toFixed(1)} pm`);
  const d20 = describe(2, 0, 0);
  ok(d20.nodeRadii.length === 1 && rel(d20.nodeRadii[0], 2) < 1e-6, `2s 径向节点位于 r = ${d20.nodeRadii[0].toFixed(6)} a0`);
}

console.log(`\n结果：${pass} 项通过，${fail} 项失败\n`);
process.exit(fail === 0 ? 0 : 1);
