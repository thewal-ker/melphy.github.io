﻿/**
 * scripts/check-physics.mjs — 波函数数值自检（Node 直接运行，不需要浏览器）
 *   node scripts/check-physics.mjs
 * 与教科书解析式逐点比对，并验证归一化 / ⟨r⟩ / 节点结构。
 */
import {
  radialR, radialDensity, radialProfile, meanRadiusNumeric, meanRadius,
  radialNodes, factorial, realY, angularAmp, angularPeak, energyEV, A0_PM,
} from '../js/physics.js';
let pass = 0, fail = 0;
const ok = (cond, msg, extra = '') => {
  if (cond) { pass++; console.log(`  \x1b[32m✓\x1b[0m ${msg}${extra ? '  ' + extra : ''}`); }
  else { fail++; console.log(`  \x1b[31m✗\x1b[0m ${msg}${extra ? '  ' + extra : ''}`); }
};
const close = (a, b, tol) => Math.abs(a - b) <= tol;

console.log('\n[1] 径向波函数 R_nl(r) 与解析式逐点比对');
const analytic = {
  '1,0': (r) => 2 * Math.exp(-r),
  '2,0': (r) => (1 / (2 * Math.SQRT2)) * (2 - r) * Math.exp(-r / 2),
  '2,1': (r) => (1 / (2 * Math.sqrt(6))) * r * Math.exp(-r / 2),
  '3,0': (r) => (2 / (81 * Math.sqrt(3))) * (27 - 18 * r + 2 * r * r) * Math.exp(-r / 3),
  '3,1': (r) => (4 / (81 * Math.sqrt(6))) * (6 * r - r * r) * Math.exp(-r / 3),
  '3,2': (r) => (4 / (81 * Math.sqrt(30))) * r * r * Math.exp(-r / 3),
};
for (const [key, f] of Object.entries(analytic)) {
  const [n, l] = key.split(',').map(Number);
  let maxRel = 0;
  for (let i = 1; i <= 60; i++) {
    const r = i * 0.35;
    const a = f(r), b = radialR(n, l, r);
    maxRel = Math.max(maxRel, Math.abs(a - b) / Math.max(1e-12, Math.abs(a)));
  }
  ok(maxRel < 1e-12, `R_${n}${l} 最大相对偏差 ${maxRel.toExponential(2)}`, '(< 1e-12)');
}

console.log('\n[2] 归一化 ∫|R_nl|²r²dr = 1（积分上限随 n 扩展至 3n²+8）');
for (const [n, l] of [[1, 0], [2, 0], [3, 2], [4, 0], [5, 3], [6, 5]]) {
  const R = 3 * n * n + 8, M = 400000, dr = R / M;
  let s = 0;
  for (let i = 0; i < M; i++) s += radialDensity(n, l, (i + 0.5) * dr) * dr;
  ok(close(s, 1, 2e-3), `∫|R_${n}${l}|²r²dr = ${s.toFixed(6)}`, `(0 ≤ r ≤ ${R} a0)`);
}

console.log('\n[3] ⟨r⟩ 数值积分 vs 解析式 (3n²-l(l+1))/2');
for (const [n, l] of [[1, 0], [2, 0], [2, 1], [3, 2], [4, 3], [6, 0]]) {
  const p = radialProfile(n, l, { samples: 200000 });
  const num = meanRadiusNumeric(p), ana = meanRadius(n, l);
  ok(close(num, ana, 5e-3), `n=${n} l=${l}: 数值 ${num.toFixed(6)} a0  vs 解析 ${ana} a0`);}

console.log('\n[4] 最概然半径与 95% 半径');
// 1s: F(r) = 1 - e^{-2r}(1 + 2r + 2r²)，解 F = 0.95 得 r = 3.1471 a0
const solve15 = (() => {
  let lo = 0, hi = 12;
  for (let i = 0; i < 200; i++) {
    const m = 0.5 * (lo + hi);
    const F = 1 - Math.exp(-2 * m) * (1 + 2 * m + 2 * m * m);
    if (F > 0.95) hi = m; else lo = m;
  }
  return 0.5 * (lo + hi);
})();
const p10 = radialProfile(1, 0, { samples: 100000 });
ok(close(p10.rMostProbable, 1.0, 1e-4), `1s 最概然半径 = ${p10.rMostProbable.toFixed(6)} a0（严格等于 a0）`);
ok(close(p10.r95, solve15, 5e-4), `1s 的 R95 = ${p10.r95.toFixed(4)} a0（解析解 ${solve15.toFixed(4)} a0）`);
const p20 = radialProfile(2, 0, { samples: 200000 });
ok(close(p20.rMostProbable, (3 + Math.sqrt(5)), 5e-3),
  `2s 最概然半径 = ${p20.rMostProbable.toFixed(4)} a0（解析 3+√5 = ${(3 + Math.sqrt(5)).toFixed(4)}）`);

console.log('\n[5] 径向节点：个数 = n-l-1，位置满足 R_nl = 0');
for (const [n, l] of [[2, 0], [3, 0], [3, 1], [4, 2], [5, 0]]) {
  const roots = radialNodes(n, l);
  const cnt = roots.length === n - l - 1;
  const val = roots.every((r) => Math.abs(radialR(n, l, r)) < 1e-9);
  ok(cnt && val, `n=${n} l=${l}: ${roots.length} 个节点 [${roots.map((r) => r.toFixed(3)).join(', ')}] a0`);
}

console.log('\n[6] 角向：∫|Y_lm|²dΩ = 1，峰值扫描');
for (const [l, m] of [[0, 0], [1, 0], [1, 1], [1, -1], [2, 0], [2, 2], [2, -1], [3, 1], [3, 3], [4, -4]]) {
  const Nth = 900, Nph = 900;
  let s = 0;
  const dmu = 2 / Nth, dph = 2 * Math.PI / Nph;
  for (let i = 0; i < Nth; i++) {
    const mu = -1 + (i + 0.5) * dmu;
    for (let j = 0; j < Nph; j++) s += realY(l, m, mu, (j + 0.5) * dph) ** 2 * dmu * dph;
  }
  ok(close(s, 1, 3e-3), `Y_${l},${m}: ∫|Y|²dΩ = ${s.toFixed(5)}`);
}
for (const [l, m] of [[2, 2], [3, 1], [2, -2], [4, 3]]) {
  const peak = angularPeak(l, m);
  const scale = m === 0 ? 1 : 2; // cos²(mφ) 峰值 = 1，实数球谐上界 = scale·A²
  let num = 0;
  for (let i = 0; i <= 4000; i++) {
    const mu = -1 + 2 * i / 4000;
    for (let j = 0; j < 24; j++) {
      const v = scale * angularAmp(l, m, mu) ** 2; // 与拒绝法使用的包络一致
      if (v > num) num = v;
    }
  }
  ok(peak >= num && close(peak, num, 1e-5),
    `Y_${l},${m} 峰值包络 ${peak.toFixed(8)} ≥ 网格最大值 ${num.toFixed(8)}（拒绝法上界）`);
}

console.log('\n[7] 能级与常数');
ok(close(energyEV(1), -13.605693122994, 1e-9), `E_1 = ${energyEV(1).toFixed(9)} eV`);
ok(close(energyEV(2), -3.4014232807, 1e-9), `E_2 = ${energyEV(2).toFixed(9)} eV`);
ok(close(A0_PM, 52.9177210544, 1e-9), `a0 = ${A0_PM} pm（H 的 1s ⟨r⟩ = ${(1.5 * A0_PM).toFixed(3)} pm，文献 79.4 pm）`);
ok(factorial(10) === 3628800, `10! = ${factorial(10)}`);

console.log(`\n结果：${pass} 项通过，${fail} 项失败\n`);
process.exit(fail === 0 ? 0 : 1);

