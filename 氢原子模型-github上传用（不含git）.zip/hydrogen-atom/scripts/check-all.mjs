/**
 * scripts/check-all.mjs — 一次性跑完全部自检
 *   node scripts/check-all.mjs        数学与抽样自检（不需要浏览器/服务器）
 */
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = path.dirname(fileURLToPath(import.meta.url));
const scripts = ['check-physics.mjs', 'check-sampling.mjs'];
let failed = 0;
for (const s of scripts) {
  console.log(`\n${'='.repeat(72)}\n# ${s}\n${'='.repeat(72)}`);
  const r = spawnSync(process.execPath, [path.join(dir, s)], { stdio: 'inherit' });
  if (r.status !== 0) failed++;
}
console.log(`\n${'='.repeat(72)}`);
console.log(failed ? `✗ ${failed} 个自检脚本有失败项` : '✓ 全部自检通过');
process.exit(failed ? 1 : 0);
