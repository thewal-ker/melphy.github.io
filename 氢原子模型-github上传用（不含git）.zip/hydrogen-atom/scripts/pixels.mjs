/**
 * scripts/pixels.mjs — 统计渲染出的 PNG 里点云的亮度分布
 *   node scripts/pixels.mjs renders/shot-1s.png [renders/shot-3pz-phase.png ...]
 * 不依赖任何图像库：自己解 PNG（zlib + 反滤波），只用于客观比较不同量子态的画面亮度。
 */
import fs from 'node:fs';
import zlib from 'node:zlib';

export function decodePNG(buf) {
  if (buf.readUInt32BE(0) !== 0x89504e47) throw new Error('不是 PNG');
  let pos = 8, w = 0, h = 0, bitDepth = 8, colorType = 6;
  const idat = [];
  while (pos < buf.length) {
    const len = buf.readUInt32BE(pos);
    const type = buf.toString('ascii', pos + 4, pos + 8);
    const data = buf.subarray(pos + 8, pos + 8 + len);
    if (type === 'IHDR') {
      w = data.readUInt32BE(0); h = data.readUInt32BE(4);
      bitDepth = data[8]; colorType = data[9];
    } else if (type === 'IDAT') idat.push(data);
    else if (type === 'IEND') break;
    pos += 12 + len;
  }
  if (bitDepth !== 8) throw new Error('仅支持 8 位');
  const ch = colorType === 6 ? 4 : colorType === 2 ? 3 : 1;
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = w * ch;
  const out = Buffer.alloc(h * stride);
  let rp = 0;
  for (let y = 0; y < h; y++) {
    const filter = raw[rp++];
    const line = raw.subarray(rp, rp + stride); rp += stride;
    const cur = out.subarray(y * stride, (y + 1) * stride);
    const prev = y > 0 ? out.subarray((y - 1) * stride, y * stride) : null;
    for (let i = 0; i < stride; i++) {
      const a = i >= ch ? cur[i - ch] : 0;
      const b = prev ? prev[i] : 0;
      const c = (prev && i >= ch) ? prev[i - ch] : 0;
      let v = line[i];
      if (filter === 1) v += a;
      else if (filter === 2) v += b;
      else if (filter === 3) v += (a + b) >> 1;
      else if (filter === 4) {
        const p = a + b - c;
        const pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
        v += (pa <= pb && pa <= pc) ? a : (pb <= pc ? b : c);
      }
      cur[i] = v & 0xff;
    }
  }
  return { w, h, ch, data: out };
}

/** 统计画布中心区域的点云亮度（避开左右面板） */
export function statsOf(img, xLo = 0.24, xHi = 0.78) {
  const { w, h, ch, data } = img;
  let sum = 0, n = 0, bright = 0, mid = 0, sat = 0, maxV = 0;
  for (let y = 0; y < h; y++) {
    for (let x = Math.floor(w * xLo); x < Math.floor(w * xHi); x++) {
      const i = (y * w + x) * ch;
      const v = Math.max(data[i], data[i + 1], data[i + 2]);
      n++; sum += v;
      if (v > 200) bright++;
      else if (v > 60) mid++;
      if (data[i] > 245 && data[i + 1] > 245 && data[i + 2] > 245) sat++;
      if (v > maxV) maxV = v;
    }
  }
  return {
    n, mean: sum / n, max: maxV,
    over200: bright / n * 100, over60: mid / n * 100, white: sat / n * 100,
  };
}

if (import.meta.url === `file:///${process.argv[1]?.replace(/\\/g, '/')}`) {
  for (const file of process.argv.slice(2)) {
    const s = statsOf(decodePNG(fs.readFileSync(file)));
    console.log(`${file.split(/[\\/]/).pop().padEnd(24)} 均值=${s.mean.toFixed(1).padStart(6)}  `
      + `峰值=${String(s.max).padStart(3)}  >200:${s.over200.toFixed(2).padStart(6)}%  `
      + `>60:${s.over60.toFixed(2).padStart(6)}%  纯白:${s.white.toFixed(2).padStart(6)}%`);
  }
}
