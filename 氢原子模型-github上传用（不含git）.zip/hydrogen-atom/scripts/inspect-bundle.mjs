/**
 * scripts/inspect-bundle.mjs — 检查单文件版的内联脚本是否健康
 *   node scripts/inspect-bundle.mjs [文件名]
 * 关注三件事：
 *   1) 内联脚本长度是否完整（结尾应是 IIFE 收尾）
 *   2) 是否残留 import / export（说明改写漏了）
 *   3) 语法是否通过（用 node --check 校验临时文件）
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const file = path.join(ROOT, process.argv[2] || '氢原子3D模型-单文件版.html');
const html = fs.readFileSync(file, 'utf8');

const open = html.indexOf('<script>');
const close = html.lastIndexOf('</script>');
if (open < 0 || close < 0) { console.log('✗ 找不到内联 script'); process.exit(1); }
const body = html.slice(open + '<script>'.length, close);

console.log(`文件          : ${path.basename(file)}  (${(html.length / 1024).toFixed(0)} KB)`);
console.log(`内联脚本      : ${body.length} 字符, ${body.split('\n').length} 行`);
console.log(`结尾 80 字符  : ${JSON.stringify(body.slice(-80))}`);
console.log(`残留 import   : ${(body.match(/^\s*import\b/gm) || []).length} 行`);
console.log(`残留 export   : ${(body.match(/^\s*export\b/gm) || []).length} 行`);

const tmp = path.join(ROOT, 'renders', '_bundle_check.js');
fs.writeFileSync(tmp, body, 'utf8');
const r = spawnSync(process.execPath, ['--check', tmp], { encoding: 'utf8' });
if (r.status === 0) {
  console.log('语法检查      : ✓ 通过');
} else {
  console.log('语法检查      : ✗ 失败');
  console.log((r.stderr || '').split('\n').slice(0, 8).join('\n'));
}
process.exit(r.status === 0 ? 0 : 1);
