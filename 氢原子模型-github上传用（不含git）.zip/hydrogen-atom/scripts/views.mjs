/**
 * scripts/views.mjs — 抓取若干教学视角的参考图（同时验证截面/相位/测量模式）
 *   node scripts/views.mjs [pageUrl] [cdpPort]
 */
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { attach, sleep } from './cdp.mjs';

const PAGE = process.argv[2] || 'http://127.0.0.1:5178/';
const PORT = process.argv[3] || '9333';
const OUT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'renders', 'views');
const { probe, shot, logs, close } = await attach({ page: PAGE, port: PORT, shotsDir: OUT });

const setup = (js) => probe(`(() => { const app = window.__app; ${js}; return 1; })()`);

// 0. 封面图：1s 基态
await setup(`
  document.getElementById('chkSpin').checked = false;
  document.getElementById('chkSpin').dispatchEvent(new Event('change'));
  app.load(1, 0, 0);
`);
await sleep(3500);
await setup(`app.view.setView(0.6, 0.25);`);
await sleep(1600);
await shot('00-cover-1s.png');

// 1. 3d_z² + 截面，正对截面方向（从 +y 侧俯视 xz 平面，截面铺满视野）
await setup(`
  document.getElementById('chkSlice').checked = true;
  document.getElementById('chkSlice').dispatchEvent(new Event('change'));
  document.getElementById('chkSpin').checked = false;
  document.getElementById('chkSpin').dispatchEvent(new Event('change'));
  app.load(3, 2, 0);
`);
await sleep(3500);
await setup(`app.view.setView(0, 1.45); app.view.targetDist = 430;`);
await sleep(1600);
await shot('A-3dz2-slice-face-on.png');
console.log('A 完成:', await probe(`document.getElementById('stateTag').textContent`));

// 2. 3p_z 相位着色（正视图，能看清上下两个反相波瓣）
await setup(`
  document.getElementById('chkSlice').checked = false;
  document.getElementById('chkSlice').dispatchEvent(new Event('change'));
  document.getElementById('chkPhase').checked = true;
  document.getElementById('chkPhase').dispatchEvent(new Event('change'));
  app.load(3, 1, 0);
`);
await sleep(3500);
await setup(`app.view.setView(0.35, 0.15);`);
await sleep(1600);
await shot('B-3pz-phase.png');

// 3. 3d_xy（m=-2）：xy 平面内的四叶草，从极点方向看
await setup(`app.load(3, 2, -2);`);
await sleep(3500);
await setup(`app.view.setView(0.4, 1.35);`);
await sleep(1600);
await shot('C-3dxy-pole-view.png');

// 4. 4f_z³ + 测量标记
await setup(`
  document.getElementById('chkPhase').checked = false;
  document.getElementById('chkPhase').dispatchEvent(new Event('change'));
  app.load(4, 3, 0);
`);
await sleep(3500);
await probe(`(() => { const a = window.__app; for (let i = 0; i < 3; i++) a.measureRandom(); return 1; })()`);
await sleep(600);
await shot('D-4fz3-measure.png');
console.log('测量读数:', await probe(`document.getElementById('measureReadout').textContent`));

// 5. 6h（n=6, l=5）：高角动量极限
await setup(`app.load(6, 5, 0);`);
await sleep(4000);
await setup(`app.view.setView(0.9, 0.5);`);
await sleep(1600);
await shot('E-6h.png');
console.log('6h:', JSON.stringify(await probe(`({
  label: window.__app.info.label, r95: +window.__app.info.r95.toFixed(1),
  mean: document.getElementById('vCloudMean').textContent,
  alpha: +window.__app.view.material.uniforms.uAlpha.value.toFixed(2),
})`)));

const bad = logs.filter((x) => x.level === 'error' || x.level === 'exception');
console.log(`控制台错误: ${bad.length}`);
for (const b of bad) console.log(' ', b.text.slice(0, 300));
await close();
