/**
 * scripts/brightness.mjs — 曝光系数扫描
 *   node scripts/brightness.mjs [pageUrl] [cdpPort]
 * 对若干代表性量子态，扫描点云整体亮度系数 k，统计画面亮度，找出让不同
 * 量子态落在同一量级的 k（目标：过曝像素占比 1%~4%，均值 20~45）。
 * 结果用于确定 main.js 中 alpha = k·(r_med/12)^p 的系数。
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { attach, sleep } from './cdp.mjs';
import { statsOf, decodePNG } from './pixels.mjs';

const PAGE = process.argv[2] || 'http://127.0.0.1:5178/';
const PORT = process.argv[3] || '9333';
const OUT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'renders', 'sweep');
fs.mkdirSync(OUT, { recursive: true });

const ORBITALS = [[1, 0, 0], [2, 1, 0], [3, 0, 0], [3, 1, 0], [3, 2, 0], [4, 3, 0]];
const KS = [0.4, 0.7, 1.0, 1.4, 1.9, 2.6, 3.4];

const { probe, shot, logs, close } = await attach({ page: PAGE, port: PORT, shotsDir: OUT });

console.log('轨道        中位半径(世界单位)   ' + KS.map((k) => `k=${k}`.padStart(12)).join(''));
const rows = [];
for (const [n, l, m] of ORBITALS) {
  await probe(`(async () => { window.__app.load(${n},${l},${m}); await new Promise(r=>setTimeout(r,1600)); return 1; })()`);
  const meta = await probe(`({ label: window.__app.info.label, rmed: +window.__app.medianR.toFixed(2) })`);
  const cells = [];
  for (const k of KS) {
    await probe(`(window.__app.view.setAlpha(${k}), 1)`);
    await sleep(320);
    const file = await shot('tmp.png');
    cells.push(statsOf(decodePNG(fs.readFileSync(file))));
    fs.renameSync(file, path.join(OUT, `${meta.label}_k${k}.png`));
  }
  rows.push({ ...meta, cells });
  console.log(meta.label.padEnd(10) + String(meta.rmed).padStart(8) + '        '
    + cells.map((c) => `${c.mean.toFixed(0)}/${c.over200.toFixed(1)}%`.padStart(12)).join(''));
}

// 候选补偿公式（alpha = A·(r_med/13)^p）横向对比
const CANDIDATES = [
  ['不平滑 A=1.0 p=0.0', 0, 1.0],
  ['弱     A=1.15 p=0.30', 0.30, 1.15],
  ['中     A=1.15 p=0.45', 0.45, 1.15],
  ['强     A=1.3 p=0.6', 0.60, 1.30],
];
console.log('\n候选补偿公式对比（数值为 均值/过曝%）');
const header = '轨道      r_med  ' + CANDIDATES.map((c) => c[0].padStart(18)).join('');
console.log(header);
const table = [];
for (const [n, l, m] of ORBITALS) {
  await probe(`(async () => { window.__app.load(${n},${l},${m}); await new Promise(r=>setTimeout(r,1600)); return 1; })()`);
  const meta = await probe(`({ label: window.__app.info.label, rmed: +window.__app.medianR.toFixed(2) })`);
  const cells = [];
  for (const [, p, A] of CANDIDATES) {
    const k = Math.max(0.15, Math.min(3.2, A * Math.pow(meta.rmed / 13, p)));
    await probe(`(window.__app.view.setAlpha(${k}), 1)`);
    await sleep(320);
    const file = await shot('tmp.png');
    const s = statsOf(decodePNG(fs.readFileSync(file)));
    cells.push(s);
    fs.renameSync(file, path.join(OUT, `cand_${meta.label}_${p}_${A}.png`));
  }
  table.push({ ...meta, cells });
  console.log(meta.label.padEnd(9) + String(meta.rmed).padStart(6) + '  '
    + cells.map((c) => `${c.mean.toFixed(0)}/${c.over200.toFixed(1)}%`.padStart(18)).join(''));
}

console.log('\n各候选的离散程度（过曝% 的极差 / 均值极差，越小越均匀）：');
CANDIDATES.forEach(([name], i) => {
  const over = table.map((r) => r.cells[i].over200);
  const mean = table.map((r) => r.cells[i].mean);
  console.log(`  ${name.padEnd(18)} 过曝 ${Math.min(...over).toFixed(1)}%~${Math.max(...over).toFixed(1)}%`
    + `  均值 ${Math.min(...mean).toFixed(0)}~${Math.max(...mean).toFixed(0)}`);
});

const bad = logs.filter((x) => x.level === 'error' || x.level === 'exception');
if (bad.length) { console.log('\n控制台错误:'); for (const b of bad) console.log(' ', b.text.slice(0, 300)); }
await close();
