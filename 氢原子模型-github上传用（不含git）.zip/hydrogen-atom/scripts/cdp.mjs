/**
 * scripts/cdp.mjs — 极简 Chrome DevTools Protocol 客户端（供 smoke.mjs / brightness.mjs 复用）
 */
import fs from 'node:fs';
import path from 'node:path';

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export class CDP {
  constructor(ws) {
    this.ws = ws;
    this.id = 0;
    this.pending = new Map();
    this.events = [];
    this.listeners = [];
    ws.addEventListener('message', (ev) => {
      const msg = JSON.parse(ev.data);
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        msg.error ? reject(new Error(`${msg.error.message} ${JSON.stringify(msg.error.data ?? '')}`)) : resolve(msg.result);
      } else if (msg.method) {
        this.events.push(msg);
        for (const fn of this.listeners) fn(msg);
      }
    });
  }
  send(method, params = {}, sessionId) {
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params, sessionId }));
      setTimeout(() => {
        if (this.pending.has(id)) { this.pending.delete(id); reject(new Error(`timeout: ${method}`)); }
      }, 180000);
    });
  }
}

/**
 * 连接无头 Chrome，打开页面并等页面内 window.__app 就绪。
 * @returns {{cdp, S, probe, shot, logs, shotsDir, close}}
 */
export async function attach({ page, port = '9333', width = 1600, height = 900, shotsDir = null, waitForApp = true }) {
  const res = await fetch(`http://127.0.0.1:${port}/json/version`);
  const { webSocketDebuggerUrl } = await res.json();
  const ws = new WebSocket(webSocketDebuggerUrl);
  await new Promise((r, j) => { ws.addEventListener('open', r); ws.addEventListener('error', j); });
  const cdp = new CDP(ws);

  const logs = [];
  cdp.listeners.push((msg) => {
    const p = msg.params || {};
    if (msg.method === 'Runtime.consoleAPICalled') {
      logs.push({ level: p.type, text: (p.args || []).map((a) => a.value ?? a.description ?? a.type).join(' ') });
    } else if (msg.method === 'Runtime.exceptionThrown') {
      const d = p.exceptionDetails || {};
      logs.push({ level: 'exception', text: d.exception?.description || d.text || 'unknown' });
    } else if (msg.method === 'Log.entryAdded') {
      logs.push({ level: p.entry.level, text: `[${p.entry.source}] ${p.entry.text}` });
    }
  });

  const { targetId } = await cdp.send('Target.createTarget', { url: 'about:blank' });
  const { sessionId } = await cdp.send('Target.attachToTarget', { targetId, flatten: true });
  const S = (m, p) => cdp.send(m, p, sessionId);

  await S('Runtime.enable');
  await S('Log.enable');
  await S('Page.enable');
  await S('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: 1, mobile: false });
  await S('Page.navigate', { url: page });
  await sleep(4000);

  const probe = async (expr) => {
    const r = await S('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
    return r.result.value;
  };

  // 等 window.__app 出现（模块版被 CORS 拦下时可关掉，用于观察失败现场）
  if (waitForApp) {
    for (let i = 0; i < 60; i++) {
      if (await probe('!!window.__app')) break;
      await sleep(500);
    }
  }

  const dir = shotsDir || path.resolve(process.cwd(), 'renders');
  fs.mkdirSync(dir, { recursive: true });
  const shot = async (name) => {
    const r = await S('Page.captureScreenshot', { format: 'png' });
    const file = path.join(dir, name);
    fs.writeFileSync(file, Buffer.from(r.data, 'base64'));
    return file;
  };

  return { cdp, S, probe, shot, logs, close: async () => { await S('Page.close').catch(() => {}); ws.close(); } };
}
