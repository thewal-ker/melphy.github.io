/**
 * scripts/smoke.mjs — 用 Chrome DevTools Protocol 真跑一遍页面
 *   node scripts/smoke.mjs [pageUrl] [cdpPort]
 * 采集控制台错误 / 未捕获异常 / 着色器编译错误，导出截图，并模拟两次交互。
 * 需要先启动 server.mjs 与带 --remote-debugging-port 的 Chrome。
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const PAGE = process.argv[2] || 'http://127.0.0.1:5178/';
const PORT = process.argv[3] || '9333';
const OUT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'renders');
fs.mkdirSync(OUT, { recursive: true });

class CDP {
  constructor(ws) {
    this.ws = ws;
    this.id = 0;
    this.pending = new Map();
    this.events = [];
    this.listeners = [];
    ws.addEventListener('message', (ev) => {
      const msg = JSON.parse(ev.data);
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        msg.error ? reject(new Error(`${msg.error.message} (${JSON.stringify(msg.error.data ?? '')})`)) : resolve(msg.result);
      } else if (msg.method) {
        this.events.push(msg);
        for (const fn of this.listeners) fn(msg);
      }
    });
  }
  send(method, params = {}, sessionId) {
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params, sessionId }));
      setTimeout(() => {
        if (this.pending.has(id)) { this.pending.delete(id); reject(new Error(`timeout: ${method}`)); }
      }, 120000);
    });
  }
  on(fn) { this.listeners.push(fn); }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const res = await fetch(`http://127.0.0.1:${PORT}/json/version`);
const { webSocketDebuggerUrl } = await res.json();
const ws = new WebSocket(webSocketDebuggerUrl);
await new Promise((r, j) => { ws.addEventListener('open', r); ws.addEventListener('error', j); });
const cdp = new CDP(ws);

const logs = [];
cdp.on((msg) => {
  const p = msg.params || {};
  if (msg.method === 'Runtime.consoleAPICalled') {
    const text = (p.args || []).map((a) => a.value ?? a.description ?? a.type).join(' ');
    logs.push({ level: p.type, text });
  } else if (msg.method === 'Runtime.exceptionThrown') {
    const d = p.exceptionDetails || {};
    logs.push({ level: 'exception', text: d.exception?.description || d.text || 'unknown' });
  } else if (msg.method === 'Log.entryAdded') {
    logs.push({ level: p.entry.level, text: `[${p.entry.source}] ${p.entry.text}` });
  }
});

const { targetId } = await cdp.send('Target.createTarget', { url: 'about:blank' });
const { sessionId } = await cdp.send('Target.attachToTarget', { targetId, flatten: true });
const S = (m, p) => cdp.send(m, p, sessionId);

await S('Runtime.enable');
await S('Log.enable');
await S('Page.enable');
await S('Emulation.setDeviceMetricsOverride', { width: 1600, height: 900, deviceScaleFactor: 1, mobile: false });
await S('Page.navigate', { url: PAGE });
await sleep(6000);

// 页面内诊断
const probe = async (expr, label) => {
  const r = await S('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) return { error: r.exceptionDetails.exception?.description || r.exceptionDetails.text };
  return r.result.value;
};

const diag = await probe(`(() => {
  const app = window.__app;
  if (!app) return { app: false };
  const gl = app.view.renderer.getContext();
  return {
    app: true,
    webgl: gl.getParameter(gl.VERSION) + ' | ' + gl.getParameter(gl.RENDERER),
    state: app.state,
    label: app.info && app.info.label,
    pointsDrawn: app.cloud && app.cloud.count,
    programOk: !app.view.material || app.view.material.program === undefined
      ? 'n/a' : !!app.view.material.program,
    cameraDist: +app.view.dist.toFixed(1),
    appear: +app.view.appear.toFixed(2),
    hud: {
      stateTag: document.getElementById('stateTag').textContent,
      vQN: document.getElementById('vQN').textContent,
      vE: document.getElementById('vE').textContent,
      vRmp: document.getElementById('vRmp').textContent,
      vRmean: document.getElementById('vRmean').textContent,
      vCloudMean: document.getElementById('vCloudMean').textContent,
      vGenMs: document.getElementById('vGenMs').textContent,
      selfCheck: document.getElementById('selfCheck').textContent.slice(0, 60),
    },
    chartPainted: (() => {
      const c = document.getElementById('chart');
      const ctx = c.getContext('2d');
      const d = ctx.getImageData(0, 0, c.width, c.height).data;
      let nonEmpty = 0;
      for (let i = 0; i < d.length; i += 4 * 97) if (d[i] + d[i+1] + d[i+2] > 30) nonEmpty++;
      return nonEmpty;
    })(),
  };
})()`);
console.log('--- 页面诊断 ---');
console.log(JSON.stringify(diag, null, 2));

// 各轨道的取景量：点云半径分位 vs 解析 r95
const framing = await probe(`(async () => {
  const app = window.__app;
  const rows = [];
  for (const [n, l, m] of [[1,0,0],[2,1,0],[3,0,0],[3,1,0],[3,2,0],[4,3,0],[6,5,0]]) {
    app.load(n, l, m);
    await new Promise((r) => setTimeout(r, 1500));
    const rs = Float32Array.from(app.cloud.radii).sort();
    const q = (p) => rs[Math.floor(rs.length * p)] / app.viewScale;
    rows.push({
      orb: app.info.label,
      r95: +app.info.r95.toFixed(2),
      p50: +q(0.5).toFixed(2), p80: +q(0.8).toFixed(2), p90: +q(0.9).toFixed(2),
      viewScale: +app.viewScale.toFixed(3),
      camDist: +app.view.dist.toFixed(0),
    });
  }
  app.load(1, 0, 0);
  await new Promise((r) => setTimeout(r, 1500));
  return rows;
})()`);
console.log('--- 半径分位（单位 a₀）与取景 ---');
for (const r of framing) console.log(JSON.stringify(r));

const shot = async (name) => {
  const r = await S('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  const file = path.join(OUT, name);
  fs.writeFileSync(file, Buffer.from(r.data, 'base64'));
  console.log(`截图: ${name}  ${(fs.statSync(file).size / 1024).toFixed(0)} KB`);
};

await shot('shot-1s.png');

// 交互 1：切到 3d_z² 并打开截面
await probe(`(() => {
  const app = window.__app;
  document.getElementById('chkSlice').checked = true;
  document.getElementById('chkSlice').dispatchEvent(new Event('change'));
  app.load(3, 2, 0);
  return 1;
})()`, 'switch 3dz2');
await sleep(4500);
console.log('3d_z² 状态:', JSON.stringify(await probe(`({
  label: window.__app.info.label,
  r95: +window.__app.info.r95.toFixed(2),
  cloudMean: document.getElementById('vCloudMean').textContent,
  sliceVisible: window.__app.view.slice.visible,
})`)));
await shot('shot-3dz2-slice.png');

// 交互 2：重新抽样（淡出→抽样→淡入）
await probe(`(window.__app.resample(), 1)`);
await sleep(4500);
console.log('重采样后:', JSON.stringify(await probe(`({
  points: window.__app.cloud.count,
  appear: +window.__app.view.appear.toFixed(2),
  pending: window.__app.pendingResample,
})`)));

// 交互 3：p 轨道 + 相位着色
await probe(`(() => {
  const app = window.__app;
  document.getElementById('chkSlice').checked = false;
  document.getElementById('chkSlice').dispatchEvent(new Event('change'));
  document.getElementById('chkPhase').checked = true;
  document.getElementById('chkPhase').dispatchEvent(new Event('change'));
  app.load(3, 1, 0);
  return 1;
})()`);
await sleep(4500);
console.log('3p_z 相位态:', JSON.stringify(await probe(`({
  label: window.__app.info.label,
  phaseMix: window.__app.view.material.uniforms.uPhaseMix.value,
})`)));
await shot('shot-3pz-phase.png');

// 交互 4：点击测量（用页面内 API 直接做一次随机测量）
console.log('测量:', JSON.stringify(await probe(`(() => {
  window.__app.measureRandom();
  return document.getElementById('measureReadout').textContent;
})()`)));

console.log('\n--- 控制台输出 ---');
const bad = logs.filter((l) => ['error', 'exception'].includes(l.level));
if (!logs.length) console.log('(无输出)');
for (const l of logs.slice(0, 40)) console.log(`[${l.level}] ${l.text.slice(0, 400)}`);
console.log(`\n错误/异常条数: ${bad.length}`);

await S('Page.close').catch(() => {});
ws.close();
process.exit(bad.length ? 2 : 0);
