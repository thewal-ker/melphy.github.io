/**
 * physics.js — 类氢原子（H, Z=1）波函数的数值实现
 * ---------------------------------------------------------------------------
 * 约定：原子单位（a0 = 1），玻尔半径 a0 = 52.9177210544 pm。
 *   ψ_nlm(r,θ,φ) = R_nl(r) · Y_lm(θ,φ)
 *   R_nl(r)  = sqrt( (2Z/(n a0))^3 · (n-l-1)! / (2n (n+l)!) )
 *              · e^{-ρ/2} ρ^l L^{2l+1}_{n-l-1}(ρ),        ρ = 2Zr/(n a0)
 *   Y_lm      : 实数形式球谐（cos 分量 / sin 分量），归一化 ∫|Y|²dΩ = 1
 * 本模块不依赖任何第三方库，可直接在 Node 中做数值自检。
 */

export const A0_PM = 52.9177210544;        // 玻尔半径 (pm)
export const RY_EV = 13.605693122994;      // 里德堡能量 (eV)
export const LETTER = ['s', 'p', 'd', 'f', 'g', 'h', 'i'];

/* ------------------------------- 基础函数 -------------------------------- */

const FACT_CACHE = [1];
export function factorial(n) {
  if (n < 0) return NaN;
  n = Math.floor(n);
  while (FACT_CACHE.length <= n) FACT_CACHE.push(FACT_CACHE[FACT_CACHE.length - 1] * FACT_CACHE.length);
  return FACT_CACHE[n];
}

/** 广义拉盖尔多项式 L_k^{(a)}(x)，三项递推 */
export function laguerre(k, a, x) {
  if (k < 0) return 0;
  let l0 = 1;
  if (k === 0) return l0;
  let l1 = 1 + a - x;
  for (let i = 2; i <= k; i++) {
    const l2 = ((2 * i - 1 + a - x) * l1 - (i - 1 + a) * l0) / i;
    l0 = l1;
    l1 = l2;
  }
  return l1;
}

/** 关联勒让德函数 P_l^m(x)，m ≥ 0（不含 Condon–Shortley 相位） */
export function plgndr(l, m, x) {
  let pmm = 1;
  if (m > 0) {
    const somx2 = Math.sqrt(Math.max(0, (1 - x) * (1 + x)));
    let f = 1;
    for (let i = 1; i <= m; i++) { pmm *= f * somx2; f += 2; }
  }
  if (l === m) return pmm;
  let pmmp1 = x * (2 * m + 1) * pmm;
  if (l === m + 1) return pmmp1;
  let pll = 0;
  for (let ll = m + 2; ll <= l; ll++) {
    pll = ((2 * ll - 1) * x * pmmp1 - (ll + m - 1) * pmm) / (ll - m);
    pmm = pmmp1; pmmp1 = pll;
  }
  return pll;
}

/**
 * 角向归一化因子：A_lm(θ) = N_lm · P_l^|m|(cosθ)（不含 Condon–Shortley 相位）
 *   m = 0 : N = sqrt((2l+1)/(4π))·sqrt((l-m)!/(l+m)!)
 *   m ≠ 0 : 实数球谐的 √2 约定已计入此处，
 *           使 Y = N·P·cos(mφ) 满足 ∫|Y|²dΩ = 1（m≠0 时自动带上 √2）
 *   例：Y_1,1 = sqrt(3/4π)·sinθ·cosφ（即 p_x），∫|Y|²dΩ = 1
 */
export const normAngular = (l, m) => {
  const am = Math.abs(m);
  const base = Math.sqrt((2 * l + 1) / (4 * Math.PI) * factorial(l - am) / factorial(l + am));
  return am === 0 ? base : Math.SQRT2 * base;
};

/* ------------------------------- 径向部分 -------------------------------- */

/** 径向波函数 R_nl(r)，r 以 a0 为单位，返回单位 a0^{-3/2} */
export function radialR(n, l, r, z = 1) {
  if (n < 1 || l < 0 || l > n - 1) return 0;
  const rho = 2 * z * r / n;
  const norm = Math.sqrt(
    Math.pow(2 * z / n, 3) * factorial(n - l - 1) / (2 * n * factorial(n + l))
  );
  return norm * Math.exp(-rho / 2) * Math.pow(rho, l) * laguerre(n - l - 1, 2 * l + 1, rho);
}

/** 径向概率密度 D(r) = r²|R_nl(r)|²，∫D dr = 1，r 以 a0 为单位 */
export function radialDensity(n, l, r, z = 1) {
  const R = radialR(n, l, r, z);
  return r * r * R * R;
}

/** 径向节点位置（R_nl = 0 且 r > 0），单位 a0，升序 */
export function radialNodes(n, l, z = 1) {
  const k = n - l - 1;
  if (k <= 0) return [];
  const roots = [];
  const rMax = (n * n + 4 * n + 6) / z;
  const M = 40000;
  const f = (r) => {
    const rho = 2 * z * r / n;
    return laguerre(k, 2 * l + 1, rho);
  };
  let a = 1e-7, fa = f(a);
  for (let i = 1; i <= M; i++) {
    const b = rMax * i / M;
    const fb = f(b);
    if (fa === 0 || fa * fb < 0) {
      let lo = a, hi = b, flo = fa;
      for (let it = 0; it < 60; it++) {
        const mid = 0.5 * (lo + hi);
        const fm = f(mid);
        if (flo * fm <= 0) hi = mid; else { lo = mid; flo = fm; }
      }
      roots.push(0.5 * (lo + hi));
    }
    a = b; fa = fb;
  }
  return roots.filter((r, i, arr) => i === 0 || r - arr[i - 1] > 1e-6);
}

/* ------------------------------- 角向部分 -------------------------------- */

/** 实数球谐的角向振幅 A_lm(θ) = N_lm·P_l^|m|(cosθ)，与方位角无关 */
export const angularAmp = (l, m, mu) => {
  const am = Math.abs(m);
  return normAngular(l, am) * plgndr(l, am, mu);
};

/**
 * 实数球谐；mu = cosθ, phi = 方位角。N_lm 已含 m≠0 的 √2 约定，故 ∫|Y|²dΩ = 1。
 *   m = 0 : Y = N_l0·P_l(cosθ)
 *   m > 0 : Y = N_lm·P_l^m(cosθ)·cos(mφ)   （cos 型：p_x, d_xz, d_x²-y², f_x(x²-3y²) …）
 *   m < 0 : Y = N_l|m|·P_l^|m|(cosθ)·sin(|m|φ)（sin 型：p_y, d_yz, d_xy …）
 */
export function realY(l, m, mu, phi) {
  const A = angularAmp(l, m, mu);
  if (m === 0) return A;
  return A * (m > 0 ? Math.cos(m * phi) : Math.sin(-m * phi));
}

/* --------------------------- 解析可观测量 --------------------------------- */

export const energyEV = (n, z = 1) => -RY_EV * z * z / (n * n);        // E_n
export const energyRelative = (n) => 1 / (n * n);                      // 相对基态
export const angularMomentum = (l) => Math.sqrt(l * (l + 1));          // |L|/ħ
export const meanRadius = (n, l, z = 1) => (3 * n * n - l * (l + 1)) / (2 * z); // ⟨r⟩ / a0
export const countRadialNodes = (n, l) => n - l - 1;                   // 径向节点数
export const countAngularNodes = (l) => l;                             // 角向节面数
export const countTotalNodes = (n) => n - 1;                           // 节点总数

/** 径向分布 D(r) 的采样表：用于绘图、找最概然半径、求累积概率 */
export function radialProfile(n, l, { z = 1, samples = 2400, rMax = null } = {}) {
  const R = rMax ?? (n * n * 3 + n * 10 + 10) / z;
  const rs = new Float64Array(samples);
  const d = new Float64Array(samples);
  const cdf = new Float64Array(samples);
  const dr = R / (samples - 1);
  let acc = 0;
  for (let i = 0; i < samples; i++) {
    const r = i * dr;
    rs[i] = r;
    d[i] = radialDensity(n, l, r, z);
    if (i > 0) acc += 0.5 * (d[i] + d[i - 1]) * dr;
    cdf[i] = acc;
  }
  const total = acc || 1;
  for (let i = 0; i < samples; i++) cdf[i] /= total;

  // 最概然半径：D(r) 最大处（抛物线细化）
  let iMax = 1;
  for (let i = 1; i < samples; i++) if (d[i] > d[iMax]) iMax = i;
  let rMostProbable = rs[iMax];
  if (iMax > 0 && iMax < samples - 1) {
    const y0 = d[iMax - 1], y1 = d[iMax], y2 = d[iMax + 1];
    const denom = y0 - 2 * y1 + y2;
    if (denom !== 0) rMostProbable = rs[iMax] + 0.5 * dr * (y0 - y2) / denom;
  }

  // 95% 概率半径
  let r95 = rs[samples - 1];
  for (let i = 1; i < samples; i++) {
    if (cdf[i] >= 0.95) {
      const t = (0.95 - cdf[i - 1]) / Math.max(1e-12, cdf[i] - cdf[i - 1]);
      r95 = rs[i - 1] + t * dr;
      break;
    }
  }
  let peak = 0;
  for (let i = 0; i < samples; i++) if (d[i] > peak) peak = d[i];
  return { rs, d, cdf, rMax: R, dr, total, rMostProbable, r95, peak };
}

/** 由表格积分求 ⟨r⟩（与解析式互验） */
export function meanRadiusNumeric(profile) {
  const { rs, d, cdf, dr } = profile;
  let s = 0;
  for (let i = 0; i < rs.length; i++) s += rs[i] * d[i] * dr;
  const norm = cdf[cdf.length - 1] || 1;
  return s / norm;
}

/** 在给定球面上寻找 |Y_lm|² 的最大值（角向抽样拒绝法的上界包络） */
export function angularPeak(l, m) {
  const scale = m === 0 ? 1 : 2; // 实数球谐 m≠0 时 cos(mφ) 的振幅为 1，峰值处 sin/cos² = 1
  const f = (mu) => scale * angularAmp(l, m, mu) ** 2;
  const N = 600;
  let best = 0, iBest = 0;
  for (let i = 0; i <= N; i++) {
    const v = f(-1 + 2 * i / N);
    if (v > best) { best = v; iBest = i; }
  }
  // 黄金分割细化，避免峰值落在网格点之间导致包络偏小（会让拒绝法漏采样）
  const gr = (Math.sqrt(5) - 1) / 2;
  let a = Math.max(-1, -1 + 2 * (iBest - 1) / N);
  let b = Math.min(1, -1 + 2 * (iBest + 1) / N);
  let c = b - gr * (b - a), d = a + gr * (b - a);
  for (let k = 0; k < 80; k++) {
    if (f(c) > f(d)) b = d; else a = c;
    c = b - gr * (b - a); d = a + gr * (b - a);
  }
  return Math.max(best, f(0.5 * (a + b)));
}
