/**
 * orbital.js — 由 ψ_nlm 生成可视化数据
 *   · sampleCloud()  蒙特卡洛点云：位置严格按 |ψ|² 分布抽样（径向逆变换 + 角向拒绝法）
 *   · samplePosition() 单次"测量"：返回一个按概率抽到的电子位置
 *   · buildSlice()   xz 平面概率密度截面（用于节面/瓣结构教学）
 * 抽样自洽性：某区域内点数 ∝ 电子出现在该区域的概率。
 */
import {
  radialR, realY, radialProfile, angularPeak, normAngular, plgndr, radialNodes,
  meanRadius, energyEV, LETTER, countRadialNodes, countAngularNodes, countTotalNodes,
} from './physics.js';

/* ------------------------- 通用随机数（可复现） --------------------------- */

export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ------------------------------ 轨道描述 ---------------------------------- */

function orbitalLabel(n, l, m) {
  let sub;
  if (l === 0) sub = '';
  else if (l === 1) sub = m === 0 ? 'z' : (m > 0 ? 'x' : 'y');
  else if (l === 2) sub = m === 0 ? 'z²' : (m > 0 ? 'xz' : 'yz');
  else if (l === 3) sub = m === 0 ? 'z³' : (m > 0 ? 'xz²' : 'yz²');
  else sub = `m=${m}`;
  return `${n}${LETTER[l]}${sub}`;
}

/** 汇总一个轨道的全部解析信息（供 HUD 与图表使用） */
export function describe(n, l, m, opts = {}) {
  const profile = radialProfile(n, l, opts);
  return {
    n, l, m, label: orbitalLabel(n, l, m),
    energyEV: energyEV(n),
    radialNodes: countRadialNodes(n, l),
    angularNodes: countAngularNodes(l),
    totalNodes: countTotalNodes(n),
    meanRadius: meanRadius(n, l),
    meanRadiusNumeric: sampleMeanRadius(profile),
    rMostProbable: profile.rMostProbable,
    r95: profile.r95,
    nodeRadii: radialNodes(n, l),
    profile,
    extent: profile.r95,
  };
}

function sampleMeanRadius(profile) {
  const { rs, d, dr, cdf } = profile;
  let s = 0;
  for (let i = 0; i < rs.length; i++) s += rs[i] * d[i] * dr;
  return s / (cdf[cdf.length - 1] || 1);
}

/* --------------------------- 径向：逆变换抽样 ----------------------------- */

const GRID_N = 120000;
const SAMPLER_CACHE = new Map();   // 缓存 {n,l} 的径向抽样表，重复抽样/连续"测量"无需重建

/**
 * 在 arcsinh 非均匀网格上建径向累积分布：
 *   u = asinh(r/p)·p  →  r = p·sinh(u/p)
 * 原点附近网格密（可分辨 n 大时的径向振荡），远处变疏（尾部点数本来就少）。
 */
function buildRadialSampler(n, l) {
  const key = `${n},${l}`;
  if (SAMPLER_CACHE.has(key)) return SAMPLER_CACHE.get(key);
  const z = 1;
  const p = 3;
  const rMax = (n * n * 3 + n * 12 + 12) / z;   // 尾部概率 < 1e-4
  const uMax = Math.asinh(rMax / p) * p;
  const N = GRID_N;
  const du = uMax / N;
  const r = new Float64Array(N + 1);
  const cdf = new Float64Array(N + 1);
  let acc = 0;
  for (let i = 0; i <= N; i++) {
    const u = i * du;
    r[i] = p * Math.sinh(u / p);
  }
  for (let i = 0; i <= N; i++) {
    const u = i * du;
    const R = radialR(n, l, r[i], z);
    const d = r[i] * r[i] * R * R;
    if (i > 0) {
      const R0 = radialR(n, l, r[i - 1], z);
      const d0 = r[i - 1] * r[i - 1] * R0 * R0;
      // ∫ D(r) dr = ∫ D(r(u))·r′(u) du，其中 r′(u) = cosh(u/p)
      acc += 0.5 * (d * Math.cosh(u / p) + d0 * Math.cosh((i - 1) * du / p)) * du;
    }
    cdf[i] = acc;
  }
  const total = acc || 1;
  for (let i = 0; i <= N; i++) cdf[i] /= total;
  const sampler = { N, du, r, cdf, rMax, p };
  SAMPLER_CACHE.set(key, sampler);
  return sampler;
}

function sampleRadius(s, u) {
  const target = u * s.cdf[s.N];
  let lo = 0, hi = s.N;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (s.cdf[mid] <= target) lo = mid; else hi = mid;
  }
  const c0 = s.cdf[lo], c1 = s.cdf[hi];
  const f = c1 > c0 ? (target - c0) / (c1 - c0) : 0;
  const uu = (lo + f) * s.du;
  return s.p * Math.sinh(uu / s.p);
}

/* ------------------------------ 点云抽样 ---------------------------------- */

/**
 * 蒙特卡洛点云：每个点先按 D(r)=r²|R_nl|² 抽半径（逆变换），再按 |Y_lm|² 抽方向（拒绝法），
 * 于是任意体积元内的点数期望 ∝ |ψ|²dV —— 点云本身就是概率密度的无偏估计。
 *
 * 注意：这里刻意**不做**密度阈值剔除。任何"丢掉低密度点"的硬截断都等价于给 |ψ|² 加了一个
 * 阶跃，会系统性缩小 ⟨r⟩（实测 1s 会从 1.5a₀ 掉到 1.47a₀）。稀有区域的稀疏由渲染端按密度
 * 压暗来表现，从而保持"密度即概率"的诚实性。
 *
 * @param {object} o {n,l,m,count,seed,viewScale}
 */
export function sampleCloud({ n, l, m, count = 120000, seed = 12345, viewScale = 1 }) {
  const rand = mulberry32(seed);
  const rs = buildRadialSampler(n, l);
  const peak = angularPeak(l, m);           // 上界包络 >= max|Y|²

  const positions = new Float32Array(count * 3);
  const phase = new Float32Array(count);
  const density = new Float32Array(count);
  const radii = new Float32Array(count);

  let k = 0, guard = 0;
  const guardMax = count * 80 + 400000;
  while (k < count && guard < guardMax) {
    guard++;
    const r = sampleRadius(rs, rand());
    // 角向：球面均匀 → 以 |Y|²/峰值 接受
    const mu = 2 * rand() - 1;
    const phi = 2 * Math.PI * rand();
    const Y = realY(l, m, mu, phi);
    const w = (Y * Y) / peak;
    if (rand() > w) continue;

    const sinT = Math.sqrt(Math.max(0, 1 - mu * mu));
    const Rnl = radialR(n, l, r);
    const dens = Rnl * Rnl * Y * Y;         // 真实概率密度 |ψ|²

    const j = k * 3;
    positions[j] = viewScale * r * sinT * Math.cos(phi);
    positions[j + 1] = viewScale * r * mu;          // 以 +y 为极轴（Three.js 内 y 朝上）
    positions[j + 2] = viewScale * r * sinT * Math.sin(phi);
    phase[k] = Y >= 0 ? 1 : -1;
    density[k] = dens;
    radii[k] = viewScale * r;
    k++;
  }
  return { positions, phase, density, radii, count: k, rMax: rs.rMax, scale: viewScale };
}

/** 单次"测量"：按 |ψ|² 抽一个电子位置（用于教学演示"测量坍缩"） */
export function samplePosition(n, l, m, seed = Date.now() & 0xffff) {
  const rand = mulberry32(seed);
  const rs = buildRadialSampler(n, l);
  const peak = angularPeak(l, m);
  for (let i = 0; i < 100000; i++) {
    const r = sampleRadius(rs, rand());
    const mu = 2 * rand() - 1;
    const phi = 2 * Math.PI * rand();
    const Y = realY(l, m, mu, phi);
    if (rand() <= (Y * Y) / peak) {
      const sinT = Math.sqrt(Math.max(0, 1 - mu * mu));
      return { r, x: r * sinT * Math.cos(phi), y: r * mu, z: r * sinT * Math.sin(phi), Y };
    }
  }
  return null;
}

/* ------------------------------ 截面场 ------------------------------------ */

const RADIAL_TABLE_N = 4096;

/** 预计算 R_nl(r) 查表 + 线性插值（截面/曲线绘制用，避免反复算拉盖尔多项式） */
export function makeRadialTable(n, l, rMax) {
  const N = RADIAL_TABLE_N;
  const dr = rMax / (N - 1);
  const R = new Float64Array(N);
  for (let i = 0; i < N; i++) R[i] = radialR(n, l, i * dr);
  return {
    rMax, dr, R,
    at(r) {
      if (r <= 0) return R[0];
      if (r >= rMax) return 0;
      const t = r / dr, i = t | 0;
      const f = t - i;
      return R[i] * (1 - f) + R[i + 1] * f;
    },
  };
}

/**
 * xz 平面（方位角 φ=0 与 φ=π 所在平面）上的 |ψ|² 截面。
 * 该平面同时呈现径向节点与角向节面，是讲"节点结构"最直观的一张图。
 */
export function buildSlice({ n, l, m, res = 288, rMax = null }) {
  const R = rMax ?? (n * n * 3 + n * 12 + 12);
  const table = makeRadialTable(n, l, R);
  const data = new Float32Array(res * res);
  let max = 0;
  for (let j = 0; j < res; j++) {
    const z = (2 * (j + 0.5) / res - 1) * R;
    for (let i = 0; i < res; i++) {
      const x = (2 * (i + 0.5) / res - 1) * R;
      const r = Math.hypot(x, z);
      let v = 0;
      if (r < R) {
        const mu = r > 1e-12 ? z / r : 1;         // cosθ，φ = 0
        const Y = realY(l, m, mu, 0);
        const psi = table.at(r) * Y;
        v = psi * psi;
      }
      data[j * res + i] = v;
      if (v > max) max = v;
    }
  }
  return { data, res, rMax: R, max };
}

/* ------------------------------ 预设轨道 ---------------------------------- */

export const PRESETS = [
  { n: 1, l: 0, m: 0, note: '基态：球对称，无节点' },
  { n: 2, l: 0, m: 0, note: '1 个径向节点（半径 2a₀ 的球面）' },
  { n: 2, l: 1, m: 0, note: 'p_z：沿 z 轴哑铃形' },
  { n: 2, l: 1, m: 1, note: 'p_x：沿 x 轴哑铃形' },
  { n: 2, l: 1, m: -1, note: 'p_y：沿 y 轴哑铃形' },
  { n: 3, l: 0, m: 0, note: '2 个径向节点' },
  { n: 3, l: 1, m: 0, note: 'p_z + 1 个径向节点' },
  { n: 3, l: 2, m: 0, note: 'd_z²：沿 z 的双叶 + 腰部圆环' },
  { n: 3, l: 2, m: 1, note: 'd_xz：四叶草（xz 面）' },
  { n: 3, l: 2, m: -1, note: 'd_yz：四叶草（yz 面）' },
  { n: 3, l: 2, m: 2, note: 'd_x²−y²：四叶草（xy 面）' },
  { n: 3, l: 2, m: -2, note: 'd_xy：四叶草（xy 面，旋转 45°）' },
  { n: 4, l: 0, m: 0, note: '3 个径向节点' },
  { n: 4, l: 1, m: 0, note: '高激发 p 态' },
  { n: 4, l: 2, m: 0, note: '高激发 d 态' },
  { n: 4, l: 3, m: 0, note: 'f_z³：3 个角向节面' },
  { n: 4, l: 3, m: 1, note: 'f_xz²' },
  { n: 4, l: 3, m: 3, note: 'f_x(x²−3y²)' },
  { n: 5, l: 4, m: 0, note: 'g 轨道：4 个角向节面' },
  { n: 6, l: 5, m: 0, note: 'h 轨道：n=6 的高角动量态' },
];

export { orbitalLabel };
