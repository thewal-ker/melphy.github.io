/**
 * chart.js — 径向概率分布 D(r) = r²|R_nl|² 曲线
 * 与 3D 点云共用同一套密度色标，因此"曲线高的 r 区间"正是"点云亮的球壳"。
 */
import { densityCss } from './colormap.js';

export function drawRadialChart(canvas, profile, info = {}) {
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const cssW = canvas.clientWidth || 300;
  const cssH = Math.round(cssW * 0.46);
  canvas.width = Math.round(cssW * dpr);
  canvas.height = Math.round(cssH * dpr);
  canvas.style.height = cssH + 'px';
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssW, cssH);

  const padL = 34, padR = 10, padT = 12, padB = 22;
  const w = cssW - padL - padR;
  const h = cssH - padT - padB;
  const { rs, d, rMax, peak } = profile;
  const N = rs.length;

  // 数据区间：取到 D(r) 变得可忽略处，避免右侧大片空白
  let last = N - 1;
  for (let i = N - 1; i > 0; i--) if (d[i] > peak * 2e-3) { last = i; break; }
  const rTop = Math.max(1, rs[last] * 1.06);

  const X = (r) => padL + (r / rTop) * w;
  const Y = (v) => padT + h - Math.min(1, v / peak) * h;

  // 网格
  ctx.strokeStyle = 'rgba(96,132,200,0.14)';
  ctx.lineWidth = 1;
  ctx.font = '10px ui-monospace, Consolas, monospace';
  ctx.fillStyle = '#7d90b4';
  const ticks = niceTicks(rTop, 5);
  for (const t of ticks) {
    const x = X(t);
    ctx.beginPath(); ctx.moveTo(x, padT); ctx.lineTo(x, padT + h); ctx.stroke();
    ctx.textAlign = 'center';
    ctx.fillText(String(t), x, cssH - 7);
  }
  ctx.textAlign = 'left';
  ctx.fillText('D(r)', 4, padT + 8);
  ctx.textAlign = 'right';
  ctx.fillText('r / a₀', cssW - 6, cssH - 7);

  // 曲线下方按密度色标填充（柱状切片，颜色与点云一致）
  for (let i = 1; i < N; i++) {
    if (rs[i] > rTop) break;
    const y0 = Y(d[i - 1]), y1 = Y(d[i]);
    const x0 = X(rs[i - 1]), x1 = X(rs[i]);
    const t = Math.min(1, Math.max(0, (0.5 * (d[i - 1] + d[i])) / peak));
    ctx.fillStyle = densityCss(Math.pow(t, 0.45));
    ctx.globalAlpha = 0.85;
    ctx.fillRect(x0, Math.min(y0, y1), Math.max(0.8, x1 - x0), padT + h - Math.min(y0, y1));
  }
  ctx.globalAlpha = 1;

  // 曲线描边
  ctx.beginPath();
  for (let i = 0; i < N; i++) {
    if (rs[i] > rTop) break;
    const x = X(rs[i]), y = Y(d[i]);
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  }
  ctx.strokeStyle = 'rgba(220,235,255,0.85)';
  ctx.lineWidth = 1.2;
  ctx.stroke();

  // 径向节点
  ctx.setLineDash([3, 3]);
  ctx.strokeStyle = 'rgba(255,120,120,0.85)';
  for (const rn of (info.nodeRadii || [])) {
    if (rn > rTop) continue;
    const x = X(rn);
    ctx.beginPath(); ctx.moveTo(x, padT); ctx.lineTo(x, padT + h); ctx.stroke();
  }
  // 最概然半径
  ctx.strokeStyle = 'rgba(255,177,77,0.95)';
  if (info.rMostProbable <= rTop) {
    const x = X(info.rMostProbable);
    ctx.beginPath(); ctx.moveTo(x, padT); ctx.lineTo(x, padT + h); ctx.stroke();
  }
  // ⟨r⟩
  ctx.strokeStyle = 'rgba(78,163,255,0.85)';
  ctx.setLineDash([5, 4]);
  if (info.meanRadius <= rTop) {
    const x = X(info.meanRadius);
    ctx.beginPath(); ctx.moveTo(x, padT); ctx.lineTo(x, padT + h); ctx.stroke();
  }
  ctx.setLineDash([]);

  // 图例
  const items = [
    ['最概然', 'rgba(255,177,77,0.95)', info.rMostProbable?.toFixed(2) + ' a₀'],
    ['⟨r⟩', 'rgba(78,163,255,0.9)', info.meanRadius?.toFixed(2) + ' a₀'],
  ];
  if ((info.nodeRadii || []).length) items.push(['节点', 'rgba(255,120,120,0.9)', info.nodeRadii.map((v) => v.toFixed(1)).join(', ')]);
  let lx = padL + 2, ly = padT + 8;
  ctx.font = '10px ui-monospace, Consolas, monospace';
  for (const [name, col, val] of items) {
    ctx.strokeStyle = col;
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(lx, ly - 3); ctx.lineTo(lx + 10, ly - 3); ctx.stroke();
    ctx.fillStyle = '#9fb2d4';
    const text = `${name} ${val}`;
    ctx.fillText(text, lx + 14, ly);
    lx += 16 + ctx.measureText(text).width;
  }
}

function niceTicks(max, n) {
  const raw = max / n;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const norm = raw / mag;
  const step = (norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 5 ? 5 : 10) * mag;
  const out = [];
  for (let v = 0; v <= max + 1e-9; v += step) out.push(Math.round(v * 1e6) / 1e6);
  if (out.length <= 7) return out;
  return out.filter((_, i) => i % 2 === 0);
}
