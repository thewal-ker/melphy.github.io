/**
 * colormap.js — 全应用共用的密度配色
 * 点云、xz 截面、径向分布曲线使用同一套色标，保证"颜色 = 概率密度"的教学一致性。
 */

const STOPS = [
  [0.00, [0, 0, 0]],
  [0.06, [8, 10, 40]],
  [0.20, [24, 38, 120]],
  [0.38, [16, 110, 200]],
  [0.56, [40, 200, 200]],
  [0.72, [140, 235, 150]],
  [0.86, [250, 215, 90]],
  [1.00, [255, 255, 240]],
];

export const PHASE_POS = [1.0, 0.55, 0.18];   // ψ > 0：暖橙
export const PHASE_NEG = [0.18, 0.72, 1.0];   // ψ < 0：冷青

/** t∈[0,1] → [r,g,b]，各分量 0..1 */
export function densityColor(t) {
  const x = Math.max(0, Math.min(1, t));
  for (let i = 1; i < STOPS.length; i++) {
    if (x <= STOPS[i][0]) {
      const [t0, c0] = STOPS[i - 1], [t1, c1] = STOPS[i];
      const f = (x - t0) / (t1 - t0);
      return [
        (c0[0] + (c1[0] - c0[0]) * f) / 255,
        (c0[1] + (c1[1] - c0[1]) * f) / 255,
        (c0[2] + (c1[2] - c0[2]) * f) / 255,
      ];
    }
  }
  return [1, 1, 1];
}

/** 生成 1×256 的 LUT，供点云着色器与截面贴图使用 */
export function colormapTextureData(size = 256) {
  const data = new Uint8Array(size * 4);
  for (let i = 0; i < size; i++) {
    const [r, g, b] = densityColor(i / (size - 1));
    data[i * 4] = Math.round(r * 255);
    data[i * 4 + 1] = Math.round(g * 255);
    data[i * 4 + 2] = Math.round(b * 255);
    data[i * 4 + 3] = 255;
  }
  return data;
}

/** 把 |ψ|² 的相对值映射成"看得见"的强度：压缩动态范围 + 暗部截断 */
export function densityLevel(v, max, gamma = 0.38, floor = 0.012) {
  const t = Math.pow(Math.max(0, v) / (max || 1), gamma);
  if (t <= floor) return 0;
  return Math.min(1, (t - floor) / (1 - floor));
}

/** 暗部压暗用的余量（1 → 从 0 开始可见），保证远尾部的稀疏点淡出而不是硬切 */
export function isVisibleDensity(v, max, gamma = 0.38, floor = 0.012) {
  return Math.pow(Math.max(0, v) / (max || 1), gamma) > floor;
}

/** 供 Canvas2D 使用的颜色字符串 */
export function densityCss(t) {
  const [r, g, b] = densityColor(t);
  return `rgb(${Math.round(r * 255)},${Math.round(g * 255)},${Math.round(b * 255)})`;
}
