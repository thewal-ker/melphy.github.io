/**
 * scene.js — Three.js 渲染层
 *   · 点云：加法混合的点精灵，颜色取自共用色标（密度）或相位（± 波瓣）
 *   · 截面：xz 平面 |ψ|² 贴图
 *   · 原子核、坐标轴、玻尔半径环
 *   · 自实现轨道控制（拖动旋转 / 滚轮缩放 / 右键或双指平移），无外部依赖
 *   · 沿视线对点云做射线求交，实现"点击测量"
 */
import * as THREE from '../vendor/three.module.js';
import { colormapTextureData, densityLevel, PHASE_POS, PHASE_NEG } from './colormap.js';

const VERT = /* glsl */`
attribute float aPhase;    // +1 / -1 波函数符号
attribute float aDensity;  // 归一化后的密度色标位置 0..1
attribute float aRnd;      // 逐点随机数（重建时的错位淡入 + 漂浮动画）
uniform float uSize;       // 世界单位下的点尺寸
uniform float uPixelRatio;
uniform float uScale;      // 世界单位 / 玻尔半径
uniform float uAppear;     // 0→1 逐点淡入进度
uniform float uAnim;       // 漂浮动画强度
uniform float uTime;
uniform float uAtten;      // 近核过曝抑制强度，避免原点附近一片死白
varying float vT;          // 供片元着色器查色标
varying float vPhase;
varying float vRnd;
void main() {
  vec3 p = position;
  if (uAnim > 0.001) {
    float ra = 6.2831853 * aRnd;
    float ph = aRnd * 41.7 + uTime * 0.9;
    p.x += uAnim * 0.022 * uScale * sin(ph) * cos(ra);
    p.y += uAnim * 0.022 * uScale * sin(ph * 1.31) * sin(ra);
    p.z += uAnim * 0.022 * uScale * cos(ph * 0.87);
  }
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  gl_Position = projectionMatrix * mv;
  float d = max(length(mv.xyz), 1e-4);
  gl_PointSize = max(1.0, uSize * uPixelRatio * (300.0 / d));   // 透视衰减
  float t = 1.0 - clamp(length(p) / (3.2 * uScale), 0.0, 1.0);
  vT = aDensity * (1.0 - uAtten * t * t);
  vPhase = aPhase;
  vRnd = aRnd;
}
`;

const FRAG = /* glsl */`
uniform sampler2D uLut;
uniform float uAlpha;
uniform float uAppear;
uniform float uPhaseMix;
uniform vec3 uPos;
uniform vec3 uNeg;
varying float vT;
varying float vPhase;
varying float vRnd;
void main() {
  vec2 c = gl_PointCoord * 2.0 - 1.0;
  float r2 = dot(c, c);
  if (r2 > 1.0) discard;
  float core = exp(-3.2 * r2) * (1.0 - r2);       // 软圆斑
  float appear = smoothstep(vRnd - 0.12, vRnd + 0.06, uAppear);
  vec3 densCol = texture2D(uLut, vec2(clamp(vT, 0.0, 1.0), 0.5)).rgb;
  // 相位模式：整片云按 ψ 的符号染色（暖=正、冷=负），亮度仍随密度变化，
  // 于是"± 波瓣"的分界与"哪里概率大"能同时读出来。
  vec3 phaseCol = vPhase > 0.0 ? uPos : uNeg;
  vec3 col = mix(densCol, phaseCol, uPhaseMix * (0.62 + 0.38 * pow(max(vT, 0.0), 0.4)));
  gl_FragColor = vec4(col * core * uAlpha * appear, 1.0);
}
`;

function glowTexture(size = 128) {
  const cv = document.createElement('canvas');
  cv.width = cv.height = size;
  const ctx = cv.getContext('2d');
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0.0, 'rgba(255,255,255,1)');
  g.addColorStop(0.18, 'rgba(190,225,255,0.55)');
  g.addColorStop(0.45, 'rgba(90,150,255,0.16)');
  g.addColorStop(1.0, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export class AtomScene {
  constructor(container) {
    this.container = container;
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setClearColor(0x04060f, 1);
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.fog = null;
    this.camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.05, 5000);

    this.group = new THREE.Group();
    this.scene.add(this.group);
    this.cloudGroup = new THREE.Group();
    this.group.add(this.cloudGroup);

    // 色标 LUT
    const lutData = new Uint8Array(colormapTextureData(256));
    this.lut = new THREE.DataTexture(lutData, 256, 1, THREE.RGBAFormat);
    this.lut.needsUpdate = true;
    this.lut.minFilter = this.lut.magFilter = THREE.LinearFilter;
    this.lut.wrapS = THREE.ClampToEdgeWrapping;
    this.lut.wrapT = THREE.ClampToEdgeWrapping;

    this._buildNucleus();
    this._buildAxes();
    this._buildSlice();
    this._buildMarkers();

    this.cloud = null;
    this.measurements = [];
    this.phaseColoring = false;
    this.atten = 0.55;
    this.alpha = 1.35;
    this.appear = 1;
    this.animStrength = 0.35;
    this.scale = 1;
    this.bohrRadius = 1;

    // 相机轨道参数
    this.az = Math.PI * 0.25;
    this.el = 0.34;
    this.dist = 8;
    this.targetDist = 8;
    this.target = new THREE.Vector3(0, 0, 0);
    this.targetLook = new THREE.Vector3(0, 0, 0);
    this.autoRotate = true;
    this.dragging = null;
    this.lastPointer = { x: 0, y: 0 };
    this.raycaster = new THREE.Raycaster();
    this.clock = new THREE.Clock();

    this._bindControls();
    this._onResize = () => this.resize();
    window.addEventListener('resize', this._onResize);
    this._applyCamera();
  }

  /* ------------------------------ 场景元素 ------------------------------ */

  _buildNucleus() {
    this.nucleus = new THREE.Mesh(
      new THREE.SphereGeometry(0.05, 20, 14),
      new THREE.MeshBasicMaterial({ color: 0xffffff })
    );
    this.group.add(this.nucleus);
    this.glow = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glowTexture(), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: 0.9,
    }));
    this.glow.scale.setScalar(1.2);
    this.group.add(this.glow);
  }

  _buildAxes() {
    this.axisMat = new THREE.LineBasicMaterial({ color: 0x2a3a6a, transparent: true, opacity: 0.85 });
    this.axes = new THREE.Group();
    const mk = (a, b) => {
      const g = new THREE.BufferGeometry().setFromPoints([a, b]);
      return new THREE.Line(g, this.axisMat);
    };
    this.axes.add(mk(new THREE.Vector3(-1, 0, 0), new THREE.Vector3(1, 0, 0)));
    this.axes.add(mk(new THREE.Vector3(0, -1, 0), new THREE.Vector3(0, 1, 0)));
    this.axes.add(mk(new THREE.Vector3(0, 0, -1), new THREE.Vector3(0, 0, 1)));
    this.group.add(this.axes);

    // 玻尔半径环（经典轨道对照：半径 n²a₀）
    const seg = 200, pts = [];
    for (let i = 0; i <= seg; i++) {
      const a = i / seg * Math.PI * 2;
      pts.push(new THREE.Vector3(Math.cos(a), 0, Math.sin(a)));
    }
    this.bohrRing = new THREE.Line(
      new THREE.BufferGeometry().setFromPoints(pts),
      new THREE.LineDashedMaterial({ color: 0xffb14d, dashSize: 0.12, gapSize: 0.1, transparent: true, opacity: 0.9 })
    );
    this.bohrRing.computeLineDistances();
    this.group.add(this.bohrRing);
  }

  _buildSlice() {
    this.sliceTexture = new THREE.DataTexture(new Uint8Array(4), 1, 1, THREE.RGBAFormat);
    this.sliceTexture.needsUpdate = true;
    this.sliceTexture.minFilter = this.sliceTexture.magFilter = THREE.LinearFilter;
    this.sliceTexData = null;
    this.slice = new THREE.Mesh(
      new THREE.PlaneGeometry(1, 1),
      new THREE.MeshBasicMaterial({
        map: this.sliceTexture, transparent: true, opacity: 0.95,
        side: THREE.DoubleSide, depthWrite: false, depthTest: false,
      })
    );
    this.slice.renderOrder = -1;
    this.slice.visible = false;
    this.group.add(this.slice);
    this.sliceBorder = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.PlaneGeometry(1, 1)),
      new THREE.LineBasicMaterial({ color: 0x3d5a9a, transparent: true, opacity: 0.8 })
    );
    this.sliceBorder.visible = false;
    this.group.add(this.sliceBorder);
  }

  _buildMarkers() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(3 * 3), 3));
    this.markerPoints = new THREE.Points(g, new THREE.PointsMaterial({
      color: 0xfff6c0, size: 11, sizeAttenuation: false, transparent: true, opacity: 1,
    }));
    this.markerPoints.renderOrder = 5;
    this.markerPoints.visible = false;
    this.group.add(this.markerPoints);
    this.markerLine = new THREE.Line(
      new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]),
      new THREE.LineDashedMaterial({ color: 0xfff6c0, dashSize: 0.1, gapSize: 0.08, transparent: true, opacity: 0.7 })
    );
    this.markerLine.visible = false;
    this.group.add(this.markerLine);
  }

  /* -------------------------------- 点云 -------------------------------- */

  /**
   * @param {object} cloud  由 orbital.sampleCloud() 产生
   * @param {object} opts   { densityMax, viewScale, nucleusUnits }
   */
  setCloud(cloud, { densityMax = 1, viewScale = 1, nucleusUnits = 1 } = {}) {
    this.disposeCloud();
    const n = cloud.count;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(cloud.positions.subarray(0, n * 3), 3));
    g.setAttribute('aPhase', new THREE.BufferAttribute(cloud.phase.subarray(0, n), 1));
    const rnd = new Float32Array(n);
    const den = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      rnd[i] = Math.random();
      den[i] = densityLevel(cloud.density[i], densityMax, 0.38, 0.012);
    }
    g.setAttribute('aRnd', new THREE.BufferAttribute(rnd, 1));
    g.setAttribute('aDensity', new THREE.BufferAttribute(den, 1));
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), cloud.rMax * viewScale);
    g.computeBoundingSphere();

    this.material = new THREE.ShaderMaterial({
      uniforms: {
        uLut: { value: this.lut },
        uSize: { value: viewScale * 0.55 / Math.max(1, n / 100000) },
        uPixelRatio: { value: this.renderer.getPixelRatio() },
        uScale: { value: viewScale },
        uAppear: { value: 0 },
        uAlpha: { value: this.alpha },
        uAnim: { value: this.animStrength },
        uTime: { value: 0 },
        uPhaseMix: { value: this.phaseColoring ? 1 : 0 },
        uPos: { value: new THREE.Vector3(...PHASE_POS) },
        uNeg: { value: new THREE.Vector3(...PHASE_NEG) },
        uAtten: { value: this.atten },
      },
      vertexShader: VERT,
      fragmentShader: FRAG,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      depthTest: true,
    });
    this.cloud = new THREE.Points(g, this.material);
    this.cloud.frustumCulled = true;
    this.cloudGroup.add(this.cloud);

    this.scale = viewScale;
    this.bohrRadius = nucleusUnits * viewScale;
    this.setBohrRadius(nucleusUnits);
    const k = viewScale;
    this.nucleus.scale.setScalar(Math.max(0.6, 0.035 * k + 0.04));
    this.glow.scale.setScalar(Math.max(1.0, 0.55 * k));
    this.glow.material.opacity = 0.75;
    this.axes.scale.setScalar(cloud.rMax * k * 0.9);
    this.slice.scale.setScalar(2 * cloud.rMax * k * 0.95);
    this.sliceBorder.scale.copy(this.slice.scale);
    this.slice.position.z = -1e-4;
    this.markerPoints.material.size = 11;
    // 逐点淡入
    this.appear = 0;
    this._appearTarget = 1;
  }

  disposeCloud() {
    if (!this.cloud) return;
    this.cloudGroup.remove(this.cloud);
    this.cloud.geometry.dispose();
    this.material.dispose();
    this.cloud = null;
  }

  /** 透明化重采样：只让点云渐隐，其余元素不动（讲"电子位置不确定"用） */
  fadeOutCloud() { this._fadeTarget = 0; }

  /** Bohr 半径环半径（单位：a₀，绘图单位由 scale 换算） */
  setBohrRadius(nucleusUnits) {
    this.bohrRing.scale.setScalar(nucleusUnits * this.scale);
    const mat = this.bohrRing.material;
    mat.dashSize = 0.12 * this.scale;
    mat.gapSize = 0.1 * this.scale;
    this.bohrRing.computeLineDistances();
  }

  setBohrVisible(v) { this.bohrRing.visible = v; }
  setAxesVisible(v) { this.axes.visible = v; }
  setNucleusVisible(v) { this.nucleus.visible = v; this.glow.visible = v; }
  setPhaseColoring(v) {
    this.phaseColoring = v;
    if (this.material) this.material.uniforms.uPhaseMix.value = v ? 1 : 0;
  }
  setAttenuation(a) { this.atten = a; if (this.material) this.material.uniforms.uAtten.value = a; }
  setPointSize(k) { if (this.material) this.material.uniforms.uSize.value = k; }
  /** 点云整体亮度（加法混合下的曝光补偿） */
  setAlpha(a) { this.alpha = a; if (this.material) this.material.uniforms.uAlpha.value = a; }
  setAnimStrength(a) { this.animStrength = a; if (this.material) this.material.uniforms.uAnim.value = a; }
  setAutoRotate(v) { this.autoRotate = v; }

  /** 把 xz 截面贴到平面上（data 为 Float32Array，value 为归一化后的 0..1 色标位置） */
  setSlice(textureData, res, worldSize) {
    if (this.sliceTexData && this.sliceTexData.length === textureData.length) {
      this.sliceTexData.set(textureData);
      this.sliceTexture.needsUpdate = true;
    } else {
      this.sliceTexData = new Uint8Array(textureData);
      this.sliceTexture.dispose();
      this.sliceTexture = new THREE.DataTexture(this.sliceTexData, res, res, THREE.RGBAFormat);
      this.sliceTexture.needsUpdate = true;
      this.sliceTexture.minFilter = this.sliceTexture.magFilter = THREE.LinearFilter;
      this.slice.material.map = this.sliceTexture;
      this.slice.material.needsUpdate = true;
    }
    this.slice.scale.setScalar(worldSize);
    this.sliceBorder.scale.setScalar(worldSize);
  }

  setSliceVisible(v) { this.slice.visible = v; this.sliceBorder.visible = v; }

  /* --------------------- 沿视线求交：点击"测量" --------------------- */

  /**
   * 相机射线与点云求交，返回命中点（世界坐标 → 玻尔半径单位）与到核距离。
   * 用空间哈希网格把候选点限制在射线附近，避免逐点全扫。
   */
  raycastCloud(clientX, clientY) {
    if (!this.cloud) return null;
    const rect = this.renderer.domElement.getBoundingClientRect();
    const ndc = new THREE.Vector2(
      ((clientX - rect.left) / rect.width) * 2 - 1,
      -((clientY - rect.top) / rect.height) * 2 + 1
    );
    this.raycaster.setFromCamera(ndc, this.camera);
    const ray = this.raycaster.ray;
    const pos = this.cloud.geometry.getAttribute('position').array;
    const n = this.cloud.geometry.getAttribute('position').count;
    // 射线与点云包围球的相交区间
    const sphere = this.cloud.geometry.boundingSphere;
    const hitSphere = new THREE.Sphere(sphere.center, sphere.radius * 1.02);
    const pt = new THREE.Vector3();
    if (!this.raycaster.ray.intersectsSphere(hitSphere)) return null;
    const toCenter = pt.copy(sphere.center).sub(ray.origin);
    const tCa = toCenter.dot(ray.direction);
    const d2 = toCenter.lengthSq() - tCa * tCa;
    const half = Math.sqrt(Math.max(0, sphere.radius * sphere.radius - d2));
    const t0 = Math.max(0, tCa - half), t1 = tCa + half;

    const worldScale = this.cloudGroup.scale.x || 1;
    const threshold = this.material.uniforms.uSize.value * 0.9;
    let best = Infinity, bestIdx = -1;
    // 分块扫描，命中率低时也不至于卡顿
    const chunk = 20000;
    for (let s = 0; s < n; s += chunk) {
      const e = Math.min(n, s + chunk);
      for (let i = s; i < e; i++) {
        const x = pos[i * 3], y = pos[i * 3 + 1], z = pos[i * 3 + 2];
        const t = (x - ray.origin.x) * ray.direction.x
          + (y - ray.origin.y) * ray.direction.y
          + (z - ray.origin.z) * ray.direction.z;
        if (t < t0 || t > t1) continue;
        const dx = ray.origin.x + ray.direction.x * t - x;
        const dy = ray.origin.y + ray.direction.y * t - y;
        const dz = ray.origin.z + ray.direction.z * t - z;
        const dd = dx * dx + dy * dy + dz * dz;
        if (dd < best) { best = dd; bestIdx = i; }
      }
    }
    if (bestIdx < 0) return null;
    const wx = pos[bestIdx * 3] * worldScale;
    const wy = pos[bestIdx * 3 + 1] * worldScale;
    const wz = pos[bestIdx * 3 + 2] * worldScale;
    return {
      index: bestIdx,
      world: new THREE.Vector3(wx, wy, wz),
      radius: Math.hypot(wx, wy, wz) / (this.scale || 1),   // 单位 a₀
    };
  }

  addMarker(world, unitRadius) {
    this.measurements.push({ world: world.clone(), radius: unitRadius });
    if (this.measurements.length > 6) this.measurements.shift();
    this._refreshMarkers();
  }
  clearMarkers() { this.measurements = []; this._refreshMarkers(); }

  _refreshMarkers() {
    const m = this.measurements;
    const arr = this.markerPoints.geometry.getAttribute('position');
    for (let i = 0; i < 3; i++) {
      const p = m[Math.max(0, m.length - 3) + i];
      if (p) arr.setXYZ(i, p.world.x, p.world.y, p.world.z);
      else arr.setXYZ(i, 0, 0, 0);
    }
    arr.needsUpdate = true;
    this.markerPoints.geometry.setDrawRange(0, Math.min(3, m.length));
    this.markerPoints.visible = m.length > 0;
    const last = m[m.length - 1];
    if (last) {
      const linePos = this.markerLine.geometry.getAttribute('position');
      linePos.setXYZ(0, 0, 0, 0);
      linePos.setXYZ(1, last.world.x, last.world.y, last.world.z);
      linePos.needsUpdate = true;
      this.markerLine.geometry.computeBoundingSphere();
      this.markerLine.computeLineDistances();
      this.markerLine.visible = true;
    } else {
      this.markerLine.visible = false;
    }
  }

  /* ------------------------------- 相机 -------------------------------- */

  fitToRadius(radius, instant = false) {
    const vFov = this.camera.fov * Math.PI / 180;
    const hFov = 2 * Math.atan(Math.tan(vFov / 2) * this.camera.aspect);
    const d = 1.25 * radius / Math.tan(Math.min(vFov, hFov) / 2);
    this.targetDist = Math.max(1.2, d);
    if (instant) { this.dist = this.targetDist; this.target.set(0, 0, 0); this.targetLook.set(0, 0, 0); }
  }

  setView(az, el) { this.az = az; this.el = el; }

  _applyCamera() {
    const ce = Math.cos(this.el);
    this.camera.position.set(
      this.target.x + this.dist * ce * Math.sin(this.az),
      this.target.y + this.dist * Math.sin(this.el),
      this.target.z + this.dist * ce * Math.cos(this.az)
    );
    this.camera.lookAt(this.targetLook);
  }

  _bindControls() {
    const el = this.renderer.domElement;
    el.style.touchAction = 'none';
    el.addEventListener('pointerdown', (e) => {
      el.setPointerCapture(e.pointerId);
      this.dragging = e.button === 2 ? 'pan' : 'rotate';
      this.lastPointer = { x: e.clientX, y: e.clientY };
      this._downAt = { x: e.clientX, y: e.clientY, t: performance.now() };
    });
    el.addEventListener('pointermove', (e) => {
      if (!this.dragging) return;
      const dx = e.clientX - this.lastPointer.x;
      const dy = e.clientY - this.lastPointer.y;
      this.lastPointer = { x: e.clientX, y: e.clientY };
      if (this.dragging === 'rotate') {
        this.az -= dx * 0.006;
        this.el = Math.max(-1.5, Math.min(1.5, this.el + dy * 0.006));
      } else {
        const k = this.dist * 0.0016;
        const right = new THREE.Vector3().setFromMatrixColumn(this.camera.matrix, 0);
        const up = new THREE.Vector3().setFromMatrixColumn(this.camera.matrix, 1);
        this.target.addScaledVector(right, -dx * k).addScaledVector(up, dy * k);
        this.targetLook.copy(this.target);
      }
    });
    const end = (e) => {
      if (this.dragging && this._downAt) {
        const moved = Math.hypot(e.clientX - this._downAt.x, e.clientY - this._downAt.y);
        const dt = performance.now() - this._downAt.t;
        if (moved < 5 && dt < 450 && this.onClick) this.onClick(e.clientX, e.clientY);
      }
      this.dragging = null;
      try { el.releasePointerCapture(e.pointerId); } catch { /* ignore */ }
    };
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', () => { this.dragging = null; });
    el.addEventListener('contextmenu', (e) => e.preventDefault());
    el.addEventListener('wheel', (e) => {
      e.preventDefault();
      const k = Math.exp(e.deltaY * 0.0012);
      this.targetDist = Math.max(0.4, Math.min(4000, this.targetDist * k));
    }, { passive: false });
  }

  onClick(cb) { this.onClick = cb; }

  resize() {
    const w = this.container.clientWidth, h = this.container.clientHeight;
    if (!w || !h) return;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    if (this.material) this.material.uniforms.uPixelRatio.value = this.renderer.getPixelRatio();
  }

  update(dt) {
    if (this.autoRotate && !this.dragging) this.az += dt * 0.12;
    // 相机平滑
    this.dist += (this.targetDist - this.dist) * Math.min(1, dt * 7);
    this.target.lerp(this.targetLook, Math.min(1, dt * 7));
    this._applyCamera();

    if (this.material) {
      const u = this.material.uniforms;
      u.uTime.value += dt;
      if (this._fadeTarget === 0) {
        this.appear = Math.max(0, this.appear - dt * 6);
        if (this.appear <= 0.001 && this.onFadedOut) this.onFadedOut();
      } else {
        this.appear = Math.min(1, this.appear + dt * 1.6);
      }
      u.uAppear.value = this.appear;
      u.uAnim.value = this.animStrength;
    }
    this.renderer.render(this.scene, this.camera);
  }
}
