/**
 * main.js — 应用装配：量子态选择 → 抽样 → 3D 点云 + 截面 + 读数 + 曲线
 *
 * 交互要点：
 *   · 改 n/l/m 或预设 → 重新抽样（自适应缩放，点云形状即时反映 |ψ|² 的节点结构）
 *   · ⌷ / 重新抽样按钮 → 先淡出旧点云再抽样新点云，直观展示"形状不变、位置全变"
 *   · 单击点云或按 M → 沿视线"测量"一次电子位置
 */
import * as THREE from '../vendor/three.module.js';
import { AtomScene } from './scene.js';
import {
  describe, sampleCloud, samplePosition, buildSlice, PRESETS, orbitalLabel,
} from './orbital.js';
import {
  A0_PM, LETTER, energyEV, angularMomentum, countRadialNodes, countAngularNodes, meanRadius,
} from './physics.js';
import { drawRadialChart } from './chart.js';
import { densityColor, densityLevel, PHASE_POS, PHASE_NEG } from './colormap.js';

const POINT_COUNTS = [30000, 60000, 120000, 200000];
const COUNT_LABELS = ['3 万', '6 万', '12 万', '20 万'];
const SLICE_RES = 256;

const $ = (id) => document.getElementById(id);

/* ---------------------------- 量子数合法性 ---------------------------- */

const maxL = (n) => n - 1;
const clampM = (m, l) => Math.max(-l, Math.min(l, m));

/**
 * 点云整体曝光系数。紧凑态（1s）的点全挤在近核处，加法混合下屏幕点密度极高会过曝；
 * 弥散态（3s/4f/6h）则偏暗。用点云中位半径（世界单位）做客观尺度，按下式做温和补偿：
 *
 *   α = A · (r_med / 13)^p,   A = 1.15, p = 0.30
 *
 * 系数由 scripts/brightness.mjs 对 1s/2p/3s/3p/3d/4f 六种态实际渲染反解得到：
 * 该组参数把画面过曝像素占比从 0.1%~14.8% 收敛到 0.2%~12.1%，同时保留
 * "紧凑态更亮"这一物理事实（绝对尺度由右侧读数承担，不靠调色欺骗眼睛）。
 */
const ALPHA_A = 1.15;
const ALPHA_P = 0.30;
function alphaFor(worldMedianR) {
  return Math.max(0.15, Math.min(3.2, ALPHA_A * Math.pow(worldMedianR / 13, ALPHA_P)));
}

/* ------------------------------- 应用 -------------------------------- */

class App {
  constructor() {
    this.canvas = $('view');
    this.view = new AtomScene(this.canvas.parentElement);
    this.canvas.remove();                       // 用渲染器自己的 canvas 接管全屏视口
    this.view.renderer.domElement.id = 'view';
    this.view.setBohrVisible(true);

    this.state = {
      n: 1, l: 0, m: 0,
      countIdx: 3,
      phase: false,
      slice: false,
      pointScale: 1,
      atten: 0.3,
      seed: 20240613,
    };
    this.info = null;
    this.cloud = null;
    this.busy = false;
    this.pendingResample = false;
    this.tour = false;
    this.tourAt = 0;
    this.tourIdx = 0;

    this.buildPresets();
    this.bindUI();
    this.view.onClick((x, y) => this.measureAt(x, y));
    this.view.onFadedOut = () => {
      if (this.pendingResample) { this.pendingResample = false; this.regenerate(); }
    };

    this.resizeChart();
    window.addEventListener('resize', () => this.resizeChart());
    this.updateLegend();
    this.load(1, 0, 0, { instant: true });
    this.loop();
  }

  /* ------------------------------ 预设 ------------------------------- */

  buildPresets() {
    const sel = $('preset');
    sel.innerHTML = '';
    const groups = new Map();
    for (const p of PRESETS) {
      const key = `${p.n}${LETTER[p.l]}`;
      if (!groups.has(key)) {
        const og = document.createElement('optgroup');
        og.label = key;
        groups.set(key, og);
        sel.appendChild(og);
      }
      const opt = document.createElement('option');
      opt.value = `${p.n},${p.l},${p.m}`;
      opt.textContent = `${orbitalLabel(p.n, p.l, p.m)} — ${p.note}`;
      groups.get(key).appendChild(opt);
    }
    sel.addEventListener('change', () => {
      const [n, l, m] = sel.value.split(',').map(Number);
      this.load(n, l, m);
    });
  }

  /* ------------------------------- UI ------------------------------- */

  bindUI() {
    const nEl = $('n'), lEl = $('l'), mEl = $('m');

    nEl.addEventListener('input', () => {
      const n = +nEl.value;
      lEl.max = String(maxL(n));
      if (+lEl.value > maxL(n)) lEl.value = String(maxL(n));
      mEl.max = String(+lEl.value);
      mEl.min = String(-(+lEl.value));
      if (Math.abs(+mEl.value) > +lEl.value) mEl.value = String(clampM(+mEl.value, +lEl.value));
      this.syncQuantumLabels();
      this.load(+n, +lEl.value, +mEl.value);
    });
    lEl.addEventListener('input', () => {
      const l = +lEl.value;
      mEl.max = String(l);
      mEl.min = String(-l);
      if (Math.abs(+mEl.value) > l) mEl.value = String(clampM(+mEl.value, l));
      this.syncQuantumLabels();
      this.load(+nEl.value, l, +mEl.value);
    });
    mEl.addEventListener('input', () => {
      this.syncQuantumLabels();
      this.load(+nEl.value, +lEl.value, +mEl.value);
    });

    $('count').addEventListener('input', (e) => {
      this.state.countIdx = +e.target.value;
      $('countOut').textContent = COUNT_LABELS[this.state.countIdx];
      this.regenerate();
    });
    $('psize').addEventListener('input', (e) => {
      this.state.pointScale = +e.target.value;
      $('psizeOut').textContent = this.state.pointScale.toFixed(1) + '×';
      this.applyPointSize();
    });
    $('atten').addEventListener('input', (e) => {
      this.state.atten = +e.target.value;
      $('attenOut').textContent = this.state.atten.toFixed(2);
      this.view.setAttenuation(this.state.atten);
    });

    $('chkPhase').addEventListener('change', (e) => {
      this.state.phase = e.target.checked;
      this.view.setPhaseColoring(this.state.phase);
      this.updateLegend();
    });
    $('chkSlice').addEventListener('change', (e) => {
      this.state.slice = e.target.checked;
      this.view.setSliceVisible(this.state.slice);
      if (this.state.slice) this.updateSlice();
    });
    $('chkAxes').addEventListener('change', (e) => this.view.setAxesVisible(e.target.checked));
    $('chkBohr').addEventListener('change', (e) => this.view.setBohrVisible(e.target.checked));
    $('chkNucleus').addEventListener('change', (e) => this.view.setNucleusVisible(e.target.checked));
    $('chkSpin').addEventListener('change', (e) => this.view.setAutoRotate(e.target.checked));
    $('chkAnim').addEventListener('change', (e) => this.view.setAnimStrength(e.target.checked ? 0.35 : 0));

    $('btnResample').addEventListener('click', () => this.resample());
    $('btnMeasure').addEventListener('click', () => this.measureRandom());
    $('btnFront').addEventListener('click', () => this.view.setView(0, 0.02));
    $('btnTop').addEventListener('click', () => this.view.setView(0, 1.45));
    $('btnFit').addEventListener('click', () => {
      this.view.target.set(0, 0, 0);
      this.view.targetLook.set(0, 0, 0);
      this.view.fitToRadius(this.currentRadius());
      this.view.setView(Math.PI * 0.25, 0.34);
      this.view.clearMarkers();
      $('measureReadout').textContent = '';
    });
    $('btnTour').addEventListener('click', () => this.toggleTour());

    window.addEventListener('keydown', (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;
      if (e.code === 'Space') { e.preventDefault(); this.resample(); }
      else if (e.key === 'm' || e.key === 'M') this.measureRandom();
      else if (e.key === 'r' || e.key === 'R') $('btnFit').click();
    });
  }

  syncQuantumLabels() {
    $('nOut').textContent = $('n').value;
    $('lOut').textContent = $('l').value;
    $('mOut').textContent = $('m').value;
  }

  syncControlsFromState() {
    const { n, l, m } = this.state;
    $('n').value = String(n);
    $('l').max = String(maxL(n));
    $('l').value = String(l);
    $('m').max = String(l);
    $('m').min = String(-l);
    $('m').value = String(m);
    this.syncQuantumLabels();
    const key = `${n},${l},${m}`;
    const sel = $('preset');
    sel.value = [...sel.options].some((o) => o.value === key) ? key : '';
    const preset = PRESETS.find((p) => p.n === n && p.l === l && p.m === m);
    $('presetNote').textContent = preset ? preset.note
      : `自定义态：n=${n}，l=${l}（${LETTER[l]}），m=${m}`;
  }

  currentRadius() {
    return 1.35 * 100;   // 点云 95 分位半径已归一化到 100 世界单位
  }

  /* --------------------------- 载入与抽样 --------------------------- */

  load(n, l, m, { instant = false } = {}) {
    this.state.n = n;
    this.state.l = l;
    this.state.m = m;
    this.syncControlsFromState();
    this.regenerate({ instant });
  }

  resample() {
    // 先让旧点云淡出，再抽新点云 —— 形状不变、位置全变
    this.view.fadeOutCloud();
    this.pendingResample = true;
    this.setStatus('重新抽样：电子位置完全改变…');
  }

  regenerate({ instant = false } = {}) {
    if (this.busy) { this.pendingResample = true; return; }
    this.busy = true;
    this.showLoading(true);
    requestAnimationFrame(() => setTimeout(() => this._regenerate(instant), 16));
  }

  _regenerate(instant) {
    const t0 = performance.now();
    const { n, l, m } = this.state;
    const count = POINT_COUNTS[this.state.countIdx];
    this.info = describe(n, l, m);

    this.state.seed = (this.state.seed * 1103515245 + 12345) & 0x7fffffff;
    const cloud = sampleCloud({
      n, l, m, count, seed: this.state.seed, viewScale: 1,
    });

    // 自适应世界尺度：用**实际抽样到的** 95 分位半径定标，使点云始终填满视野
    const sortedR = Float32Array.from(cloud.radii.subarray(0, cloud.count)).sort();
    const r95 = sortedR[Math.floor(sortedR.length * 0.95)] || 1;
    const viewScale = 100 / r95;
    cloud.scale = viewScale;
    for (let i = 0; i < cloud.count * 3; i++) cloud.positions[i] *= viewScale;
    for (let i = 0; i < cloud.count; i++) cloud.radii[i] *= viewScale;
    this.viewScale = viewScale;

    // 归一化基准：取 ~99.5 分位的密度，避免极少数近核点把量程拉爆
    const sorted = Float32Array.from(cloud.density.subarray(0, cloud.count)).sort();
    const ref = sorted[Math.floor(sorted.length * 0.995)] || sorted[sorted.length - 1] || 1;
    this.cloud = cloud;
    this.view.setCloud(cloud, {
      densityMax: ref, viewScale, nucleusUnits: n * n,
    });
    // 整体曝光补偿：紧凑态（1s）的点全挤在近核处，加法混合下屏幕点密度极高会过曝；
    // 弥散态（3p/4f）则相反。用点云中位半径（世界单位）作客观尺度做幂律归一，
    // 系数由 scripts/brightness.mjs 实际渲染反解得到。
    this.medianR = sortedR[Math.floor(sortedR.length * 0.5)];
    this.view.setAlpha(alphaFor(this.medianR));
    this.applyPointSize();
    this.view.setPhaseColoring(this.state.phase);
    this.view.setAttenuation(this.state.atten);
    this.view.setSliceVisible(this.state.slice);
    if (this.state.slice) this.updateSlice();

    const ms = performance.now() - t0;
    this.view.fitToRadius(this.currentRadius(), instant);
    this.updateReadouts(ms);
    this.showLoading(false);
    this.busy = false;
    if (this.pendingResample) { this.pendingResample = false; this.regenerate(); }
  }

  applyPointSize() {
    const base = this.viewScale * 0.55 / Math.max(1, this.cloud ? this.cloud.count / 100000 : 1);
    this.view.setPointSize(base * this.state.pointScale);
  }

  updateSlice() {
    const { n, l, m } = this.state;
    const s = buildSlice({ n, l, m, res: SLICE_RES, rMax: this.info.r95 * 1.9 });
    const data = new Uint8Array(SLICE_RES * SLICE_RES * 4);
    const cols = new Float32Array(3 * (SLICE_RES * SLICE_RES));
    let maxLevel = 1e-30;
    for (let i = 0; i < s.data.length; i++) {
      const lv = densityLevel(s.data[i], s.max, 0.42, 0.01);
      cols[i * 3] = lv;
      if (lv > maxLevel) maxLevel = lv;
    }
    for (let i = 0; i < s.data.length; i++) {
      const lv = cols[i * 3];
      const [r, g, b] = densityColor(lv);
      data[i * 4] = Math.round(r * 255);
      data[i * 4 + 1] = Math.round(g * 255);
      data[i * 4 + 2] = Math.round(b * 255);
      data[i * 4 + 3] = Math.round(255 * Math.min(1, Math.pow(lv, 0.75) * 1.15));
    }
    this.view.setSlice(data, SLICE_RES, 2 * s.rMax * this.viewScale);
  }

  /* ------------------------------ 读数 ------------------------------ */

  updateReadouts(ms) {
    const info = this.info;
    const { n, l, m } = this.state;
    const E = energyEV(n);
    $('stateTag').textContent = info.label;
    $('vQN').textContent = `${n}, ${l}, ${m}`;
    $('vLabel').textContent = `${info.label}　(l=${l} → ${LETTER[l]} 轨道)`;
    $('vE').textContent = `${E.toFixed(4)} eV`;
    $('vErel').textContent = `−1/${n}² = ${(1 / (n * n)).toFixed(4)} × 13.606`;
    $('vRn').textContent = `${countRadialNodes(n, l)} 个（球面）`;
    $('vAn').textContent = `${countAngularNodes(l)} 个（平面/锥面）`;
    $('vL').textContent = `${angularMomentum(l).toFixed(3)} ħ`;

    const a0 = (r) => `${r.toFixed(3)} a₀ = ${(r * A0_PM).toFixed(1)} pm`;
    $('vRmp').textContent = a0(info.rMostProbable);
    $('vRmean').textContent = a0(info.meanRadius);
    $('vR95').textContent = a0(info.r95);
    $('vBohr').textContent = `${(n * n).toFixed(2)} a₀ = ${(n * n * A0_PM).toFixed(1)} pm`;

    // 点云 ↔ 解析自检
    const cnt = this.cloud.count;
    let sum = 0;
    for (let i = 0; i < cnt; i++) sum += this.cloud.radii[i];
    const meanView = sum / cnt;
    const meanA0 = meanView / this.viewScale;
    const err = Math.abs(meanA0 - info.meanRadius) / info.meanRadius * 100;
    $('vCloudMean').textContent = `${meanA0.toFixed(3)} a₀（偏差 ${err.toFixed(2)}%）`;
    $('vCloudN').textContent = `${(cnt / 10000).toFixed(1)} 万`;
    $('vGenMs').textContent = `${ms.toFixed(0)} ms`;
    $('selfCheck').textContent =
      `点云平均半径 ${meanA0.toFixed(3)} a₀ vs 解析 ${info.meanRadius.toFixed(3)} a₀：`
      + `偏差 ${err.toFixed(2)}%（抽样噪声范围内的自检，说明"点云密度 = 概率密度"）。`;

    if (this.state.slice) this.updateSlice();
    this.drawChart();
  }

  drawChart() {
    drawRadialChart($('chart'), this.info.profile, {
      nodeRadii: this.info.nodeRadii,
      rMostProbable: this.info.rMostProbable,
      meanRadius: this.info.meanRadius,
    });
  }

  resizeChart() {
    if (this.info) this.drawChart();
  }

  /* ------------------------------ 测量 ------------------------------ */

  measureAt(clientX, clientY) {
    const hit = this.view.raycastCloud(clientX, clientY);
    if (!hit) return;
    this.view.addMarker(hit.world, hit.radius);
    const x = hit.world.x / this.viewScale, y = hit.world.y / this.viewScale, z = hit.world.z / this.viewScale;
    $('measureReadout').textContent =
      `测量：r = ${hit.radius.toFixed(2)} a₀ = ${(hit.radius * A0_PM).toFixed(1)} pm `
      + `(x,y,z)=(${x.toFixed(1)}, ${y.toFixed(1)}, ${z.toFixed(1)}) a₀`;
  }

  measureRandom() {
    const { n, l, m } = this.state;
    const p = samplePosition(n, l, m, (Math.random() * 1e9) | 0);
    if (!p) return;
    const world = new THREE.Vector3(p.x * this.viewScale, p.y * this.viewScale, p.z * this.viewScale);
    this.view.addMarker(world, p.r);
    $('measureReadout').textContent =
      `测量：r = ${p.r.toFixed(2)} a₀ = ${(p.r * A0_PM).toFixed(1)} pm `
      + `（单次测量的结果随机散布，多次测量才呈现 |ψ|² 的分布）`;
  }

  /* ------------------------------ 巡览 ------------------------------ */

  toggleTour() {
    this.tour = !this.tour;
    $('btnTour').classList.toggle('on', this.tour);
    this.tourAt = 0;
    this.setStatus(this.tour ? '自动巡览中：每 8 秒切换一个代表性轨道' : '');
  }

  tourStep(dt) {
    if (!this.tour) return;
    this.tourAt += dt;
    if (this.tourAt < 8) return;
    this.tourAt = 0;
    const list = [[1, 0, 0], [2, 0, 0], [2, 1, 0], [3, 2, 0], [3, 2, 2], [4, 3, 0]];
    this.tourIdx = (this.tourIdx + 1) % list.length;
    const [n, l, m] = list[this.tourIdx];
    this.load(n, l, m);
  }

  /* ------------------------------ 杂项 ------------------------------ */

  showLoading(v, text) {
    const el = $('loading');
    el.classList.toggle('hidden', !v);
    if (text) $('loadingText').textContent = text;
  }

  setStatus(t) { $('status').textContent = t; }

  /** 图例随着色方式切换：密度色标 ↔ 相位双色 */
  updateLegend() {
    const el = $('legend');
    if (this.state.phase) {
      el.innerHTML = '<span>波函数相位 ψ 的符号</span>'
        + `<span class="ph"><i class="swatch" style="background:rgb(${PHASE_POS.map((c) => Math.round(c * 255)).join(',')})"></i>ψ &gt; 0</span>`
        + `<span class="ph"><i class="swatch" style="background:rgb(${PHASE_NEG.map((c) => Math.round(c * 255)).join(',')})"></i>ψ &lt; 0</span>`
        + '<span>(亮度仍表示概率密度)</span>';
    } else {
      el.innerHTML = '<span>概率密度</span><span class="bar"></span><span>低 → 高</span>';
    }
  }

  loop() {
    let last = performance.now();
    const tick = () => {
      const now = performance.now();
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      this.view.update(dt);
      this.tourStep(dt);
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }
}

try {
  window.__app = new App();
} catch (err) {
  console.error(err);
  const msg = (err && err.message) || String(err);
  document.body.insertAdjacentHTML('beforeend',
    `<pre style="position:fixed;inset:auto 20px 20px 20px;z-index:99;color:#ff9a9a;background:#180a0a;`
    + `padding:12px 14px;border-radius:8px;font:12px/1.6 ui-monospace,Consolas,monospace;`
    + `white-space:pre-wrap;border:1px solid #5a2020">启动失败：${msg}\n\n`
    + `若提示 WebGL / context，请在支持 WebGL2 的浏览器中打开（Chrome / Edge / Firefox 均可）。</pre>`);
}
