/**
 * server.mjs — 零依赖静态服务器（ES 模块需要 http 协议，file:// 下会被 CORS 拦截）
 *   node server.mjs [port]        默认 5178，端口占用时自动 +1 重试
 */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

export function createServer() {
  return http.createServer((req, res) => {
    const urlPath = decodeURIComponent((req.url || '/').split('?')[0]);
    let rel = urlPath === '/' ? 'index.html' : urlPath.replace(/^\/+/, '');
    const full = path.resolve(ROOT, rel);
    if (!full.startsWith(ROOT)) {                   // 目录穿越防护
      res.writeHead(403).end('forbidden');
      return;
    }
    fs.stat(full, (err, st) => {
      if (err || !st.isFile()) {
        res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }).end('404 not found: ' + rel);
        return;
      }
      res.writeHead(200, {
        'content-type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream',
        'cache-control': 'no-cache',
        'content-length': st.size,
      });
      fs.createReadStream(full).pipe(res);
    });
  });
}

export function listen(port = 5178, attempts = 12) {
  return new Promise((resolve, reject) => {
    const server = createServer();
    server.on('error', (err) => {
      if (err.code === 'EADDRINUSE' && attempts > 0) {
        listen(port + 1, attempts - 1).then(resolve, reject);
      } else reject(err);
    });
    server.listen(port, '127.0.0.1', () => resolve({ server, port }));
  });
}

if (process.argv[1] && process.argv[1].endsWith('server.mjs')) {
  const start = Number(process.argv[2]) || 5178;
  listen(start).then(({ port }) => {
    console.log(`氢原子 3D 模型: http://127.0.0.1:${port}/`);
  }).catch((e) => {
    console.error('启动失败:', e.message);
    process.exit(1);
  });
}
