"""three-body-3d.html 的物理校验脚本（离线，纯标准库）

用途：把 HTML 里内置的预设初始条件与积分方案单独复现一遍，确认它们真的成立，
而不只是“看起来像那么回事”。校验内容：

  1. 8 字轨道（Chenciner–Montgomery）初值的周期与闭合性
  2. 拉格朗日等边三角解的刚性旋转（精确周期解）
  3. 双星 + 飞掠：有界、最近距离安全
  4. 层级三体（双星 + 行星）的长期稳定性
  5. 混沌预设对 1% 初值扰动的敏感性
  6. 自适应步长规则（与页面一致）下的能量漂移与步数预算

运行： python verify_physics.py
"""

import math

# ---------------------------------------------------------------- 通用工具
def acc_of(P, m, G, eps):
    """三个质点的引力加速度（含软化长度 eps）。"""
    A = [[0.0, 0.0, 0.0] for _ in range(3)]
    for i in range(3):
        for j in range(i + 1, 3):
            d = [P[j][c] - P[i][c] for c in range(3)]
            r2 = sum(x * x for x in d) + eps * eps
            inv = 1.0 / (r2 * math.sqrt(r2))
            for c in range(3):
                f = G * d[c] * inv
                A[i][c] += m[j] * f
                A[j][c] -= m[i] * f
    return A


def energy(P, V, m, G, eps):
    ke = 0.5 * sum(m[i] * sum(x * x for x in V[i]) for i in range(3))
    pe = 0.0
    for i in range(3):
        for j in range(i + 1, 3):
            r = math.sqrt(sum((P[j][c] - P[i][c]) ** 2 for c in range(3)) + eps * eps)
            pe -= G * m[i] * m[j] / r
    return ke + pe


def integrate(P, V, m, G, eps, dt, n):
    """速度 Verlet；返回终态与统计量。"""
    P = [list(x) for x in P]
    V = [list(x) for x in V]
    A = acc_of(P, m, G, eps)
    rmax = 0.0
    sepmin = 1e9
    for _ in range(n):
        for i in range(3):
            for c in range(3):
                V[i][c] += 0.5 * dt * A[i][c]
                P[i][c] += dt * V[i][c]
        A = acc_of(P, m, G, eps)
        for i in range(3):
            for c in range(3):
                V[i][c] += 0.5 * dt * A[i][c]
        for i in range(3):
            rmax = max(rmax, math.sqrt(sum(x * x for x in P[i])))
        for i in range(3):
            for j in range(i + 1, 3):
                sepmin = min(sepmin, math.dist(P[i], P[j]))
    return P, V, rmax, sepmin


def com(P, m):
    M = sum(m)
    return [sum(m[i] * P[i][c] for i in range(3)) / M for c in range(3)]


def report(name, P, V, m, G, eps, duration, dt=None):
    E0 = energy(P, V, m, G, eps)
    if dt is None:
        dt = duration / 40000.0
    n = int(duration / dt)
    Pf, Vf, rmax, sepmin = integrate(P, V, m, G, eps, dt, n)
    E1 = energy(Pf, Vf, m, G, eps)
    C0, Cf = com(P, m), com(Pf, m)
    closure = max(math.dist([Pf[i][c] - Cf[c] for c in range(3)],
                            [P[i][c] - C0[c] for c in range(3)]) for i in range(3))
    print("  %-14s T=%-9.3f steps=%-7d | rmax=%-9.1f sepmin=%-8.1f | |dE/E|=%.1e | closure=%.3f"
          % (name, duration, n, rmax, sepmin, abs((E1 - E0) / E0), closure))
    return rmax, sepmin


# ------------------------------------------------- 1) 8 字轨道（放大 + 单位质量）
PC = [[0.97000436, -0.24308753, 0.0], [-0.97000436, 0.24308753, 0.0], [0.0, 0.0, 0.0]]
VC = [[-0.46620369, -0.43236573, 0.0], [-0.46620369, -0.43236573, 0.0],
      [0.93240737, 0.86473146, 0.0]]
print(__doc__.strip().splitlines()[0])
print("\n1) 8 字轨道（经典解 + 精确尺度变换）")
print("   经典解：G=m=1，v0=0.6358，周期 T0=6.326")
print("   尺度变换：x→Kx，v→K√(Gm)·v，T→T0/√(Gm)（角速度 ∝ √(Gm)，与 K 无关）")
for G, m, K in ((1.0, 1.0, 1.0), (1.0, 1.0, 10.0), (100.0, 1.0, 1.0), (100.0, 1.0, 10.0)):
    s = K * math.sqrt(G * m)
    P = [[c * K for c in p] for p in PC]
    V = [[c * s for c in q] for q in VC]
    T = 6.326 / math.sqrt(G * m)
    report("G=%g m=%g K=%g" % (G, m, K), P, V, [m] * 3, G, 0.0, T, dt=T / 4000.0)
print("   结论：要实现该轨道，必须令 m = K²/G（此时 v=K·√(Gm)/√(Gm)… 即 v=K·√G）。")
print("         单位质量、G=100 时，K=√G=10 给出世界尺度 ~11、周期仅 0.63，")
print("         而浏览器每帧最多约 1000 步（每周期需 ~3000 步），因此该轨道")
print("         无法在可观尺度上以交互帧率稳定展示 —— 页面因此改用下面三个预设。")

# ------------------------------------------------- 2) 拉格朗日等边三角解
print("\n2) 拉格朗日等边三角解（页面预设 triangle）")
G, mm, a = 100.0, 6.0, 240.0
R = a / math.sqrt(3.0)
v = math.sqrt(G * mm * math.sqrt(3.0) / a)
P, V = [], []
for i in range(3):
    th = i * 2 * math.pi / 3
    P.append([R * math.cos(th), 0.0, R * math.sin(th)])
    V.append([v * math.sin(th), 0.0, -v * math.cos(th)])
Trot = 2 * math.pi * R / v
print("   R=%.4f  v=%.4f  旋转周期=%.2f" % (R, v, Trot))
report("triangle", P, V, [mm] * 3, G, a * 0.015, 2 * Trot, dt=Trot / 20000.0)

# ------------------------------------------------- 3) 双星 + 飞掠
print("\n3) 双星 + 飞掠（页面预设 sling）")
vb = math.sqrt(100.0 * 30.0 / (2 * 70.0))
P = [[-70, 0, 0], [70, 0, 0], [60, 150, 0]]
V = [[0, 0, -vb], [0, 0, vb], [0, 0, 0]]
report("sling", P, V, [30, 30, 4], 100.0, 6.0, 400.0, dt=0.01)

# ------------------------------------------------- 4) 层级三体：长期稳定性
print("\n4) 双星 + 行星（页面预设 binary）：t=0..3000")
P = [[-90, 0, 0], [90, 0, 0], [0, 0, 420]]
V = [[0, 0, -vb], [0, 0, vb], [-4.35, 0, 0]]
report("binary", P, V, [30, 30, 1], 100.0, 8.0, 3000.0, dt=0.006)

# ------------------------------------------------- 5) 混沌预设的敏感性
print("\n5) 混沌（页面预设 chaos）：初速度 +1% 后的发散")
P = [[130, 40, -40], [-110, -60, 60], [-20, 90, -120]]
V = [[0.5, 0, 1.1], [0.9, 0.4, -0.7], [-1.4, -0.6, 0.2]]
Pa, Va, _, sepmin = integrate(P, V, [10, 6, 4], 100.0, 5.0, 0.006, int(400 / 0.006))
k = 1.01
V2 = [[c * k for c in q] for q in V]
Pb, Vb, _, _ = integrate(P, V2, [10, 6, 4], 100.0, 5.0, 0.006, int(400 / 0.006))
r1 = max(math.sqrt(sum(x * x for x in Pa[i])) for i in range(3))
print("   t=400 时有界（rmax=%.1f），最近距离 %.1f" % (r1, sepmin))
print("   +1%% 初速度 → 位置偏差 %.2f 世界单位（混沌放大）"
      % max(math.dist(Pa[i], Pb[i]) for i in range(3)))

# ------------------------------------------------- 6) 页面自适应步长规则
print("\n6) 页面自适应步长 dt = min(eta·√(ε/amax), 0.06·max(ε,sep)/vmax) 的实际表现")


def browser_run(P, V, m, G, eps, duration, eta=0.06):
    """完整复现页面的步进 + 能量统计。"""
    P = [list(x) for x in P]
    V = [list(x) for x in V]
    A = acc_of(P, m, G, eps)
    E0 = energy(P, V, m, G, eps)
    t = 0.0
    steps = 0
    rmax = 0.0
    sepmin = 1e9
    while t < duration:
        amax = max(math.sqrt(sum(x * x for x in a)) for a in A)
        vmax = max(math.sqrt(sum(x * x for x in v)) for v in V)
        sep = min(math.dist(P[i], P[j]) for i in range(3) for j in range(i + 1, 3))
        dt = min(eta * math.sqrt(eps / max(amax, 1e-12)), 0.06 * max(eps, sep) / max(vmax, 1e-12))
        dt = max(dt, eps / 20000)
        for i in range(3):
            for c in range(3):
                V[i][c] += 0.5 * dt * A[i][c]
                P[i][c] += dt * V[i][c]
        A = acc_of(P, m, G, eps)
        for i in range(3):
            for c in range(3):
                V[i][c] += 0.5 * dt * A[i][c]
        t += dt
        steps += 1
        rmax = max(rmax, max(math.sqrt(sum(x * x for x in P[i])) for i in range(3)))
        sepmin = min(sepmin, sep)
    E1 = energy(P, V, m, G, eps)
    return steps, t / steps, rmax, sepmin, abs((E1 - E0) / E0)


G, mm, a = 100.0, 6.0, 240.0
R = a / math.sqrt(3.0)
v = math.sqrt(G * mm * math.sqrt(3.0) / a)
Ptri, Vtri = [], []
for i in range(3):
    th = i * 2 * math.pi / 3
    Ptri.append([R * math.cos(th), 0.0, R * math.sin(th)])
    Vtri.append([v * math.sin(th), 0.0, -v * math.cos(th)])

cases = {
    "triangle": (Ptri, Vtri, [mm] * 3, 138.6, 2.0),
    "sling": ([[-70, 0, 0], [70, 0, 0], [60, 150, 0]],
              [[0, 0, -vb], [0, 0, vb], [0, 0, 0]], [30, 30, 4], 150.0, 2.0),
    "binary": ([[-90, 0, 0], [90, 0, 0], [0, 0, 420]],
               [[0, 0, -vb], [0, 0, vb], [-4.35, 0, 0]], [30, 30, 1], 330.0, 2.0),
    "chaos": ([[130, 40, -40], [-110, -60, 60], [-20, 90, -120]],
              [[0.5, 0, 1.1], [0.9, 0.4, -0.7], [-1.4, -0.6, 0.2]], [10, 6, 4], 120.0, 2.0),
}
for name, (Px, Vx, mx, ir, mult) in cases.items():
    eps = ir * 0.015
    # 与页面一致：预设自带的时间流速（triangle 1.6×、sling 2.6×、binary 3×、chaos 1.2×），
    # 这里统一用 timeScale=2 观察 60 秒墙钟时间内的模拟量与漂移
    dur = 60.0 * mult
    steps, dt, rmax, sepmin, drift = browser_run(Px, Vx, mx, 100.0, eps, dur)
    print("  %-9s ε=%-6.2f 模拟 %-6.1f 时间单位用了 %-6d 步（dt≈%.4f）"
          "| rmax=%-8.1f sepmin=%-7.1f | |dE/E|=%.1e"
          % (name, eps, dur, steps, dt, rmax, sepmin, drift))
