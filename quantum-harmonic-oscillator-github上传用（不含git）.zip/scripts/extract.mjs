/**
 * scripts/extract.mjs — 从 index.html 里抽出内联 <script>，用于 `node --check` 静态语法检查。
 *   node scripts/extract.mjs <index.html> <out.js>
 * 不依赖任何第三方库。
 */
import fs from 'node:fs';

const [, , src, out] = process.argv;
if (!src || !out) {
  console.error('用法: node scripts/extract.mjs <index.html> <out.js>');
  process.exit(2);
}
const html = fs.readFileSync(src, 'utf8');
const m = html.match(/<script>([\s\S]*?)<\/script>/);
if (!m) { console.error('未找到内联 <script> 块'); process.exit(2); }
fs.writeFileSync(out, m[1]);
console.log(`已抽出 ${m[1].length} 字符 → ${out}`);
