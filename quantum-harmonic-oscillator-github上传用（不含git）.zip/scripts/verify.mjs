/**
 * scripts/verify.mjs — 无头 Edge + CDP：把页面真正跑起来，
 * 用 window.__app 校验物理正确性，并输出截图。
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';

const ROOT = path.resolve(import.meta.dirname, '..');
const PAGE = 'file:///' + path.join(ROOT, 'index.html').replace(/\\/g, '/');
const SHOTS = path.join(ROOT, 'docs');
fs.mkdirSync(SHOTS, { recursive: true });

const EDGE = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
].find(p => fs.existsSync(p));
if (!EDGE) { console.error('找不到 Edge/Chrome'); process.exit(2); }

const PORT = '9333';
const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'qho-'));
const child = spawn(EDGE, [
  '--headless=new', `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--disable-extensions',
  '--use-angle=swiftshader', '--enable-unsafe-swiftshader',
  '--window-size=1600,900', '--hide-scrollbars', 'about:blank',
], { stdio: 'ignore', detached: false });

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function findWs() {
  for (let i = 0; i < 60; i++) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/version`);
      const j = await r.json();
      if (j.webSocketDebuggerUrl) return j.webSocketDebuggerUrl;
    } catch { /* not up yet */ }
    await sleep(400);
  }
  throw new Error('浏览器调试端口未就绪');
}

let msgId = 0;
function rpc(ws, method, params = {}, sessionId) {
  const id = ++msgId;
  return new Promise((resolve, reject) => {
    const onMsg = ev => {
      const m = JSON.parse(ev.data);
      if (m.id === id) {
        ws.removeEventListener('message', onMsg);
        m.error ? reject(new Error(method + ': ' + m.error.message)) : resolve(m.result);
      }
    };
    ws.addEventListener('message', onMsg);
    ws.send(JSON.stringify({ id, method, params, sessionId }));
    setTimeout(() => { ws.removeEventListener('message', onMsg); reject(new Error('timeout ' + method)); }, 60000);
  });
}

const wsUrl = await findWs();
const ws = new WebSocket(wsUrl);
await new Promise((r, j) => { ws.addEventListener('open', r); ws.addEventListener('error', j); });

const logs = [];
ws.addEventListener('message', ev => {
  const m = JSON.parse(ev.data);
  if (m.method === 'Runtime.consoleAPICalled')
    logs.push('[console] ' + (m.params.args || []).map(a => a.value ?? a.description).join(' '));
  if (m.method === 'Runtime.exceptionThrown')
    logs.push('[EXCEPTION] ' + (m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text));
  if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error')
    logs.push('[log] ' + m.params.entry.text);
});

const { targetId } = await rpc(ws, 'Target.createTarget', { url: 'about:blank' });
const { sessionId } = await rpc(ws, 'Target.attachToTarget', { targetId, flatten: true });
const S = (m, p) => rpc(ws, m, p, sessionId);
await S('Runtime.enable'); await S('Log.enable'); await S('Page.enable');
await S('Emulation.setDeviceMetricsOverride', { width: 1600, height: 900, deviceScaleFactor: 1, mobile: false });
await S('Page.navigate', { url: PAGE });
await sleep(3500);

async function probe(expr) {
  const r = await S('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result.value;
}
async function shot(name) {
  const r = await S('Page.captureScreenshot', { format: 'png' });
  const f = path.join(SHOTS, name);
  fs.writeFileSync(f, Buffer.from(r.data, 'base64'));
  return f;
}

const ready = await probe('!!(window.__app && window.__app.ready)');
if (!ready) {
  console.error('页面未就绪。日志：\n' + logs.join('\n'));
  process.exit(1);
}

/* ── 在页面里跑一组物理断言，返回结构化结果 ── */
const report = await probe(`(() => {
  const A = window.__app, out = [];
  const ok = (name, got, want, tol) => out.push({
    name, got:+got.toFixed(8), want:+want.toFixed(8), tol,
    pass: Math.abs(got-want) <= tol,
  });

  /* 1. 本征态归一化与正交性 */
  const norm = [], orth = [0,0];
  for (let n=0;n<=12;n++){
    let s=0; for(let i=0;i<=A.GN;i++) s += A.PSI2[n][i];
    norm.push(s*A.DX);
  }
  ok('∫|ψ₀|²dx = 1', norm[0], 1, 1e-9);
  ok('∫|ψ₅|²dx = 1', norm[5], 1, 1e-8);
  ok('∫|ψ₁₂|²dx = 1', norm[12], 1, 1e-7);
  { let s=0; for(let i=0;i<=A.GN;i++) s += A.PSI[0][i]*A.PSI[1][i]; orth[0]=s*A.DX; }
  { let s=0; for(let i=0;i<=A.GN;i++) s += A.PSI[3][i]*A.PSI[7][i]; orth[1]=s*A.DX; }
  ok('⟨0|1⟩ = 0', orth[0], 0, 1e-9);
  ok('⟨3|7⟩ = 0', orth[1], 0, 1e-8);

  /* 2. 能量本征值 */
  A.setSingle(0); let m = A.moments(0); ok('基态 ⟨E⟩ = 0.5', m.H, 0.5, 1e-12);
  A.setSingle(4); m = A.moments(0);     ok('|4⟩ ⟨E⟩ = 4.5', m.H, 4.5, 1e-12);

  /* 3. 基态最小不确定度：Δx=Δp=1/√2 */
  A.setSingle(0); m = A.moments(0);
  ok('基态 Δx = 1/√2', m.dx, Math.SQRT1_2, 1e-10);
  ok('基态 Δp = 1/√2', m.dp, Math.SQRT1_2, 1e-10);
  ok('基态 ΔxΔp = ħ/2', m.prod, 0.5, 1e-12);

  /* 4. 相干态 |α⟩：⟨x⟩(t)=√2α·cos t，Δx=Δp=1/√2，⟨E⟩=α²+½ */
  A.setCoherent(2.0); A.applyCoef(false);
  m = A.moments(0);
  ok('相干态 ⟨x⟩(0) = 2√2', m.X, 2*Math.SQRT2, 1e-9);
  ok('相干态 ⟨E⟩ = α²+½', m.H, 4.5, 1e-9);
  ok('相干态 ΔxΔp = ħ/2', m.prod, 0.5, 1e-9);
  const Xs = [0,0.7,1.9,3.3].map(t => A.moments(t).X);
  const want = [0,0.7,1.9,3.3].map(t => 2*Math.SQRT2*Math.cos(t));
  let maxerr = 0; for (let i=0;i<Xs.length;i++) maxerr = Math.max(maxerr, Math.abs(Xs[i]-want[i]));
  out.push({name:'相干态 ⟨x⟩(t) 追随经典 x=√2α·cos t', got:+maxerr.toExponential(2), want:0, tol:1e-8, pass:maxerr<1e-8});

  /* 5. 压缩真空：Δx=(1/√2)e^{-r}, Δp=(1/√2)e^{r}, 乘积仍为 ħ/2 */
  A.setSqueezed(1.0); A.applyCoef(false);
  m = A.moments(0);
  ok('压缩 r=1 Δx = e⁻¹/√2', m.dx, Math.exp(-1)*Math.SQRT1_2, 1e-9);
  ok('压缩 r=1 Δp = e¹/√2',  m.dp, Math.exp( 1)*Math.SQRT1_2, 1e-9);
  ok('压缩态 ΔxΔp = ħ/2',   m.prod, 0.5, 1e-9);
  ok('压缩态 ⟨x⟩ = 0',       m.X, 0, 1e-9);

  /* 5b. 压缩真空随时间"呼吸"：Δx²(t)=½(cosh2r−sinh2r·cos2t)，Δp²(t)=½(cosh2r+sinh2r·cos2t)
         —— 噪声椭圆在相空间转动，只有轴对齐时刻 (t=0, π/2, …) 才取到 ΔxΔp = ħ/2
         残差 ~1e-7 来自 NMAX=96 对 sinh²r 高能尾部的截断，不是算法误差 */
  {
    const r = 1.2, TOL = 2e-6;
    A.setSqueezed(r); A.applyCoef(false);
    const c2 = Math.cosh(2*r), s2 = Math.sinh(2*r);
    let e1=0, e2=0, e3=0;
    for (const t of [0, 0.4, Math.PI/4, Math.PI/2, 2.3]){
      const mm = A.moments(t);
      e1 = Math.max(e1, Math.abs(mm.dx - Math.sqrt(0.5*(c2 - s2*Math.cos(2*t)))));
      e2 = Math.max(e2, Math.abs(mm.dp - Math.sqrt(0.5*(c2 + s2*Math.cos(2*t)))));
      e3 = Math.max(e3, Math.abs(mm.prod - 0.5*Math.sqrt(c2*c2 - s2*s2*Math.cos(2*t)**2)));
    }
    out.push({name:'压缩态 Δx(t) 呼吸曲线（残差=截断）', got:+e1.toExponential(2), want:0, tol:TOL, pass:e1<TOL});
    out.push({name:'压缩态 Δp(t) 呼吸曲线（残差=截断）', got:+e2.toExponential(2), want:0, tol:TOL, pass:e2<TOL});
    out.push({name:'压缩态 ΔxΔp(t) = ½√(cosh²2r−sinh²2r·cos²2t)', got:+e3.toExponential(2), want:0, tol:TOL, pass:e3<TOL});
    const pmin = Math.min(...[0,Math.PI/2,Math.PI].map(t=>A.moments(t).prod));
    const pmax = A.moments(Math.PI/4).prod;
    out.push({name:'压缩态 ΔxΔp 最小值 = ħ/2，最大值 = ½cosh2r',
              got: pmin.toFixed(9)+' … '+pmax.toFixed(6), want:'0.5 … '+(0.5*Math.cosh(2*r)).toFixed(6),
              tol:TOL, pass: Math.abs(pmin-0.5)<TOL && Math.abs(pmax-0.5*Math.cosh(2*r))<TOL});
  }

  /* 6. 叠加态 |0⟩+|1⟩：⟨x⟩(t) = (1/√2)cos t */
  A.setEqual([0,1]); A.applyCoef(false);
  ok('(|0⟩+|1⟩) ⟨E⟩ = 1.0', A.moments(0).H, 1.0, 1e-12);
  ok('(|0⟩+|1⟩) ⟨x⟩(π) = −1/√2', A.moments(Math.PI).X, -Math.SQRT1_2, 1e-10);

  /* 7. 波函数场与系数展开一致：ψ(x,t) = Σ cₙψₙ(x)e^{−iEₙt} */
  A.setEqual([0,2,5]); A.applyCoef(false);
  const t0 = 1.234;
  A.evalPsi(t0);
  const NMAX = 28, re0 = A.psiRe, im0 = A.psiIm;
  const inv = 1/Math.sqrt(3);
  let err2 = 0;
  for (let i=0;i<=A.GN;i+=7){
    let r=0, im=0;
    for (const n of [0,2,5]){
      const th = -(n+0.5)*t0;
      r  += inv*A.PSI[n][i]*Math.cos(th);
      im += inv*A.PSI[n][i]*Math.sin(th);
    }
    err2 = Math.max(err2, Math.abs(r-re0[i]), Math.abs(im-im0[i]));
  }
  out.push({name:'波函数场 = 本征态展开', got:+err2.toExponential(2), want:0, tol:1e-12, pass:err2<1e-12});

  /* 8. 归一化守恒（长时间演化后 ∫|ψ|²=1） */
  let worst = 0;
  for (const t of [0, 1.7, 5.5, 23.1, 100.0]){
    A.evalPsi(t);
    let s=0; for (let i=0;i<=A.GN;i++) s += A.psi2[i];
    worst = Math.max(worst, Math.abs(s*A.DX - 1));
  }
  out.push({name:'演化中 ∫|ψ|²dx ≡ 1', got:+worst.toExponential(2), want:0, tol:1e-9, pass:worst<1e-9});

  /* 9. 厄米多项式节点数：ψₙ 应有 n 个零点（跳过精确为零的网格点，否则漏掉 x=0 处的节点） */
  const nodes = [];
  for (const n of [1,3,6,10,17]){
    let c=0, prev=0;
    for (let i=0;i<=A.GN;i++){
      const v = A.PSI[n][i];
      if (Math.abs(v) < 1e-13) continue;
      if (prev !== 0 && (v>0) !== (prev>0)) c++;
      prev = v;
    }
    nodes.push([n,c]);
  }
  out.push({name:'ψₙ 零点数 = n', got:nodes.map(x=>x[1]).join(','), want:'1,3,6,10,17',
            tol:0, pass: nodes.every(x=>x[0]===x[1])});

  /* 10. 对应原理：高激发态的累积分布 → 经典累积分布 (1/π)(arcsin(x/A)+π/2) */
  const cdfErr = [];
  for (const n of [8, 16, 32]){
    A.setSingle(n); A.applyCoef(false); A.evalPsi(0);
    const Ac = Math.sqrt(2*(n+0.5));
    const xs = A.xs, p2 = A.psi2;
    let tot=0;
    for(let i=0;i<A.GN;i++){
      const xm=xs[i], xp=xs[i+1];
      if (xm < -Ac || xp > Ac) continue;
      tot += 0.5*(p2[i]+p2[i+1])*A.DX;
    }
    let cum=0, mx=0;
    for(let i=0;i<A.GN;i++){
      const xm=xs[i], xp=xs[i+1];
      if (xm < -Ac || xp > Ac) continue;
      cum += 0.5*(p2[i]+p2[i+1])*A.DX;
      const Fc = (Math.asin(Math.max(-1,Math.min(1,xp/Ac))) + Math.PI/2)/Math.PI;
      mx = Math.max(mx, Math.abs(cum/tot - Fc));
    }
    cdfErr.push([n, mx]);
  }
  out.push({name:'n=8,16,32 累积分布 ≈ 经典 (max|ΔF|)',
            got: cdfErr.map(x=>x[1].toFixed(4)).join(','), want:'<0.08',
            tol:0.08, pass: cdfErr.every(x=>x[1] < 0.08)});
  out.push({name:'  对应原理误差随 n 单调减小',
            got: (cdfErr[0][1] > cdfErr[1][1] && cdfErr[1][1] > cdfErr[2][1]) ? 'yes':'no',
            want:'yes', tol:0, pass: cdfErr[0][1] > cdfErr[1][1] && cdfErr[1][1] > cdfErr[2][1]});

  /* 复原默认态 */
  A.setSingle(0); A.applyCoef(true);
  return out;
})()`);

console.log('\n══ 物理校验（在真实页面中运行） ══\n');
let fail = 0;
for (const r of report) {
  if (!r.pass) fail++;
  const mark = r.pass ? '  PASS' : '  FAIL';
  console.log(`${mark}  ${r.name.padEnd(42)} 得到=${String(r.got).padStart(14)}  期望=${r.want}${r.tol ? ' ±'+r.tol : ''}`);
}
console.log(`\n${report.length - fail}/${report.length} 通过`);

/* ── 各视角截图（直接产出 docs/ 里用于 README 的图） ── */
await probe('__app.pause(); __app.seek(0.9); __app.setView(0.95,0.34)');
await probe('__app.setSingle(0)');
await sleep(900);
const shots = [];
shots.push(await shot('screenshot-ladder-ground.png'));

await probe('__app.setEqual([0,1,2,3,4,5,6]); __app.applyCoef(true)');
await probe('__app.S.nShow=8; __app.refit(false); __app.setView(0.42,0.30)');
await probe('__app.seek(0.6)');
await sleep(1000);
shots.push(await shot('screenshot-ladder-superposition.png'));

await probe('__app.setMode("packet"); __app.setCoherent(2.0); __app.applyCoef(true)');
await probe('__app.setView(0.95,0.30)');
await probe('__app.seek(1.1)');
await sleep(1100);
shots.push(await shot('preview.png'));
fs.copyFileSync(path.join(SHOTS, 'preview.png'), path.join(SHOTS, 'screenshot-packet-coherent.png'));

await probe('__app.setView(1.50,0.10)');   // 正对 x-y 面：就是课本上的 ψ(x) 图
await sleep(900);
shots.push(await shot('screenshot-textbook-view.png'));

await probe('__app.setView(0.95,0.30); __app.setSqueezed(1.2); __app.applyCoef(true)');
await probe('__app.seek(0.4)');
await sleep(1000);
shots.push(await shot('screenshot-packet-squeezed.png'));

await probe('__app.setMode("ladder"); __app.setSingle(3); __app.S.nShow=8; __app.refit(true)');
await probe('__app.seek(0.35)');
await sleep(1000);
shots.push(await shot('screenshot-ladder-n3.png'));

/* 复原默认态 */
await probe('__app.S.nShow=6; __app.setSingle(0); __app.refit(true); __app.seek(0)');

/* ── UI 交互冒烟测试：把每个控件都真的点一遍，看是否有异常 ── */
const ui = await probe(`(() => {
  const notes = [];
  const click = el => el.dispatchEvent(new MouseEvent('click',{bubbles:true}));
  const setv = (el,v) => { el.value = v; el.dispatchEvent(new Event('input',{bubbles:true})); };
  try {
    for (const b of [...document.getElementById('presets').children]) click(b);
    for (const c of [...document.getElementById('chips').children]) click(c);          // 全开
    for (const c of [...document.getElementById('chips').children]) click(c);          // 全关
    const t1 = [...document.querySelectorAll('#togs input')];
    for (const t of t1){ t.checked=!t.checked; t.dispatchEvent(new Event('change',{bubbles:true})); }
    const t2 = [...document.querySelectorAll('#togs input')];
    for (const t of t2){ t.checked=!t.checked; t.dispatchEvent(new Event('change',{bubbles:true})); }
    setv(document.getElementById('nShow'), 10);
    setv(document.getElementById('nShow'), 2);
    setv(document.getElementById('spd'), 2.5);
    setv(document.getElementById('rot'), 0);
    click(document.querySelector('#modeSeg button[data-mode="packet"]'));
    click(document.querySelector('#modeSeg button[data-mode="ladder"]'));
    document.querySelectorAll('#coefs input[type=range]').forEach((r,i)=> setv(r, (i%2)?'0.5':'-90'));
    const pr = document.querySelectorAll('#params input[type=range]');
    setv(pr[0], '3.0'); setv(pr[1], '1.4');
    click(document.getElementById('playBtn')); click(document.getElementById('playBtn'));
    click(document.getElementById('resetBtn')); click(document.getElementById('viewBtn')); click(document.getElementById('topBtn'));
  } catch(e){ notes.push('EXCEPTION: '+e.message); }
  const errEl = document.getElementById('err');
  return { notes, errShown: errEl.style.display === 'block', errText: errEl.textContent.slice(0,400),
           counts:{presets:document.getElementById('presets').children.length,
                   chips:document.getElementById('chips').children.length,
                   togs:document.querySelectorAll('#togs input').length,
                   coefRows:document.querySelectorAll('#coefs .crow').length} };
})()`);

/* 真实指针拖拽（轨道相机） */
await S('Input.dispatchMouseEvent', {type:'mousePressed', x:820, y:300, button:'left', clickCount:1});
for (let i=1;i<=6;i++) await S('Input.dispatchMouseEvent', {type:'mouseMoved', x:820+i*22, y:300+i*9, button:'left'});
await S('Input.dispatchMouseEvent', {type:'mouseReleased', x:952, y:354, button:'left', clickCount:1});
await sleep(700);
const afterDrag = await probe('({az:__app.cam.az, el:__app.cam.el, err:document.getElementById("err").style.display})');

console.log('\n══ UI 交互冒烟 ══');
console.log('  控件数量: ' + JSON.stringify(ui.counts));
console.log('  脚本异常: ' + (ui.notes.length ? ui.notes.join(' | ') : '无'));
console.log('  错误面板: ' + (ui.errShown ? '出现 → ' + ui.errText : '未出现'));
console.log('  拖拽后相机: az=' + afterDrag.az.toFixed(3) + ' el=' + afterDrag.el.toFixed(3) +
            '（初始 0.950 / 0.340 → 拖拽生效）');
if (ui.notes.length || ui.errShown || afterDrag.err === 'block') fail++;

const stats = await probe('JSON.stringify(__app.stats())');
console.log('\n渲染统计: ' + stats);
console.log('截图: ' + shots.map(s => path.basename(s)).join(', '));

if (logs.length) { console.log('\n浏览器日志:\n' + logs.slice(0, 40).join('\n')); }
else console.log('\n浏览器日志: 无错误');

await S('Page.close').catch(() => {});
ws.close();
child.kill();
try { fs.rmSync(profile, { recursive: true, force: true }); } catch {}
process.exit(fail ? 1 : 0);
