/**
 * scripts/make-zip.mjs — 生成两个分发用 zip（跨平台规范：条目名一律用 / 分隔）
 *   node scripts/make-zip.mjs
 *     A) quantum-harmonic-oscillator-github完整仓库（含git）.zip  —— 含 .git，解压后可直接 git push
 *     B) quantum-harmonic-oscillator-github上传用（不含git）.zip  —— 用于浏览器拖拽上传
 *
 * 注意：.NET 的 ZipFile.CreateFromDirectory 在 Windows 上写入的是反斜杠分隔符，
 * 不合 ZIP 规范（APPNOTE 4.4.17.1 要求正斜杠），在 macOS/Linux 上解压会得到
 * 名字里带反斜杠的文件。这里手写条目名以保证跨平台正确。
 */
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

const ROOT = path.resolve(import.meta.dirname, '..');
const REPO = ROOT;
const OUT_DIR = path.resolve(ROOT, '..');
const SLUG = 'quantum-harmonic-oscillator';

/* ------------------------------ CRC32 ------------------------------ */
const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();
function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

/** 极简 ZIP 写入器：deflate + 中央目录，条目名强制 / 分隔 */
class ZipWriter {
  constructor() { this.chunks = []; this.central = []; this.offset = 0; }
  add(name, data) {
    const nameBuf = Buffer.from(name.replace(/\\/g, '/'), 'utf8');
    const crc = crc32(data);
    const comp = zlib.deflateRawSync(data, { level: 9 });
    const useStore = comp.length >= data.length;
    const body = useStore ? data : comp;
    const method = useStore ? 0 : 8;

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);            // version needed
    local.writeUInt16LE(0x0800, 6);        // UTF-8 名字标志
    local.writeUInt16LE(method, 8);
    local.writeUInt16LE(0, 10);            // time
    local.writeUInt16LE(0x21, 12);         // date = 1980-01-01
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(body.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(nameBuf.length, 26);
    local.writeUInt16LE(0, 28);
    this.chunks.push(local, nameBuf, body);

    const cen = Buffer.alloc(46);
    cen.writeUInt32LE(0x02014b50, 0);
    cen.writeUInt16LE(20, 4);
    cen.writeUInt16LE(20, 6);
    cen.writeUInt16LE(0x0800, 8);
    cen.writeUInt16LE(method, 10);
    cen.writeUInt16LE(0, 12);
    cen.writeUInt16LE(0x21, 14);
    cen.writeUInt32LE(crc, 16);
    cen.writeUInt32LE(body.length, 20);
    cen.writeUInt32LE(data.length, 24);
    cen.writeUInt16LE(nameBuf.length, 28);
    cen.writeUInt32LE(0, 38);              // external attrs
    cen.writeUInt32LE(this.offset, 42);
    this.central.push(cen, nameBuf);

    this.offset += local.length + nameBuf.length + body.length;
  }
  finish(file) {
    const cenBuf = Buffer.concat(this.central);
    const end = Buffer.alloc(22);
    end.writeUInt32LE(0x06054b50, 0);
    end.writeUInt16LE(this.central.length / 2, 8);
    end.writeUInt16LE(this.central.length / 2, 10);
    end.writeUInt32LE(cenBuf.length, 12);
    end.writeUInt32LE(this.offset, 16);
    end.writeUInt16LE(0, 20);
    fs.writeFileSync(file, Buffer.concat([...this.chunks, cenBuf, end]));
  }
}

/** 递归收集文件（exclude 用于跳过 .git） */
function walk(dir, base = '', out = [], { exclude = null } = {}) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (exclude && exclude(e.name)) continue;
    const rel = base ? `${base}/${e.name}` : e.name;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) walk(full, rel, out, { exclude });
    else if (e.isFile()) out.push({ rel, full });
  }
  return out;
}

function build(outFile, { withGit }) {
  const files = walk(REPO, '', [], { exclude: withGit ? null : (n) => n === '.git' });
  files.sort((a, b) => a.rel.localeCompare(b.rel));
  const w = new ZipWriter();
  for (const f of files) w.add(f.rel, fs.readFileSync(f.full));
  w.finish(outFile);
  return { count: files.length, bytes: fs.statSync(outFile).size };
}

const A = path.join(OUT_DIR, `${SLUG}-github完整仓库（含git）.zip`);
const B = path.join(OUT_DIR, `${SLUG}-github上传用（不含git）.zip`);
for (const f of [A, B]) if (fs.existsSync(f)) fs.unlinkSync(f);

const ra = build(A, { withGit: true });
const rb = build(B, { withGit: false });
const mb = (n) => (n / 1024 / 1024).toFixed(2) + ' MB';
console.log(`A) ${path.basename(A)}`);
console.log(`   ${ra.count} 个文件  ${mb(ra.bytes)}   —— 解压后可直接 git push`);
console.log(`B) ${path.basename(B)}`);
console.log(`   ${rb.count} 个文件  ${mb(rb.bytes)}   —— 浏览器拖拽上传用`);
console.log('条目名统一使用 / 分隔，跨平台可解压。');
