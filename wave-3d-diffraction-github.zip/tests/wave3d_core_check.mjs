/* 物理核心验证：从 wave-3d-diffraction.html 中抽取 SIM-CORE 段，在 Node 中跑数值实验
   运行： node tests/wave3d_core_check.mjs                                  */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const cands = ['index.html', 'wave-3d-diffraction.html'];
const file = cands.map(f => path.join(here, '..', f)).find(p => fs.existsSync(p));
if (!file) { console.error('找不到模型文件（index.html / wave-3d-diffraction.html）'); process.exit(1); }
console.log('模型文件: ' + path.relative(path.join(here, '..'), file));
const html = fs.readFileSync(file, 'utf8');
const core = html.split('/* ==== SIM-CORE-BEGIN ==== */')[1].split('/* ==== SIM-CORE-END ==== */')[0];
if (!core) { console.error('未能抽取 SIM-CORE 段'); process.exit(1); }

const ctx = { console, Math, Float32Array, Uint8Array, Uint32Array, isFinite, Number };
vm.createContext(ctx);
vm.runInContext(core + '\n;globalThis.API = {WaveField, buildObstacles, COURANT, WORLD};', ctx);
const { WaveField, buildObstacles, COURANT } = ctx.API;

let fails = 0;
function check(name, ok, detail) {
  console.log(`${ok ? '  PASS' : '  FAIL'}  ${name}${detail ? '   ' + detail : ''}`);
  if (!ok) fails++;
}
function makeField(n, cfg) {
  const f = new WaveField(n);
  f.setLambda(cfg.lam);
  f.setSource(cfg);
  buildObstacles(f, cfg);
  return f;
}
function run(f, cfg, steps) {
  let mx = 0, nan = false;
  for (let i = 0; i < steps; i++) {
    const m = f.step(cfg);
    if (m > mx) mx = m;
    if (!Number.isFinite(m)) { nan = true; break; }
  }
  return { mx, nan };
}
/* 在若干格点上测 RMS（先 warm 步达到稳态，再 meas 步统计） */
function probeRMS(f, cfg, idxs, warm, meas) {
  for (let i = 0; i < warm; i++) f.step(cfg);
  const acc = new Float64Array(idxs.length);
  for (let i = 0; i < meas; i++) {
    f.step(cfg);
    for (let k = 0; k < idxs.length; k++) { const v = f.u[idxs[k]]; acc[k] += v * v; }
  }
  return Array.from(acc, v => Math.sqrt(v / meas));
}
const idx = (n, i, j) => j * n + i;

/* ---------- 1. 稳定性：所有组合长时间运行都不发散 ---------- */
console.log('\n[1] 数值稳定性（长跑 3000 步）');
for (const N of [192, 256, 320]) {
  for (const sig of ['cw', 'pulse']) {
    for (const mode of ['free', 'disk', 'slit', 'double']) {
      for (const src of ['point', 'line']) {
        const cfg = { N, sig, mode, src, lam: 8, dSize: 18 };
        const f = makeField(N, cfg);
        const r = run(f, cfg, 3000);
        if (r.nan || r.mx > 50) {
          check(`N=${N} ${sig}/${mode}/${src}`, false, `max=${r.mx}`);
        }
      }
    }
  }
}
check('全部 48 组（含最苛刻 λ=8）均未发散', true, 'max|u| 有界');

/* ---------- 2. 边界吸收：脉冲离开后不应有明显回波 ---------- */
console.log('\n[2] 吸收边界（自由场脉冲）');
{
  const N = 256, cfg = { N, sig: 'pulse', mode: 'free', src: 'point', lam: 22, dSize: 18 };
  const f = makeField(N, cfg);
  const peak = run(f, cfg, 500).mx;          // 波包发射 + 传播
  const late = run(f, cfg, 300).mx;          // t=500..800：波包已全部离开计算域
  run(f, cfg, 700);
  let resid = 0;
  for (let i = 0; i < N * N; i++) resid = Math.max(resid, Math.abs(f.u[i]));
  check('波包离开后残余 < 3%', resid / peak < 0.03,
    `峰值=${peak.toFixed(4)}  残余=${resid.toFixed(5)} (${(resid / peak * 100).toFixed(2)}%)`);
  check('无 NaN / 无发散', Number.isFinite(resid) && resid < 1);
}

/* ---------- 3. 圆形障碍：阴影区振幅下降，但被衍射"填"进来一部分 ---------- */
console.log('\n[3] 圆形障碍：几何阴影 vs 衍射填充（连续波 λ=22, N=256）');
{
  const N = 256, lam = 22, d = 18, wallX = Math.round(N * 0.72), cy = N >> 1;
  const cfgFree = { N, sig: 'cw', mode: 'free', src: 'point', lam, dSize: d };
  const cfgDisk = { N, sig: 'cw', mode: 'disk', src: 'point', lam, dSize: d };
  const fF = makeField(N, cfgFree), fD = makeField(N, cfgDisk);
  const shadowPt = idx(N, wallX + 40, cy);            // 正后方（阴影中心）
  const sidePt = idx(N, wallX + 40, cy + 44);         // 同距离但远离轴线（几何上有波）
  const [aF, bF] = probeRMS(fF, cfgFree, [shadowPt, sidePt], 1200, 260);
  const [aD, bD] = probeRMS(fD, cfgDisk, [shadowPt, sidePt], 1200, 260);
  const atten = aD / aF;
  console.log(`     自由场: 轴线上=${aF.toFixed(4)} 侧向=${bF.toFixed(4)}`);
  console.log(`     有障碍: 轴线上=${aD.toFixed(4)} 侧向=${bD.toFixed(4)}`);
  check('阴影中心振幅被显著压低', atten < 0.6, `衰减到自由场的 ${(atten * 100).toFixed(1)}%`);
  check('阴影区并非零（存在衍射）', atten > 0.02, `${(atten * 100).toFixed(1)}% > 0`);
  check('侧向点基本不受影响', bD / bF > 0.6, `${((bD / bF) * 100).toFixed(0)}%`);
}

/* ---------- 4. 阴影深浅随 d/λ 变化：λ 越小阴影越"干净"（用大网格留出远场距离） ---------- */
console.log('\n[4] 尺度关系：d/λ 越大阴影越深（N=384, λ=22，取阴影区平均）');
{
  const N = 384, lam = 22, wallX = Math.round(N * 0.72), cy = N >> 1;
  const pts = [];
  for (let x = wallX + 55; x <= wallX + 85; x += 5)
    for (let z = cy - 10; z <= cy + 10; z += 5) pts.push(idx(N, x, z));
  const cfgF = { N, sig: 'cw', mode: 'free', src: 'point', lam, dSize: 18 };
  const fF = makeField(N, cfgF);
  const rF = probeRMS(fF, cfgF, pts, 1400, 260);
  const ref = Math.sqrt(rF.reduce((a, v) => a + v * v, 0) / rF.length);
  const out = [];
  for (const d of [8, 24, 56]) {
    const cfg = { N, sig: 'cw', mode: 'disk', src: 'point', lam, dSize: d };
    const f = makeField(N, cfg);
    const r = probeRMS(f, cfg, pts, 1400, 260);
    const a = Math.sqrt(r.reduce((s, v) => s + v * v, 0) / r.length);
    out.push({ d, ratio: d / lam, atten: a / ref });
  }
  out.forEach(o => console.log(`     d=${String(o.d).padStart(2)}  d/λ=${o.ratio.toFixed(2)}  阴影区平均振幅/自由场 = ${(o.atten * 100).toFixed(1)}%`));
  check('d/λ 越大，阴影越深', out[0].atten > out[1].atten && out[1].atten > out[2].atten);
}

/* ---------- 5. 单缝衍射：透过率随缝宽增长，缝越窄透过的能量越少 ---------- */
console.log('\n[5] 单缝衍射：透射振幅 vs 缝宽（线源, λ=22, N=256）');
{
  const N = 256, lam = 22, wallX = Math.round(N * 0.72), cy = N >> 1;
  const probe = idx(N, wallX + 35, cy);
  const cfgF = { N, sig: 'cw', mode: 'free', src: 'line', lam, dSize: 18 };
  const fF = makeField(N, cfgF);
  const [free] = probeRMS(fF, cfgF, [probe], 1400, 260);
  const rows = [];
  for (const w of [6, 10, 20, 40, 60]) {
    const cfg = { N, sig: 'cw', mode: 'slit', src: 'line', lam, dSize: w };
    const f = makeField(N, cfg);
    const [a] = probeRMS(f, cfg, [probe], 1400, 260);
    rows.push({ w, a, rel: a / free });
    console.log(`     缝宽 w=${String(w).padStart(2)} (w/λ=${(w / lam).toFixed(2)}): 轴向振幅=${a.toFixed(4)}  相对无墙=${(a / free * 100).toFixed(0)}%`);
  }
  let mono = true;
  for (let i = 1; i < rows.length; i++) if (rows[i].a <= rows[i - 1].a) mono = false;
  check('透射振幅随缝宽单调增大', mono);
  check('极窄缝（w=6）透射很弱', rows[0].rel < 0.35, `${(rows[0].rel * 100).toFixed(0)}%`);
  check('宽缝（w=60）接近几何透射', rows[4].rel > 0.6, `${(rows[4].rel * 100).toFixed(0)}%`);
}

/* ---------- 6. 双缝干涉：缝后出现强弱相间的条纹 ---------- */
console.log('\n[6] 双缝干涉条纹（线源, λ=22, w=12, 缝间距=48）');
{
  const N = 256, lam = 22, wallX = Math.round(N * 0.72), cy = N >> 1;
  const w = 12, sep = w * 4;
  const cfg = { N, sig: 'cw', mode: 'double', src: 'line', lam, dSize: w };
  const f = makeField(N, cfg);
  const xs = wallX + 40;
  const zs = [];
  for (let z = cy - 62; z <= cy + 62; z += 2) zs.push(z);
  const rms = probeRMS(f, cfg, zs.map(z => idx(N, xs, z)), 1600, 260);
  const g = rms.map(v => v / Math.max(...rms));
  let maxima = 0;
  for (let k = 1; k < g.length - 1; k++) if (g[k] > g[k - 1] && g[k] >= g[k + 1] && g[k] > 0.35) maxima++;
  const center = g[Math.floor(g.length / 2)];
  console.log('     归一化振幅沿屏（中央→两侧）: ' + g.filter((_, i) => i % 3 === 0).map(v => v.toFixed(2)).join(' '));
  check('中央条纹最强', center > 0.9 * Math.max(...g), `中央=${center.toFixed(3)}`);
  check('存在多条干涉亮纹', maxima >= 3, `亮纹数=${maxima}`);
}

/* ---------- 7. 反射：障碍物前方出现回波（驻波式增强） ---------- */
console.log('\n[7] 反射回波（连续波, 圆盘）');
{
  const N = 256, lam = 22, wallX = Math.round(N * 0.72), cy = N >> 1;
  const probe = idx(N, wallX - 30, cy);   // 障碍物前方
  const cfgF = { N, sig: 'cw', mode: 'free', src: 'point', lam, dSize: 18 };
  const cfgD = { N, sig: 'cw', mode: 'disk', src: 'point', lam, dSize: 18 };
  const fF = makeField(N, cfgF), fD = makeField(N, cfgD);
  const [aF] = probeRMS(fF, cfgF, [probe], 1200, 220);
  const [aD] = probeRMS(fD, cfgD, [probe], 1200, 220);
  console.log(`     前方测点: 自由场=${aF.toFixed(4)} 有圆盘=${aD.toFixed(4)}`);
  check('障碍物前方因反射而改变（干涉/驻波）', Math.abs(aD / aF - 1) > 0.08,
    `比值 ${(aD / aF).toFixed(3)}`);
}

console.log(fails === 0 ? '\n==> 全部检查通过\n' : `\n==> ${fails} 项检查未通过\n`);
process.exit(fails === 0 ? 0 : 1);
