/**
 * scripts/verify-well-ui.mjs — 无头 CDP：走真实交互路径（点击预设/开关/键盘/滑块），
 * 任何异常、UI 报错或"点完没反应"都算失败。
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';

const ROOT = path.resolve(import.meta.dirname, '..');
const SHOTS = process.argv[2] ? path.resolve(process.argv[2]) : path.join(ROOT, 'tests', '_out');
const BROWSER = [
  process.env.CHROME_PATH,
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  '/usr/bin/google-chrome',
].filter(Boolean).find(p => fs.existsSync(p));
if (!BROWSER) { console.error('找不到 Chrome/Edge：请设置环境变量 CHROME_PATH'); process.exit(2); }
const PORT = '9343';
const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'wui-'));
const child = spawn(BROWSER, ['--headless=new', `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--use-angle=swiftshader', '--enable-unsafe-swiftshader',
  '--window-size=1600,900', '--hide-scrollbars', 'about:blank'], { stdio: 'ignore' });
const sleep = ms => new Promise(r => setTimeout(r, ms));
let wsUrl;
for (let i = 0; i < 50 && !wsUrl; i++) {
  try { wsUrl = (await (await fetch(`http://127.0.0.1:${PORT}/json/version`)).json()).webSocketDebuggerUrl; } catch { await sleep(300); }
}
const ws = new WebSocket(wsUrl);
await new Promise(r => ws.addEventListener('open', r));
let id = 0;
const pending = new Map();
ws.addEventListener('message', ev => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) { const { res, rej } = pending.get(m.id); pending.delete(m.id);
    m.error ? rej(new Error(m.error.message)) : res(m.result); }
});
function rpc(method, params = {}, sessionId) {
  const mid = ++id;
  return new Promise((res, rej) => { pending.set(mid, { res, rej }); ws.send(JSON.stringify({ id: mid, method, params, sessionId })); });
}
const { targetId } = await rpc('Target.createTarget', { url: 'about:blank' });
const { sessionId } = await rpc('Target.attachToTarget', { targetId, flatten: true });
const S = (m, p) => rpc(m, p, sessionId);
const errors = [];
await S('Runtime.enable');
ws.addEventListener('message', ev => {
  const m = JSON.parse(ev.data);
  if (m.method === 'Runtime.exceptionThrown')
    errors.push(m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text);
});
await S('Page.enable');
await S('Emulation.setDeviceMetricsOverride', { width: 1600, height: 900, deviceScaleFactor: 1, mobile: false });
await S('Page.navigate', { url: 'file:///' + path.join(ROOT, 'index.html').replace(/\\/g, '/') });
await sleep(2500);
const probe = async e => {
  const r = await S('Runtime.evaluate', { expression: e, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result.value;
};
// 鼠标点击（真实输入事件）
async function click(sel, nth = 0) {
  const box = await probe(`(()=>{const es=document.querySelectorAll(${JSON.stringify(sel)}); const e=es[${nth}];
    if(!e) return null; const r=e.getBoundingClientRect(); return {x:r.x+r.width/2, y:r.y+r.height/2};})()`);
  if (!box) throw new Error('找不到元素 ' + sel + ' #' + nth);
  for (const type of ['mousePressed', 'mouseReleased'])
    await S('Input.dispatchMouseEvent', { type, x: box.x, y: box.y, button: 'left', clickCount: 1 });
}
async function key(text, code) {
  const vk = code ?? (text === ' ' ? 32 : text.toUpperCase().charCodeAt(0));
  await S('Input.dispatchKeyEvent', { type: 'rawKeyDown', key: text, code: 'Key' + text.toUpperCase(),
    windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk });
  if (text !== ' ') await S('Input.dispatchKeyEvent', { type: 'char', key: text, text,
    windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk });
  await S('Input.dispatchKeyEvent', { type: 'keyUp', key: text, code: 'Key' + text.toUpperCase(),
    windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk });
}
const state = () => probe(`(()=>{const A=window.__well,P=A.P;const m=A.moment(P.t);
  return {mode:P.mode, sel:P.selN, nShow:P.nShow, occ:A.occList.slice(), playing:P.playing, t:+P.t.toFixed(3),
          E:+m.E.toFixed(3), x:+m.x.toFixed(4), err:(document.getElementById('err').style.display!=='none')?
          document.getElementById('err').textContent.slice(0,120):''};})()`);

let fails = 0;
const line = s => process.stdout.write(s + '\n');
const check = (name, ok, detail) => { if (!ok) fails++; line(`  ${ok ? '✓' : '✗'} ${name}${detail ? '  ' + detail : ''}`); };

line('\n══ 交互路径检查 ════════════════════════════════════════════════════');
let s = await state();
check('初始为基态阶梯模式', s.mode === 'ladder' && s.occ.join() === '1' && !s.err, JSON.stringify(s));

/* 预设按钮逐个点击 */
const presets = await probe(`[...document.querySelectorAll('#presets button')].map(b=>b.textContent)`);
line('  预设按钮：' + presets.join(' / '));
for (let i = 0; i < presets.length; i++) {
  await click('#presets button', i);
  await sleep(120);
  s = await state();
  const expectOcc = [[1], [2], [1, 2], [1, 2, 3, 4, 5], [1,2,3,4,5,6,7,8,9,10],
                     Array.from({length:24},(_,k)=>k+1), [1, 3],
                     Array.from({length:10},(_,k)=>k+1), [1, 2], [24, 25]][i];
  check(`预设「${presets[i]}」→ occ=[${expectOcc.join(',')}]`, s.occ.join() === expectOcc.join() && !s.err, `得到 occ=[${s.occ.join(',')}] mode=${s.mode}`);
}

/* 显示要素开关全部切换两次 */
const togs = await probe(`document.querySelectorAll('#togs input').length`);
for (let i = 0; i < togs; i++) {
  await click('#togs input', i); await sleep(60);
  await click('#togs input', i); await sleep(60);
}
s = await state();
check('6 个显示要素开关各切换两次无异常', !s.err, s.err);

/* 模式切换 */
await click('#modeSeg button', 0); await sleep(150);
s = await state(); check('切回能级阶梯', s.mode === 'ladder' && !s.err);
await click('#modeSeg button', 1); await sleep(150);
s = await state(); check('切到波包/演化', s.mode === 'evolve' && !s.err);

/* 能级芯片：逐个点亮 1..16 再关掉，检查 occList 与 |cₙ|² */
for (const n of [3, 7, 16]) {
  await click('#chips .chip', n - 1); await sleep(80);
}
s = await state();
check('芯片点击叠加 n=3,7,16', [3,7,16].every(n => s.occ.includes(n)) && !s.err, `occ=[${s.occ.join(',')}]`);
for (const n of [3, 7, 16]) { await click('#chips .chip', n - 1); await sleep(80); }
s = await state();
check('再次点击关闭这些能级', ![3,7,16].some(n => s.occ.includes(n)) && !s.err, `occ=[${s.occ.join(',')}]`);

/* 展开/收起芯片 */
await click('#chips .chip.more'); await sleep(120);
const nChips = await probe(`document.querySelectorAll('#chips .chip').length`);
check('展开后芯片数 = 65（64 能级 + 收起按钮）', nChips === 65, 'n=' + nChips);
await click('#chips .chip.more'); await sleep(120);

/* 相位行点击（需要多能级） */
await click('#presets button', 2); await sleep(150);
const rows = await probe(`document.querySelectorAll('#coefs .crow').length`);
await click('#coefs .crow', 0); await sleep(100);
const ph = await probe(`(()=>{const t=document.querySelectorAll('#coefs .crow')[0].querySelector('.cph').textContent; return t;})()`);
check('点击系数行循环初相位', ph !== '0.00π' && rows >= 2, `φ₁=${ph}（行数 ${rows}）`);

/* 滑块 */
await probe(`(()=>{const e=document.getElementById('nShow'); e.value=12; e.dispatchEvent(new Event('input',{bubbles:true}));})()`);
await probe(`(()=>{const e=document.getElementById('selN'); e.value=9; e.dispatchEvent(new Event('input',{bubbles:true}));})()`);
await sleep(150);
s = await state();
check('阶梯层数=12 / 选定 n=9', s.nShow === 12 && s.sel === 9 && !s.err, JSON.stringify({nShow:s.nShow, sel:s.sel}));

/* 时间控制：暂停后重置应严格归零；恢复播放后 t 应继续推进
   （播放中重置只保证"归零后从新时间继续走"，帧率无关的严格断言放在暂停态做） */
await click('#playBtn'); await sleep(200);
s = await state(); check('暂停按钮 → playing=false', s.playing === false);
await click('#resetBtn'); await sleep(150);
s = await state(); check('暂停后重置 t 严格为 0', s.t === 0, 't=' + s.t);
await click('#playBtn'); await sleep(700);
s = await state(); check('播放按钮 → 时间推进', s.playing === true && s.t > 0.001, 't=' + s.t);

/* 键盘 */
await key(' '); await sleep(100); s = await state();
check('空格 播放/暂停', s.playing === false, 'playing=' + s.playing);
/* 键盘只应在画布聚焦时生效（按钮聚焦时空格应触发按钮） */
await probe(`document.activeElement && document.activeElement.blur && document.activeElement.blur()`);
await click('#modeSeg button', 0); await sleep(120);
/* 点击模式按钮后焦点在该按钮上，键盘快捷键按设计不触发；真实用户会点回画布 */
await click('#gl'); await sleep(80);
await probe(`document.activeElement && document.activeElement.blur && document.activeElement.blur()`);
await probe(`window.__k=[]; window.addEventListener('keydown', function h(e){ window.__k.push(e.key+'|'+e.code+'|目标='+(e.target&&e.target.tagName)+'|mode='+window.__well.P.mode+'|sel='+window.__well.P.selN); }, true); true`);
await key('n'); await sleep(150);
s = await state();
check('N 键 下一个能级', s.sel === 10, 'sel=' + s.sel);
await key('r'); await sleep(100);
await key('t'); await sleep(100); s = await state();
check('R/T 快捷键无异常', !s.err, s.err);
await key('5'); await sleep(150); s = await state();
check('数字键 5 切换能级 n=5', s.occ.includes(5), `occ=[${s.occ.join(',')}]`);

/* 相机按钮 */
for (const b of ['#viewBtn', '#topBtn', '#frontBtn', '#sideBtn']) { await click(b); await sleep(120); }
s = await state();
check('四个相机按钮无异常', !s.err, s.err);
const cam = await probe(`(()=>{const c=window.__well; return {dist:+c.P?0:0};})()`);
/* 自动旋转 */
await probe(`(()=>{const e=document.getElementById('rot'); e.value=0.5; e.dispatchEvent(new Event('input',{bubbles:true}));})()`);
await sleep(500);
s = await state();
check('自动旋转开启后无异常', !s.err, s.err);

/* 画布拖动旋转（真实指针事件） */
await S('Input.dispatchMouseEvent', { type: 'mousePressed', x: 900, y: 400, button: 'left', clickCount: 1 });
await S('Input.dispatchMouseEvent', { type: 'mouseMoved', x: 1030, y: 330, button: 'left' });
await S('Input.dispatchMouseEvent', { type: 'mouseReleased', x: 1030, y: 330, button: 'left', clickCount: 1 });
await sleep(200);
s = await state();
check('拖动旋转视角无异常', !s.err, s.err);
const shot = await S('Page.captureScreenshot', { format: 'png' });
fs.writeFileSync(path.join(SHOTS, 'ui-after-play.png'), Buffer.from(shot.data, 'base64'));

/* 极端参数：14 层 + 高能级叠加 + 全部要素 */
await probe(`(()=>{const A=window.__well; A.setOpts({mode:'ladder'}); A.setMagic({1:1,2:1,3:1,7:1,14:1,30:1,64:1}); A.setNShow(14); A.setSel(14); A.setMode('ladder'); A.render(1.234);})()`);
await sleep(200);
const stats = await probe(`(()=>{const s=window.__well.canvasStats(); return {lum:+s.meanLum.toFixed(2), lit:+s.litFrac.toFixed(3)};})()`);
check('n=64 参与叠加时可正常渲染', stats.lit > 0.01, JSON.stringify(stats));

if (errors.length) { line('\n未捕获异常：\n' + errors.join('\n')); fails += errors.length; }
line(fails === 0 ? '\n交互检查全部通过 ✅' : `\n${fails} 项失败 ❌`);
ws.close(); child.kill();
process.exit(fails === 0 ? 0 : 1);
