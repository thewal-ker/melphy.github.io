/**
 * scripts/check-links.mjs — 无浏览器的仓库自检（纯 Node 标准库）：
 *   1) 必需文件是否齐全
 *   2) README / HTML 中的相对链接与图片是否都存在
 *   3) index.html 与 infinite-square-well.html 是否一致
 *   4) 内嵌脚本能否通过语法检查（无浏览器也能发现低级错误）
 *   5) docs/ 下 PNG 是否为合法 PNG
 *   6) 是否残留开发期的绝对路径（D:\ 等）
 * 用法：node scripts/check-links.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const ROOT = path.resolve(import.meta.dirname, '..');
let fails = 0;
const line = s => process.stdout.write(s + '\n');
const check = (name, ok, detail) => { if (!ok) fails++; line(`  ${ok ? '✓' : '✗'} ${name}${detail ? '  ' + detail : ''}`); };

line('\n══ 仓库自检 ════════════════════════════════════════════════════════');

/* 1. 必需文件 */
const required = [
  'index.html', 'infinite-square-well.html', 'README.md', 'LICENSE',
  'package.json', '.gitignore', '.gitattributes', '.nojekyll',
  'scripts/verify.mjs', 'scripts/verify-ui.mjs', 'scripts/make-zip.mjs',
  'docs/preview.png',
];
for (const f of required) check(`存在 ${f}`, fs.existsSync(path.join(ROOT, f)));

/* 2. README 中的相对链接 / 图片 */
const readme = fs.readFileSync(path.join(ROOT, 'README.md'), 'utf8');
const links = [...readme.matchAll(/\]\(([^)]+)\)/g)].map(m => m[1])
  .filter(u => !/^(https?:|mailto:|#)/.test(u));
for (const u of links) {
  const p = path.join(ROOT, decodeURIComponent(u.split('#')[0]));
  check(`README 链接可解析：${u}`, fs.existsSync(p));
}
/* README 里提到的 docs/xxx.png 也要存在 */
const docRefs = [...readme.matchAll(/`?(docs\/[A-Za-z0-9._-]+\.png)`?/g)].map(m => m[1]);
for (const u of [...new Set(docRefs)]) check(`README 图片存在：${u}`, fs.existsSync(path.join(ROOT, u)));

/* 3. 两份入口文件一致 */
const a = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const b = fs.readFileSync(path.join(ROOT, 'infinite-square-well.html'), 'utf8');
check('index.html 与 infinite-square-well.html 内容一致', a === b,
      a === b ? '' : `长度 ${a.length} vs ${b.length}`);

/* 4. 内嵌脚本语法检查 */
{
  const m = a.match(/<script>([\s\S]*?)<\/script>/);
  const tmp = path.join(ROOT, 'tests', '_out');
  fs.mkdirSync(tmp, { recursive: true });
  const jsFile = path.join(tmp, '_app.mjs');
  fs.writeFileSync(jsFile, m ? m[1] : '');
  const r = spawnSync(process.execPath, ['--check', jsFile], { encoding: 'utf8' });
  check('内嵌脚本通过 node --check', r.status === 0, r.status === 0 ? '' : (r.stderr || '').split('\n')[0]);
  fs.unlinkSync(jsFile);
}

/* 5. PNG 合法性 */
const pngs = fs.readdirSync(path.join(ROOT, 'docs')).filter(f => f.endsWith('.png'));
for (const f of pngs) {
  const buf = fs.readFileSync(path.join(ROOT, 'docs', f));
  const ok = buf.length > 1000 && buf[0] === 0x89 && buf.toString('latin1', 1, 4) === 'PNG';
  check(`docs/${f} 是合法 PNG（${(buf.length / 1024).toFixed(0)} KB）`, ok);
}

/* 6. 无开发期绝对路径（本机工作目录） */
const ABS = new RegExp('[A-Za-z]:' + '[\\\\/]' + 'test' + '[\\\\/]', 'i');
for (const f of ['index.html', 'package.json', 'scripts/verify.mjs', 'scripts/verify-ui.mjs', 'README.md']) {
  const t = fs.readFileSync(path.join(ROOT, f), 'utf8');
  check(`${f} 无硬编码本机路径`, !ABS.test(t));
}

line(fails === 0 ? '\n自检全部通过 ✅' : `\n${fails} 项失败 ❌`);
process.exit(fails === 0 ? 0 : 1);
