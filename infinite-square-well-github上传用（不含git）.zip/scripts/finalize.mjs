/**
 * scripts/finalize.mjs — 发布前规范化：把所有文本文件统一成 LF（配合 .gitattributes）
 * 用法：node scripts/finalize.mjs
 */
import fs from 'node:fs';
import path from 'node:path';

const REPO = path.resolve(import.meta.dirname, '..');
const TEXT = new Set(['.html', '.md', '.mjs', '.js', '.json', '.yml', '.yaml', '.css', '.txt', '.nojekyll']);
const SKIP_DIR = new Set(['.git', 'node_modules', '_out']);

let changed = 0, scanned = 0;
function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (SKIP_DIR.has(e.name)) continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) { walk(full); continue; }
    const ext = path.extname(e.name) || e.name;
    if (!TEXT.has(ext)) continue;
    scanned++;
    const raw = fs.readFileSync(full, 'utf8');
    const lf = raw.replace(/\r\n/g, '\n');
    if (lf !== raw) { fs.writeFileSync(full, lf); changed++; }
    if (ext === '.html' && !/^<!DOCTYPE html>/i.test(lf)) console.warn('  ! ' + path.relative(REPO, full) + ' 缺少 DOCTYPE');
  }
}
walk(REPO);
console.log(`行尾规范化：扫描 ${scanned} 个文本文件，修正 ${changed} 个（其余已是 LF）。`);
