/**
 * scripts/verify-well.mjs — 无头 Edge/Chrome + CDP：
 *   1) 把 infinite-square-well.html 真正跑起来，用 window.__well 做物理断言；
 *   2) 驱动 UI 走若干教学场景并截图到 renders/。
 * 用法：node scripts/verify-well.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';

const ROOT = path.resolve(import.meta.dirname, '..');
const PAGE = 'file:///' + path.join(ROOT, 'index.html').replace(/\\/g, '/');
/** 截图输出目录：默认 tests/_out（已 gitignore）；传参可改为 docs 以更新仓库截图 */
const SHOTS = process.argv[2] ? path.resolve(process.argv[2]) : path.join(ROOT, 'tests', '_out');
fs.mkdirSync(SHOTS, { recursive: true });
/** 浏览器：优先用环境变量 CHROME_PATH，否则按常见安装位置查找 */
const BROWSER = [
  process.env.CHROME_PATH,
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
].filter(Boolean).find(p => fs.existsSync(p));
if (!BROWSER) { console.error('找不到 Chrome/Edge：请设置环境变量 CHROME_PATH'); process.exit(2); }

const PORT = '9341';
const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'well-'));
const child = spawn(BROWSER, [
  '--headless=new', `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--disable-extensions',
  '--use-angle=swiftshader', '--enable-unsafe-swiftshader',
  '--window-size=1600,900', '--hide-scrollbars', 'about:blank',
], { stdio: 'ignore', detached: false });

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function findWs() {
  for (let i = 0; i < 60; i++) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/version`);
      const j = await r.json();
      if (j.webSocketDebuggerUrl) return j.webSocketDebuggerUrl;
    } catch { /* not up yet */ }
    await sleep(400);
  }
  throw new Error('浏览器调试端口未就绪');
}

let msgId = 0;
function rpc(ws, method, params = {}, sessionId) {
  const id = ++msgId;
  return new Promise((resolve, reject) => {
    const onMsg = ev => {
      const m = JSON.parse(ev.data);
      if (m.id === id) {
        ws.removeEventListener('message', onMsg);
        m.error ? reject(new Error(method + ': ' + m.error.message)) : resolve(m.result);
      }
    };
    ws.addEventListener('message', onMsg);
    ws.send(JSON.stringify({ id, method, params, sessionId }));
    setTimeout(() => { ws.removeEventListener('message', onMsg); reject(new Error('timeout ' + method)); }, 60000);
  });
}

const wsUrl = await findWs();
const ws = new WebSocket(wsUrl);
await new Promise((r, j) => { ws.addEventListener('open', r); ws.addEventListener('error', j); });

const logs = [];
ws.addEventListener('message', ev => {
  const m = JSON.parse(ev.data);
  if (m.method === 'Runtime.consoleAPICalled')
    logs.push('[console] ' + (m.params.args || []).map(a => a.value ?? a.description).join(' '));
  if (m.method === 'Runtime.exceptionThrown')
    logs.push('[EXCEPTION] ' + (m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text));
  if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error')
    logs.push('[log] ' + m.params.entry.text);
});

const { targetId } = await rpc(ws, 'Target.createTarget', { url: 'about:blank' });
const { sessionId } = await rpc(ws, 'Target.attachToTarget', { targetId, flatten: true });
const S = (m, p) => rpc(ws, m, p, sessionId);
await S('Runtime.enable'); await S('Log.enable'); await S('Page.enable');
await S('Emulation.setDeviceMetricsOverride', { width: 1600, height: 900, deviceScaleFactor: 1, mobile: false });
await S('Page.navigate', { url: PAGE });
await sleep(3000);

async function probe(expr) {
  const r = await S('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result.value;
}
async function shot(name) {
  const r = await S('Page.captureScreenshot', { format: 'png' });
  const f = path.join(SHOTS, name);
  fs.writeFileSync(f, Buffer.from(r.data, 'base64'));
  return f;
}

const ready = await probe('!!(window.__well && window.__well.ready)');
if (!ready) {
  const ui = await probe(`(()=>{const e=document.getElementById('err');return e.style.display!=='none'?e.textContent:'(无错误框)'})()`);
  console.error('页面未就绪。日志：\n' + logs.join('\n') + '\nUI: ' + ui);
  process.exit(1);
}

/* ────────────────── 物理断言 ────────────────── */
const report = await probe(`(() => {
  const A = window.__well, out = [];
  const ok = (name, got, want, tol) => out.push({
    name, got:+Number(got).toFixed(10), want:+Number(want).toFixed(10), tol,
    pass: Math.abs(got-want) <= tol });
  const integ = f => {   // Simpson 复合公式（与页面内一致）
    const GN=A.GN, DX=A.DX; let s=0;
    for(let i=1;i<GN;i++) s += f[i]*((i&1)?4:2);
    return s*DX/3;
  };
  const sum = f => { let s=0; for(let i=0;i<=A.GN;i++) s+=f[i]; return s; };

  /* 1. 本征函数归一化与正交性：∫ψₘψₙ = δₘₙ */
  const asF64 = a => Float64Array.from(a);
  for (const n of [1,2,7,16]) {
    const s = asF64(A.sinTable(n)), f = new Float64Array(A.GN+1);
    for (let i=0;i<=A.GN;i++) f[i] = (2/Math.PI)*s[i]*s[i];
    ok('∫|ψ'+n+'|²dx = 1', integ(f), 1, 1e-9);
  }
  { let mx=0;
    for (const [m,n] of [[1,2],[2,3],[5,9],[3,16]]) {
      const a=asF64(A.sinTable(m)), b=asF64(A.sinTable(n)), f=new Float64Array(A.GN+1);
      for (let i=0;i<=A.GN;i++) f[i]=(2/Math.PI)*a[i]*b[i];
      mx = Math.max(mx, Math.abs(integ(f)));
    }
    ok('⟨ψₘ|ψₙ⟩ = 0 (m≠n)', mx, 0, 1e-9);
  }

  /* 2. 能量本征值 Eₙ = n²E₁（自然单位） */
  ok('E₁ = 1', A.E(1), 1, 0);
  ok('E₃ = 9E₁', A.E(3), 9, 0);
  ok('E₁₂/E₄ = 9', A.E(12)/A.E(4), 9, 0);

  /* 3. 定态：⟨x⟩ = L/2、⟨p⟩ = 0，且 ΔxΔp 由 Δp = n 决定
        （阱内基态并非最小不确定态：ΔxΔp = 0.5679 ħ > ħ/2） */
  for (const n of [1,2,5]) {
    A.setEqual([n]);
    const m = A.moment(0.37);
    const dn = new Float64Array(A.GN+1);
    for (let i=0;i<=A.GN;i++) dn[i] = A.re[i]*A.re[i]+A.im[i]*A.im[i];
    ok('|'+n+'⟩ ⟨x⟩ = L/2', m.x/Math.PI, 0.5, 1e-10);
    ok('|'+n+'⟩ ⟨p⟩ = 0', m.p, 0, 1e-10);
    /* ⟨p̂²⟩ 由谱展开给精确值 ⇒ Δp = nħ/L 应为机器精度 */
    ok('|'+n+'⟩ Δp = nħ/L（精确）', m.dp, n, 1e-10);
    ok('|'+n+'⟩ ∫|ψ|²dx = 1', integ(dn), 1, 1e-9);
    ok('|'+n+'⟩ ⟨Ĥ⟩ = '+n*n, m.E, n*n, 1e-12);
    ok('|'+n+'⟩ ΔE = 0（能量本征态）', m.dE, 0, 1e-12);
  }
  /* 解析值：Δx(L=π,n=1) = √(1/12−1/(2π²))，ΔxΔp/ħ = √(2)(π/√3)·√(1/12−1/2π²) */
  { A.setEqual([1]); const m=A.moment(0);
    const dxa = Math.sqrt(1/12-1/(2*Math.PI*Math.PI));
    ok('|1⟩ Δx = π√(1/12−1/2π²)', m.dx/Math.PI, dxa, 1e-9);
    ok('|1⟩ ΔxΔp = 0.5678… ħ（> ħ/2）', m.dx*m.dp, Math.PI*dxa, 1e-9); }

  /* 4. 定态不含时：|ψ(x,t)|² 与 t 无关（4 倍周期后仍完全一致） */
  { A.setEqual([3]);
    A.moment(0);
    const d0 = Float64Array.from(A.re), p0 = Float64Array.from(A.im);
    A.moment(4*2*Math.PI);
    let mx=0; for (let i=0;i<=A.GN;i++) mx = Math.max(mx, Math.abs(A.re[i]-d0[i]), Math.abs(A.im[i]-p0[i]));
    ok('|3⟩ |ψ|² 与 t 无关（4T 后波形复原）', mx, 0, 1e-9);
  }

  /* 5. 叠加态 (ψ₁+ψ₂)/√2：⟨x⟩(t) = L/2 − (16L/9π²)·cos(3t)
        （E₂−E₁ = 3 ⇒ Bohr 频率 ω₂₁ = 3；交叉积分 ∫₀^L x·sin x·sin 2x dx = −8L²/9π²，
         归一后振荡幅度 = 16L/(9π²) = 16/(9π) ≈ 0.5659） */
  { A.setEqual([1,2]);
    const C = 16*Math.PI/(9*Math.PI*Math.PI);   // 16L/(9π²) = 16/(9π)
    let err=0, amp=[];
    for (const t of [0, 0.3, 1.1, 2.7, 5.5]) {
      const m = A.moment(t);
      const want = Math.PI/2 - C*Math.cos(3*t);
      amp.push(+(m.x/Math.PI).toFixed(5));
      err = Math.max(err, Math.abs(m.x-want));
    }
    ok('⟨x⟩(t) = L/2 − 16L·cos(3t)/9π²', err, 0, 2e-9);
    ok('⟨x⟩(0)/L = 0.31987…（波包偏左）', A.moment(0).x/Math.PI, 0.5 - 16/(9*Math.PI*Math.PI), 1e-9);
    ok('⟨Ĥ⟩ = 2.5E₁', A.moment(0).E, 2.5, 1e-12);
    ok('ΔE = 1.5E₁（=(E₂−E₁)/2）', A.moment(0).dE, 1.5, 1e-12);
  }

  /* 6. 复现（revival）：Eₙ ∝ n² 使 T = 2π。
        t=π/2：相位 e^(−iE₁t)=−i, e^(−iE₂t)=+1 ⇒ ψ=(−i sin x + sin 2x)/√2，
        |ψ|² 中交叉项含 cos(2x)·(1+cos 4x)… 且在此相位下退化为关于阱心对称的分布
        ⇒ ⟨x⟩(π/2) = L/2；只有 t=2π 才是波函数完全复原 */
  { A.setEqual([1,2]);
    const m0 = A.moment(0);
    const mh = A.moment(Math.PI/2);
    ok('⟨x⟩(π/2) = L/2（该相位下分布对称）', mh.x/Math.PI, 0.5, 1e-9);
    const mf = A.moment(2*Math.PI);
    ok('|ψ(x,2π)|² = |ψ(x,0)|²（全周期复原）', Math.abs(mf.x-m0.x), 0, 1e-9);
    /* t=π/2 逐点核对实部与虚部（内部已含 √(2/π) 归一） */
    const s1 = asF64(A.sinTable(1)), s2 = asF64(A.sinTable(2));
    const k = Math.sqrt(2/Math.PI)/Math.SQRT2;
    A.moment(Math.PI/2);
    let er=0, ei=0;
    for (let i=1;i<A.GN;i++){
      er = Math.max(er, Math.abs(A.re[i] - k*s2[i]));
      ei = Math.max(ei, Math.abs(A.im[i] + k*s1[i]));
    }
    ok('ψ(x,π/2) 实部 = √(2/L)·sin2x/√2', er, 0, 1e-9);
    ok('ψ(x,π/2) 虚部 = −√(2/L)·sin x/√2', ei, 0, 1e-9);
  }

  /* 7. 对应原理：n=24 时 |ψₙ|² 的振荡在时间平均后 → 经典均匀分布 1/L。
        sin²(24x) 的周期 = π/24 = 16 格，故每个"格窗"的平均即 1/L（Simpson 对周期函数精确） */
  { A.setEqual([24]);
    const T = 2*Math.PI, M = 240, acc = new Float64Array(A.GN+1);
    for (let k=0;k<M;k++){
      A.moment(T*k/M);
      for (let i=0;i<=A.GN;i++) acc[i] += (A.re[i]*A.re[i]+A.im[i]*A.im[i])/M;
    }
    let mx=0;
    const W=32;
    for (let k=0;k+W<=A.GN;k+=W){
      let s=0; for (let i=1;i<W;i++) s += acc[k+i]*((i&1)?4:2);
      s = (s + acc[k] + acc[k+W])*A.DX/3;
      mx = Math.max(mx, Math.abs(s/(W*A.DX) - 1/Math.PI));
    }
    ok('n=24 局部平均 |ψ|² → 1/L（残差）', mx, 0, 1e-2);
    /* 粗粒化包络（更大窗口）应非常接近均匀 */
    let me=0;
    for (let k=0;k+128<=A.GN;k+=128){
      let s=0; for (let i=0;i<128;i++) s += acc[k+i];
      me = Math.max(me, Math.abs(s/128 - 1/Math.PI));
    }
    ok('n=24 概率密度包络 → 均匀（残差）', me, 0, 3e-3);
  }

  /* 8. 宽波包：⟨Ĥ⟩ = ΣEₙ/N，t=0 时在左半阱局域 */
  { A.setEqual([1,2,3,4,5,6,7,8,9,10]);
    const m = A.moment(0);
    ok('等权 1–10 ⟨Ĥ⟩ = 38.5E₁', m.E, 38.5, 1e-10);
    ok('等权 1–10 ∫|ψ|²dx = 1', m.norm, 1, 1e-9);
    ok('等权 1–10 t=0 局域在左半阱 ⟨x⟩ < L/2', m.x < Math.PI/2 ? 1 : 0, 1, 0);
  }

  /* 9. 归一化与区间：ψ 在边界严格为 0 */
  { A.setEqual([1,3,5]);
    A.moment(0.8);
    ok('ψ(0) = 0（无限高壁）', Math.hypot(A.re[0], A.im[0]), 0, 0);
    ok('ψ(L) = 0（无限高壁）', Math.hypot(A.re[A.GN], A.im[A.GN]), 0, 0);
  }

  /* 10. 行波包预设（相位 φₙ 线性于 n ⇒ 一阶近似为平移）：
        · 等权 1–10、相位 0：初始局域在 x≈0.11L，随后单调右移（0 ≤ t ≤ 0.2 自由飞行段）
        · (ψ₁−ψ₂)/√2（相位差 π）：初始局域在 x≈0.68L，随后单调左移
        t > 0.3 后波包碰壁反射并复现，不再是单调运动 */
  { A.setMagic(Object.fromEntries(Array.from({length:10},(_,k)=>[k+1,1])));
    A.setPhases({});
    const xr = [0, 0.08, 0.16, 0.2].map(t => A.moment(t).x);
    A.setMagic({1:1,2:1}); A.setPhases({2:Math.PI});
    const xl = [0, 0.15, 0.3, 0.45].map(t => A.moment(t).x);
    out.push({name:'右行波包 ⟨x⟩ 单调右移（0→0.2）', got:xr.map(v=>+(v/Math.PI).toFixed(4)).join(','),
              want:'0.1084,0.3095,0.5514,0.6255', tol:0,
              pass: xr[0]<xr[1] && xr[1]<xr[2] && xr[2]<xr[3] && Math.abs(xr[0]/Math.PI-0.1084)<2e-3});
    out.push({name:'左行波包 ⟨x⟩ 单调左移（0→0.45）', got:xl.map(v=>+(v/Math.PI).toFixed(4)).join(','),
              want:'0.6801,…,0.5394', tol:0,
              pass: xl[0]>xl[1] && xl[1]>xl[2] && xl[2]>xl[3] && Math.abs(xl[0]/Math.PI-0.6801)<2e-3});
    out.push({name:'(ψ₁+ψ₂) 与 (ψ₁−ψ₂) 互为阱心镜像', got:+((A.setPhases({}), A.setMagic({1:1,2:1}), A.moment(0).x/Math.PI + xl[0]/Math.PI).toFixed(10)),
              want:1, tol:1e-9,
              pass: (()=>{ A.setPhases({}); A.setMagic({1:1,2:1}); const a = A.moment(0).x/Math.PI;
                           return Math.abs(a + xl[0]/Math.PI - 1) < 1e-9; })()});
  }
  return out;
})()`);

let fails = 0;
const line = (s) => process.stdout.write(s + '\n');
line('\n══ 物理断言 ════════════════════════════════════════════════════════');
for (const r of report) {
  if (!r.pass) fails++;
  line(`${r.pass ? '  ✓' : '  ✗'} ${r.name.padEnd(38)} got=${String(r.got).padStart(14)} want=${String(r.want).padStart(12)} tol=${r.tol}`);
}
line(`── ${report.length - fails}/${report.length} 通过`);

/* ────────────────── 场景截图 ────────────────── */
line('\n══ 场景截图 ════════════════════════════════════════════════════════');
/** 覆盖全部教学场景；`node scripts/verify.mjs docs full` 可一次生成整组 */
const FULL = process.argv[3] === 'full';
const scenes = [
  ['screenshot-ladder-ground.png', `A.setOpts({mode:'ladder'});A.setMode('ladder');A.setEqual([1]);A.setNShow(6);A.setSel(1);A.resetView();A.render(0);`],
  ['screenshot-ladder-n3.png',     `A.setSel(3);A.render(0.6);`],
  ['screenshot-ladder-n10.png',    `A.setNShow(10);A.setSel(10);A.render(0.6);`],
  ['screenshot-evolve-1plus2.png', `A.setNShow(6);A.setMode('evolve');A.setEqual([1,2]);A.render(1.05);`],
  ['screenshot-correspondence.png',`A.setMagic({24:1,25:1});A.setOpts({showClassical:true});A.render(0.0);`],
  ['screenshot-top.png',           `A.setMode('ladder');A.setEqual([1]);A.setNShow(6);A.setSel(3);document.getElementById('topBtn').click();A.render(0);`],
];
if (FULL) scenes.push(
  ['screenshot-ladder-n6.png',     `document.getElementById('viewBtn').click();A.setSel(6);A.render(0.6);`],
  ['screenshot-evolve-packet.png', `A.setMode('evolve');A.setMagic({1:1,2:1,3:1,4:1,5:1,6:1,7:1,8:1});A.render(0.0);`],
  ['screenshot-evolve-late.png',   `A.render(0.55);`],
  ['screenshot-front.png',         `A.setMode('ladder');A.setEqual([1]);A.setSel(4);document.getElementById('frontBtn').click();A.render(0);`],
  ['screenshot-side.png',          `document.getElementById('sideBtn').click();A.render(0);`],
);
for (const [name, js] of scenes) {
  const st = await probe(`(() => { const A=window.__well; ${js} const s=A.canvasStats(); return {meanLum:+s.meanLum.toFixed(2), litFrac:+s.litFrac.toFixed(3), labels:A.labelCount(), err:(document.getElementById('err').style.display!=='none')?document.getElementById('err').textContent:''}; })()`);
  const f = await shot(name);
  const flag = st.err ? '  ✗ UI报错: ' + st.err.slice(0, 60) : (st.litFrac < 0.01 ? '  ✗ 画面几乎全黑' : '  ✓');
  line(`  ${name.padEnd(30)} 平均亮度=${String(st.meanLum).padStart(6)} 亮像素比=${st.litFrac} 标签=${String(st.labels).padStart(2)}${flag}`);
  if (st.err || st.litFrac < 0.01) fails++;
}

/* ────────────────── 窄窗口（响应式） ────────────────── */
await S('Emulation.setDeviceMetricsOverride', { width: 1024, height: 720, deviceScaleFactor: 1, mobile: false });
await sleep(400);
const stSmall = await probe(`(() => { const A=window.__well; A.setMode('ladder'); A.setEqual([1]); A.setNShow(6); A.setSel(2); A.resetView(); A.render(0); const s=A.canvasStats(); return {meanLum:+s.meanLum.toFixed(2), litFrac:+s.litFrac.toFixed(3)}; })()`);
await shot('screenshot-small-window.png');
line(`  screenshot-small-window.png（1024×720）    平均亮度=${String(stSmall.meanLum).padStart(6)} 亮像素比=${stSmall.litFrac}`);

if (logs.length) line('\n浏览器日志：\n' + logs.join('\n'));
line(fails === 0 ? '\n全部通过 ✅' : `\n${fails} 项失败 ❌`);

ws.close();
try { child.kill(); } catch { /* ignore */ }
process.exit(fails === 0 ? 0 : 1);
