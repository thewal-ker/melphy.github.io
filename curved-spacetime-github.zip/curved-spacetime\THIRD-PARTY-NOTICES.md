# 第三方组件

本项目的运行时代码（`js/`、`css/`、`index.html`、`tests/`、`tools/`）为 MIT 许可，
但仓库内附带（vendor）了下列第三方库，它们的版权归各自作者所有。

## three.js r128

- 文件：`vendor/three.min.js`
- 许可：MIT
- 版权：© 2010-2021 Three.js Authors
- 来源：<https://github.com/mrdoob/three.js>
- 说明：单文件版 `curved-spacetime.html` 内联了这份文件，其文件头部的
  `@license` 注释已原样保留。

## OrbitControls

- 文件：`vendor/OrbitControls.js`
- 许可：MIT
- 版权：© 2010-2021 Three.js Authors
- 来源：<https://github.com/mrdoob/three.js/blob/r128/examples/js/controls/OrbitControls.js>
- 说明：three.js 官方示例中的相机控制器（r128 的 `examples/js` 版本，
  以全局 `THREE.OrbitControls` 形式提供）。

---

MIT 许可全文见 [LICENSE](LICENSE)。
