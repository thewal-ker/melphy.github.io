/* ============================================================================
 * 弯曲时空模型 — 物理内核 (Curved Spacetime — physics core)
 * ----------------------------------------------------------------------------
 * 本文件不依赖 three.js，可在浏览器 (window.STPhysics) 与 Node (module.exports)
 * 中同时使用，因此可以用单元测试直接验证物理公式。
 *
 * 单位制：几何单位 G = c = 1
 *   长度 1 = 网格单位 (grid unit = 1 gu)
 *   时间 1 = gu / c          （光跨越 1 gu 需要 1 个时间单位）
 *   质量 1 gu = 1/2  (因为 r_s = 2GM/c² = M)
 *
 * 关键约定
 *   - 网格平面是 XZ 平面，y 是"深度"方向（向下凹陷 = 负 y）。
 *   - 网格顶点位移：  y(x,z) = -Σ mᵢ / sqrt(dᵢ² + ε²)      （Flamm 抛物面的软化形式）
 *   - 引力井深度深 = 时空弯曲强。
 * ========================================================================== */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.STPhysics = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  /* ---------------------------------------------------------------- 常数 */
  var C_LIGHT = 299792458;            // m/s
  var G_NEWTON = 6.67430e-11;         // m³ kg⁻¹ s⁻²
  var M_SUN = 1.98847e30;             // kg
  var AU = 1.495978707e11;            // m

  var EPS2 = 0.35 * 0.35;             // 软化因子平方（避免 1/r 奇点）

  /* ------------------------------------------------ 时空曲面的几何 (field) */
  /**
   * 由若干质量产生的"引力井"位移场。
   * @param {number} px  平面坐标 x
   * @param {number} pz  平面坐标 z
   * @param {Array<{x:number,z:number,m:number}>} masses
   * @returns {{y:number, nx:number, ny:number, nz:number, grad:number}}
   *          y   = 竖直位移（负值，向下凹陷）
   *          n   = 曲面单位法向（解析法向，供光照使用）
   *          grad= |∂y/∂x| 的量级（用于着色）
   */
  function surfaceAt(px, pz, masses) {
    var y = 0, gx = 0, gz = 0;
    for (var i = 0; i < masses.length; i++) {
      var M = masses[i];
      if (M.m <= 0) continue;
      var dx = px - M.x, dz = pz - M.z;
      var s = dx * dx + dz * dz + EPS2;
      var inv = 1 / Math.sqrt(s);            // (d²+ε²)^(-1/2)
      var inv3 = inv / s;                    // (d²+ε²)^(-3/2)
      y -= M.m * inv;
      // ∂/∂x [ -m (d²+ε²)^(-1/2) ] = m · dx · (d²+ε²)^(-3/2)
      gx += M.m * dx * inv3;
      gz += M.m * dz * inv3;
    }
    // 法向 = normalize(-∂y/∂x, 1, -∂y/∂z)
    var nx = -gx, ny = 1, nz = -gz;
    var len = Math.sqrt(nx * nx + ny * ny + nz * nz);
    return { y: y, nx: nx / len, ny: ny / len, nz: nz / len,
             grad: Math.sqrt(gx * gx + gz * gz) };
  }

  /** 只要位移（比 surfaceAt 便宜，用于 2D 嵌入图采样） */
  function heightAt(px, pz, masses) {
    var y = 0;
    for (var i = 0; i < masses.length; i++) {
      var M = masses[i];
      if (M.m <= 0) continue;
      var dx = px - M.x, dz = pz - M.z;
      y -= M.m / Math.sqrt(dx * dx + dz * dz + EPS2);
    }
    return y;
  }

  /* --------------------------------------------------- 史瓦西时空 (Schwarzschild) */
  /** 几何单位下的史瓦西半径 r_s = 2GM/c² = M */
  function schwarzschildRadius(mGeom) { return mGeom; }

  /** 由几何质量反推物理质量：M_phys = r_s c² / (2G) */
  function massFromRs(rsMeters) { return rsMeters * C_LIGHT * C_LIGHT / (2 * G_NEWTON); }

  /** r_s = 2GM/c² */
  function rsFromMass(kg) { return 2 * G_NEWTON * kg / (C_LIGHT * C_LIGHT); }

  /** 圆形轨道角速度 Ω = sqrt(M/r³) */
  function circularOmega(mGeom, r) { return Math.sqrt(mGeom / (r * r * r)); }

  /** 开普勒第三定律：周期 T = 2π sqrt(a³/M) */
  function orbitalPeriod(mGeom, a) { return 2 * Math.PI * Math.sqrt(a * a * a / mGeom); }

  /**
   * 时间膨胀因子 dτ/dt = sqrt(1 - r_s/r)。
   * 静态观者所测固有时相对于无穷远时钟的流逝速率。
   */
  function timeDilation(mGeom, r) {
    var f = 1 - schwarzschildRadius(mGeom) / r;
    return f > 0 ? Math.sqrt(f) : 0;
  }

  /**
   * 相对论性近日点进动（每轨道弧度）—— 标准 1PN 弱场公式
   *   Δφ = 6πGM / (a(1-e²)c²)   → 几何单位下 = 6πM / (a(1-e²))
   * 这是教科书 / 水星 43″·世纪⁻¹ 所用的公式，要求 M/(a(1-e²)) ≪ 1。
   * 注：本演示的轨道 M/(a(1-e²)) ~ 0.3，属于较强场，实际进动会比它更大，
   *     真实数值以 tests/physics.test.js 里 φ 空间的 Binet 数值基准为准。
   */
  function perihelionPrecession(mGeom, a, e) {
    if (a <= 0) return 0;
    return 6 * Math.PI * mGeom / (a * (1 - e * e));
  }

  /**
   * 同一条运动方程的近圆轨道精确解（径向振荡的线性化频率）：
   *   Δφ = 2π/√(1 - 6M²/h²) - 2π,     h² = Ma(1-e²)
   * e → 0 时它 → 标准公式；e 大时它仍不适用（径向振荡已强非线性）。
   * 保留它是为了在测试里展示"标准公式是弱场一阶近似"这一事实。
   */
  function perihelionPrecessionLinear(mGeom, a, e) {
    var h2 = mGeom * a * (1 - e * e);
    if (h2 <= 0) return 0;
    var q = 1 - 6 * mGeom * mGeom / h2;
    if (q <= 0) return Infinity;
    return 2 * Math.PI * (1 / Math.sqrt(q) - 1);
  }

  /* -------------------------------------------------- PN 近似轨道积分 (orbit) */
  /**
   * 后牛顿(1PN)近似的相对论修正加速度（几何单位 G=c=1）：
   *   a = -(M/r³)·x·(1 + 3K·h²/r²)
   * 其中 h 是轨道的守恒角动量（一次算出后不再变动），K 是 1PN 强度。
   *
   * 说明：
   *  - 真实引力中 K ≡ 1，上式即标准 1PN 中心力，近日点进动率为
   *       Δφ = 6πM/(a(1-e²))·K
   *    与 perihelionPrecession() 一致（见 tests/physics.test.js）。
   *  - 教学场景里允许 K > 1 来放大进动这一视觉效果。
   *  - h 必须取"轨道要素推得的标称值"，若改用逐点瞬时值会让修正项偏大，
   *    进动率随之偏离解析公式（曾经踩过这个坑，已在测试中锁死）。
   */
  function nominalH(mGeom, a, e) {
    return Math.sqrt(Math.max(mGeom * a * (1 - e * e), 0));
  }

  function accel(x, z, vx, vz, mGeom, K, h2) {
    var r2 = x * x + z * z;
    var r = Math.sqrt(r2) + 1e-12;
    var r4 = r2 * r2 + 1e-12;
    // -M/r² · (1 + 3Kh²/r²)  →  a = -M·x/r³ - 3KMh²·x/r⁵
    // 注意修正项是 1/r⁴ 量级（写成 1/r² 会在强场把轨道直接拉进视界，实测过）
    var mag = mGeom / (r2 * r) + 3 * K * mGeom * h2 / (r4 * r);
    return { ax: -mag * x, az: -mag * z };
  }

  function rk4(x, z, vx, vz, dt, mGeom, K, h2) {
    var a1 = accel(x, z, vx, vz, mGeom, K, h2);
    var x2 = x + vx * dt * 0.5, z2 = z + vz * dt * 0.5;
    var vx2 = vx + a1.ax * dt * 0.5, vz2 = vz + a1.az * dt * 0.5;
    var a2 = accel(x2, z2, vx2, vz2, mGeom, K, h2);
    var x3 = x + vx2 * dt * 0.5, z3 = z + vz2 * dt * 0.5;
    var vx3 = vx + a2.ax * dt * 0.5, vz3 = vz + a2.az * dt * 0.5;
    var a3 = accel(x3, z3, vx3, vz3, mGeom, K, h2);
    var x4 = x + vx3 * dt, z4 = z + vz3 * dt;
    var vx4 = vx + a3.ax * dt, vz4 = vz + a3.az * dt;
    var a4 = accel(x4, z4, vx4, vz4, mGeom, K, h2);
    return {
      x: x + dt / 6 * (vx + 2 * vx2 + 2 * vx3 + vx4),
      z: z + dt / 6 * (vz + 2 * vz2 + 2 * vz3 + vz4),
      vx: vx + dt / 6 * (a1.ax + 2 * a2.ax + 2 * a3.ax + a4.ax),
      vz: vz + dt / 6 * (a1.az + 2 * a2.az + 2 * a3.az + a4.az)
    };
  }

  /**
   * RK4 轨道积分器（把 dt 拆成子步，保证近星点处精度）
   */
  function Orbit(opts) {
    opts = opts || {};
    this.m = opts.m != null ? opts.m : 1;
    this.K = opts.K != null ? opts.K : 1;
    this.a = opts.a != null ? opts.a : 1.2;
    this.e = opts.e != null ? opts.e : 0.6;
    this.substeps = opts.substeps || 8;
    this.h2 = 1;
    this.swept = 0;          // 累计扫过角度
    this.lastPhi = 0;
    this.periCount = 0;      // 已通过近日点次数
    this.precession = 0;     // 累计进动（弧度）
    this._prevDr = null;
    this._lastPeriT = -1e9;
    this._time = 0;
    this.reset();
  }

  Orbit.prototype.reset = function () {
    var p = this.a * (1 - this.e);           // 近星点距离
    var r = p;                               // 从近星点出发
    this.x = r; this.z = 0;
    // 近星点处速度纯切向： v = sqrt(M(1+e)/(a(1-e)))
    this.vz = Math.sqrt(this.m * (1 + this.e) / (this.a * (1 - this.e)));
    this.vx = 0;
    this.h2 = Math.pow(nominalH(this.m, this.a, this.e), 2);
    this.r = r;
    this.lastPhi = 0;
    this.swept = 0;
    this.periCount = 0;
    this.precession = 0;
    this._prevDr = null;
    this._lastPeriT = -1e9;
    this._time = 0;
  };

  /** 由当前位置与速度直接设定初值（用于抛射粒子） */
  Orbit.prototype.setInitial = function (x, z, vx, vz, hOverride) {
    this.x = x; this.z = z; this.vx = vx; this.vz = vz;
    var h = x * vz - z * vx;
    this.h2 = (hOverride != null ? hOverride : h) * (hOverride != null ? hOverride : h);
    this.lastPhi = Math.atan2(z, x);
    this.swept = 0; this.periCount = 0; this.precession = 0; this._prevDr = null;
    this._lastPeriT = -1e9; this._time = 0;
  };

  Orbit.prototype.step = function (dt) {
    var h = dt / this.substeps;
    for (var i = 0; i < this.substeps; i++) {
      var s = rk4(this.x, this.z, this.vx, this.vz, h, this.m, this.K, this.h2);
      this.x = s.x; this.z = s.z; this.vx = s.vx; this.vz = s.vz;
    }
    this._time += dt;
    var r = Math.sqrt(this.x * this.x + this.z * this.z);
    var phi = Math.atan2(this.z, this.x);

    // 累计扫过角度（处理 ±π 跨越）
    var dphi = phi - this.lastPhi;
    while (dphi > Math.PI) dphi -= 2 * Math.PI;
    while (dphi < -Math.PI) dphi += 2 * Math.PI;
    this.swept += dphi;
    this.lastPhi = phi;

    // 近日点检测：径向速度由负转正（r 的极小值）。再叠加"至少过了半个周期"
    // 的抑制，避免近圆轨道上 dr 在 0 附近抖动造成的重复计数。
    var dr = (this.x * this.vx + this.z * this.vz) / (r || 1e-9);
    var halfT = this.a > 0 ? Math.PI * Math.sqrt(this.a * this.a * this.a / this.m) : 0;
    if (this._prevDr != null && this._prevDr < 0 && dr >= 0 &&
        (this._time - this._lastPeriT) > halfT * 0.8) {
      this.periCount++;
      this._lastPeriT = this._time;
      this.precession = this.swept - this.periCount * 2 * Math.PI;
    }
    this._prevDr = dr;
    this.r = r;
    return this;
  };

  /** 瞬时轨道要素（HUD 读数用）。
   *  偏心率用偏心率矢量 e = (v×h)/M - r̂ 求，它是瞬时的、对所有轨道类型都成立；
   *  不要用 e² = 1 - h²/(Ma)——强场或双曲情形下那个式子会给出虚假的大偏心率。 */
  Orbit.prototype.elements = function () {
    var v2 = this.vx * this.vx + this.vz * this.vz;
    var r = this.r || 1e-9;
    var invA = 2 / r - v2 / this.m;                 // 活力公式
    var a = invA > 1e-9 ? 1 / invA : Infinity;
    var h = this.x * this.vz - this.z * this.vx;
    var ex = this.vz * h / this.m - this.x / r;
    var ez = -this.vx * h / this.m - this.z / r;
    var e = Math.sqrt(ex * ex + ez * ez);
    return { a: a, e: e, r: r, v: Math.sqrt(v2),
             period: a !== Infinity ? orbitalPeriod(this.m, a) : Infinity };
  };

  /* ------------------------------------------------- 引力波衰减 (Peters 1964) */
  /**
   * 四极辐射导致的轨道衰减（几何单位，两体总质量 M，等质量情形）：
   *   ⟨da/dt⟩ = -(64/5)·M³/a³
   * 于是 a(t) = a₀ (1 - t/T_m)^{1/4},  T_m = 5a₀⁴/(256 M³)
   */
  function mergerTime(a0, mGeom) { return 5 * Math.pow(a0, 4) / (256 * Math.pow(mGeom, 3)); }
  function separationAt(tau, a0) { var s = Math.pow(Math.max(tau, 0), 0.25); return a0 * s; }
  /** 由当前分离反推剩余时间比例 τ = (a/a₀)⁴ */
  function tauFromSeparation(a, a0) { var q = a / a0; return q * q * q * q; }

  /**
   * 两体圆轨道（等质量）：
   *   d = 分离度，每个成员到质心距离 d/2
   *   Ω = sqrt(M/d³)  (牛顿) × 1PN 修正 (1 + 3M/(2d)/... ) 近似用 1 + 3M/(4d)
   */
  function binaryOmega(mTotal, d) {
    return Math.sqrt(mTotal / (d * d * d)) * (1 + 0.75 * mTotal / d);
  }
  /** 引力波频率 ≈ 2×轨道频率 */
  function gwFrequency(mTotal, d) { return 2 * binaryOmega(mTotal, d) / (2 * Math.PI); }
  /** 轨道线速度 / c 的粗略估计（用于判断相对论性强弱） */
  function orbitalBeta(mTotal, d) { return 0.5 * Math.sqrt(mTotal / d); }

  /** 并合余核质量（等质量、无自旋，数值相对论拟合值 ≈ 0.951 M） */
  function remnantMass(mTotal) { return 0.951 * mTotal; }

  /* ---------------------------------------------------- 测地线演示 / 落体 */
  /**
   * 静止释放的自由落体（径向），1PN 意义下：
   *   d²r/dt² = -M/r² (1 + 3K h²/r²)，h = 0 → 纯牛顿
   * 这里给出解析的牛顿自由落体时间（Cycloid 解）用于 HUD 参考：
   *   t_fall = π/2 · sqrt(r₀³/(2M))
   */
  function freeFallTime(mGeom, r0) {
    return Math.PI * 0.5 * Math.sqrt(Math.pow(r0, 3) / (2 * mGeom));
  }

  return {
    C_LIGHT: C_LIGHT, G_NEWTON: G_NEWTON, M_SUN: M_SUN, AU: AU, EPS2: EPS2,
    surfaceAt: surfaceAt, heightAt: heightAt,
    schwarzschildRadius: schwarzschildRadius, massFromRs: massFromRs, rsFromMass: rsFromMass,
    circularOmega: circularOmega, orbitalPeriod: orbitalPeriod, timeDilation: timeDilation,
    perihelionPrecession: perihelionPrecession,
    perihelionPrecessionLinear: perihelionPrecessionLinear,
    nominalH: nominalH,
    accel: accel, rk4: rk4, Orbit: Orbit,
    mergerTime: mergerTime, separationAt: separationAt, tauFromSeparation: tauFromSeparation,
    binaryOmega: binaryOmega, gwFrequency: gwFrequency, orbitalBeta: orbitalBeta,
    remnantMass: remnantMass, freeFallTime: freeFallTime
  };
});
