/* ============================================================================
 * 弯曲时空模型 — 3D 场景 / 着色器    (Curved Spacetime — scene & shaders)
 * ----------------------------------------------------------------------------
 * 画面主体是一张被质量压弯的时空网（rubber-sheet / Flamm 抛物面）：
 *   y(x,z) = -Σ mᵢ / sqrt((x-xᵢ)² + (z-zᵢ)² + ε²)
 * 法向由 ∂y/∂x 解析求出（而非有限差分），因此光照平滑、凹陷有体积感。
 *
 * 引力波（双星并合）用解析四极辐射公式在顶点着色器里求值：
 *   d(t) = d₀·τ^{1/4},   τ = 1 - t/T_m,   T_m = 5d₀⁴/(256M³)     (Peters 1964)
 *   Φ(t) = k(1-τ^{5/8})                                        (啁啾相位)
 *   h(r,t) = A·τ(t-r/c)^{1/4}·cos(Φ(t-r/c) + 2φ)               (光速延迟 → 因果)
 * 于是外侧的波前被"冻结"成同心圆，内侧频率越来越高 —— 真实的 chirp 图像。
 * ========================================================================== */
(function (global) {
  'use strict';

  var TAU = Math.PI * 2;

  /* ------------------------------------------------------------- 画面常量 */
  var PLANE = 90;          // 平面边长（世界单位，够大以便被雾完全吃掉边缘）
  var CH = 22;             // 顶点高度裁剪（防尖刺）
  var FOG_NEAR = 26;       // 淡出起始距离
  var FOG_FAR = 82;        // 完全融入背景的距离
  var WAVE_C = 3.0;        // 引力波传播速度：网格单位 / 虚拟秒
  var MASS_MAX = 3;        // 着色器质量槽位数

  /* ============================================================== 着色器 */
  var VERT = [
    'precision highp float;',
    'uniform float uTime;',
    'uniform vec2  uMassPos[' + MASS_MAX + '];',
    'uniform float uMassM[' + MASS_MAX + '];',
    'uniform int   uMassCount;',
    'uniform float uDepth;',
    'uniform float uNoise;',
    'uniform float uRipple;',
    'uniform float uMergeT;',
    'uniform float uChirpPhase;',    // 当前啁啾相位 Φ(t)，由 JS 按严格解析式求值
    'uniform float uChirpAmp;',
    'uniform float uBinary;',
    'uniform float uBurst;',
    'uniform vec2  uSrc;',
    'varying vec3  vNormal;',
    'varying vec3  vT1;',
    'varying vec3  vT2;',
    'varying vec3  vPos;',
    'varying float vDepth;',
    'varying float vRip;',
    'const float EPS2 = 0.1225;',
    '',
    /* 啁啾相位 Φ(t) 的严格解（四极辐射，Peters 1964）：
         d = d₀·τ^{1/4},  dΦ/dt = 2Ω(d)  ⇒  Φ(t) = k·(1 - τ(t)^{5/8})
       Φ(0)=0，τ 随时间递减 ⇒ Φ 单调递增、频率 ∝ τ^{-3/8} 越来越高（chirp）。
       这里只用推迟时间造成的相位差，故 k 的常数倍无所谓：
         ΔΦ = uChirp(τ(t-r/c)^{5/8} - τ(t)^{5/8})
       它同时给出时间振荡（波前以 c 向外推进）与空间波长 λ = c·T_wave，
       因此因果性是精确的。t ≥ T_m 后 τ 夹紧 ⇒ 相位冻结，波前不会无限堆积。 */
    'float chirpTau(float t) {',
    '  return max(1.0 - clamp(t / uMergeT, 0.0, 1.0), 1e-4);',
    '}',
    'float chirpDelta(float t, float tp) {',
    '  return uChirpPhase * (pow(chirpTau(tp), 0.625) - pow(chirpTau(t), 0.625));',
    '}',
    '',
    /* 环形脉冲波包：波前半径为 R = (t - born)·c，包络光滑 */
    'float ringAt(vec2 p, vec2 j, float born, float w, float k) {',
    '  float R = (uTime - born) * ' + WAVE_C.toFixed(2) + ';',
    '  if (R < 0.08) return 0.0;',
    '  float u = length(p - j);',
    '  if (u > R) return 0.0;',
    '  float edge = clamp((R - u) / w, 0.0, 1.0);',
    '  float env = edge * edge * (3.0 - 2.0 * edge);',
    '  return sin((u - R) * k) * env;',
    '}',
    '',
    'void main() {',
    '  vec3 p = position;',
    '  vec2 q = p.xy;',
    '  float y = 0.0, gx = 0.0, gz = 0.0, rip = 0.0;',
    '',
    /* ---------- 1) 质量造成的引力井：y -= Σ m/√(d²+ε²) ---------- */
    '  for (int i = 0; i < ' + MASS_MAX + '; i++) {',
    '    vec2 d = q - uMassPos[i];',
    '    float m = (i < uMassCount) ? uMassM[i] : 0.0;',
    '    float s = dot(d, d) + EPS2;',
    '    float inv = inversesqrt(s);',
    '    y  -= m * inv;',
    '    float f = m * inv / s;',
    '    gx += f * d.x;',
    '    gz += f * d.y;',
    '  }',
    '  y *= uDepth; gx *= uDepth; gz *= uDepth;',
    '',
    /* ---------- 2) 远场：平坦的时空网一直铺到雾里（不加均匀曲率，
       否则巨大的抛物面会折起来挡住视线）。远处由 fragment 的距离淡出处理。 ---------- */
    /* ---------- 3) 引力波场 ---------- */
    '  if (uRipple > 0.001) {',
    '    if (uBinary > 0.5) {',
    /* 3a) 连续啁啾：光速延迟 uTime-rd 给出因果波前；相位随推迟时间演化 */
    '      float rd = distance(q, uSrc) / ' + WAVE_C.toFixed(2) + ';',
    '      float tm = max(uTime - rd, 0.0);',
    '      float tau = 1.0 - clamp(tm / uMergeT, 0.0, 1.0);',
    '      float dph = chirpDelta(uTime, tm);',
    '      vec2 dir = q - uSrc;',
    '      float az = atan(dir.y, dir.x);',
    /* 四极(l=2)方向图；螺旋相位锁定在啁啾相位上 → 波前呈双臂螺旋 */
    '      float l2 = cos(2.0 * az + dph);',
    '      float win = exp(-rd * 0.20) * smoothstep(0.0, 1.6, tm);',
    '      rip += uChirpAmp * pow(tau, 0.25) * win * (0.45 + 0.55 * l2) * sin(dph + 2.0 * az);',
    '    }',
    /* 3b) 并合前抛出的强脉冲环：一圈圈向外扩散 —— 明显的同心圆波纹 */
    '    for (int i = 0; i < 3; i++) {',
    '      float bt = uMergeT * (0.52 + 0.16 * float(i));',
    '      rip += ringAt(q, uSrc, bt, 1.2 + 0.5 * float(i), 0.9) * uBurst * (1.0 + 0.35 * float(i));',
    '    }',
    /* 3c) 时空泡沫（纯视觉噪声） */
    '    rip += uNoise * 0.06 * sin(q.x * 0.62 + uTime * 1.7) * sin(q.y * 0.55 - uTime * 1.3);',
    '    y += rip * uRipple;',
    '  }',
    '',
    /* ---------- 4) 解析法向 + 切平面基 ---------- */
    '  vec3 n = normalize(vec3(-gx, 1.0, -gz));',
    '  float gl = length(vec2(gx, gz));',
    '  vec3 e1 = (gl > 1e-5) ? normalize(vec3(gz, 0.0, -gx)) : vec3(1.0, 0.0, 0.0);',
    '  vec3 e2 = normalize(cross(n, e1));',
    '',
    '  p.z = clamp(y, -' + CH.toFixed(1) + ', ' + CH.toFixed(1) + ');',
    '  gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);',
    '  vNormal = n; vT1 = e1; vT2 = e2;',
    '  vPos = (modelMatrix * vec4(p, 1.0)).xyz;',
    '  vDepth = y;',
    '  vRip = rip;',
    '}'
  ].join('\n');

  var FRAG = [
    'precision highp float;',
    'uniform float uGrid;',
    'uniform float uRS;',
    'uniform vec3  uFogColor;',
    'uniform vec3  uAccent;',
    'uniform float uGlow;',
    'varying vec3  vNormal;',
    'varying vec3  vT1;',
    'varying vec3  vT2;',
    'varying vec3  vPos;',
    'varying float vDepth;',
    'varying float vRip;',
    '',
    'float gridLine(vec2 g) {',
    '  vec2 w = fwidth(g);',
    '  vec2 f = abs(fract(g - 0.5) - 0.5) / max(w, vec2(1e-6));',
    '  return 1.0 - min(min(f.x, f.y), 1.0);',
    '}',
    '',
    'void main() {',
    '  vec3 N = normalize(vNormal);',
    '  vec3 V = normalize(cameraPosition - vPos);',
    '  vec3 L = normalize(vec3(0.55, 0.85, 0.35));',
    '  float d = max(0.0, dot(N, L));',
    '  float spec = pow(max(dot(reflect(-L, N), V), 0.0), 30.0);',
    '  float fres = pow(1.0 - max(dot(N, V), 0.0), 2.6);',
    '',
    /* 深度着色：平坦处是暗蓝海面 → 深井里转为暖金（深度即弯曲程度） */
    '  float dep = clamp(-vDepth / 2.2, 0.0, 1.0);',
    '  vec3 col = mix(vec3(0.030, 0.065, 0.155), vec3(0.105, 0.085, 0.225), smoothstep(0.0, 0.5, dep));',
    '  col = mix(col, vec3(0.30, 0.16, 0.06), smoothstep(0.42, 1.0, dep));',
    '  vec3 lineCol = mix(vec3(0.42, 0.78, 1.00), vec3(1.00, 0.78, 0.40), smoothstep(0.08, 0.90, dep));',
    '  lineCol += vec3(0.35, 0.60, 1.00) * min(abs(vRip) * 2.2, 0.9);',
    '',
    '  float major = ' + (PLANE / 8).toFixed(2) + ';',
    '  float g  = gridLine(vPos.xz * uGrid);',
    '  float gm = gridLine(vPos.xz * uGrid / major);',
    '  float lines = clamp(g * 0.85 + gm * 1.00, 0.0, 1.0);',
    '',
    '  vec3 outc = col + lineCol * lines * uGlow;',
    '  outc += spec * (0.25 + 0.75 * lines) * vec3(0.45, 0.55, 0.80);',
    '  outc += fres * (0.05 + 0.25 * lines) * mix(vec3(0.25, 0.55, 1.0), uAccent, dep);',
    '',
    /* 视界环：史瓦西半径处的高光环 */
    '  float rd = length(vPos.xz);',
    '  float ring = exp(-pow((rd - uRS) / 0.32, 2.0));',
    '  outc += vec3(1.60, 1.05, 0.50) * ring * 1.3;',
    '',
    /* 距离淡出（伪景深）：远处网格化入背景，同时保持写深度（早期 discard） */
    '  float dist = length(vPos - cameraPosition);',
    '  float fade = 1.0 - smoothstep(' + FOG_NEAR.toFixed(1) + ', ' + FOG_FAR.toFixed(1) + ', dist);',
    '  float a = clamp(fade + ring * 0.9, 0.0, 1.0);',
    '  if (a < 0.05) discard;',
    '  gl_FragColor = vec4(mix(uFogColor, outc, a), 1.0);',
    '}'
  ].join('\n');

  /* ============================================================ 场景搭建 */
  function create(opts) {
    var S = {};
    var canvas = opts.canvas;
    var cfg = opts.config;

    S.renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, alpha: false });
    S.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, cfg.maxPixelRatio || 2));
    S.renderer.setClearColor(0x04060d, 1);
    S.renderer.autoClear = true;

    S.scene = new THREE.Scene();
    S.camera = new THREE.PerspectiveCamera(46, 1, 0.1, 600);
    S.camera.position.set(0, 13.5, 19.5);

    S.controls = new THREE.OrbitControls(S.camera, canvas);
    S.controls.target.set(0, -0.8, 0);
    S.controls.enableDamping = true;
    S.controls.dampingFactor = 0.07;
    S.controls.minDistance = 2.5;
    S.controls.maxDistance = 80;
    S.controls.maxPolarAngle = Math.PI * 0.495;
    S.controls.autoRotate = cfg.autoRotate;
    S.controls.autoRotateSpeed = 0.32;
    S.controls.update();

    /* ---------------------------------------------------------- 背景星空 */
    (function stars() {
      var N = 4200;
      var pos = new Float32Array(N * 3), col = new Float32Array(N * 3), sz = new Float32Array(N);
      for (var i = 0; i < N; i++) {
        var u = Math.random() * 2 - 1, th = Math.random() * TAU, s = Math.sqrt(1 - u * u);
        var R = 70 + Math.random() * 90;
        pos[i * 3] = Math.cos(th) * s * R;
        pos[i * 3 + 1] = Math.abs(u) * R * 0.95 + 3;
        pos[i * 3 + 2] = Math.sin(th) * s * R;
        var t = Math.random();
        var c = t < 0.70 ? [0.78, 0.86, 1.0] : (t < 0.93 ? [1.0, 0.93, 0.80] : [1.0, 0.74, 0.64]);
        var b = 0.22 + Math.random() * 0.78;
        col[i * 3] = c[0] * b; col[i * 3 + 1] = c[1] * b; col[i * 3 + 2] = c[2] * b;
        sz[i] = 0.6 + Math.random() * 1.9;
      }
      var g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      g.setAttribute('color', new THREE.BufferAttribute(col, 3));
      g.setAttribute('aSize', new THREE.BufferAttribute(sz, 1));
      var mat = new THREE.ShaderMaterial({
        transparent: true, depthTest: false, depthWrite: false,
        blending: THREE.AdditiveBlending, vertexColors: true,
        uniforms: { uPix: { value: S.renderer.getPixelRatio() } },
        vertexShader: [
          'attribute float aSize; varying vec3 vC; uniform float uPix;',
          'void main(){ vC = color; vec4 mv = modelViewMatrix * vec4(position,1.0);',
          ' gl_PointSize = aSize * 1.6 * uPix;',
          ' gl_Position = projectionMatrix * mv; }'
        ].join('\n'),
        fragmentShader: [
          'varying vec3 vC;',
          'void main(){ vec2 d = gl_PointCoord - 0.5; float r = length(d);',
          ' float a = smoothstep(0.5, 0.05, r);',
          ' gl_FragColor = vec4(vC, a * a * 0.85); }'
        ].join('\n')
      });
      S.stars = new THREE.Points(g, mat);
      S.stars.frustumCulled = false;
      S.stars.renderOrder = 20;
      S.starsMat = mat;
      S.scene.add(S.stars);
    })();

    /* ----------------------------------------------------- 时空曲面 uniform */
    S.uniforms = {
      uTime: { value: 0 },
      uMassPos: { value: new Float32Array(MASS_MAX * 2) },
      uMassM: { value: new Float32Array(MASS_MAX) },
      uMassCount: { value: 1 },
      uDepth: { value: cfg.depth },
      uNoise: { value: cfg.noise },
      uRipple: { value: cfg.ripple },
      uMergeT: { value: cfg.mergeTime },
      uChirpPhase: { value: 0 },
      uBinary: { value: 0 },
      uBurst: { value: 0.16 },
      uChirpAmp: { value: 0.42 },
      uSrc: { value: new THREE.Vector2(0, 0) },
      uGrid: { value: cfg.gridScale },
      uRS: { value: 0.85 },
      uFogColor: { value: new THREE.Color(0x04060d) },
      uAccent: { value: new THREE.Color(0xffb457) },
      uGlow: { value: 1.0 }
    };

    S.gridMat = new THREE.ShaderMaterial({
      uniforms: S.uniforms,
      vertexShader: VERT,
      fragmentShader: FRAG,
      transparent: false,
      depthWrite: true,
      depthTest: true,
      side: THREE.DoubleSide,
      polygonOffset: true,
      polygonOffsetFactor: 1.0,
      polygonOffsetUnits: 1.0
    });

    S.buildGrid = function (n) {
      if (S.grid) { S.scene.remove(S.grid); S.grid.geometry.dispose(); }
      S.seg = n;
      var g = new THREE.PlaneGeometry(PLANE, PLANE, n, n);
      S.grid = new THREE.Mesh(g, S.gridMat);
      S.grid.rotation.x = -Math.PI / 2;
      S.grid.frustumCulled = false;
      S.grid.renderOrder = 1;
      S.scene.add(S.grid);
    };
    S.buildGrid(cfg.segments);

    /* ------------------------------------------------------------ 中心天体 */
    S.body = new THREE.Group();
    S.body.renderOrder = 3;
    S.scene.add(S.body);

    S.horizon = new THREE.Mesh(new THREE.SphereGeometry(1, 48, 32),
      new THREE.MeshBasicMaterial({ color: 0x000000 }));
    S.horizon.renderOrder = 3;
    S.body.add(S.horizon);

    S.core = new THREE.Mesh(new THREE.SphereGeometry(1, 48, 32), new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, depthTest: true,
      blending: THREE.AdditiveBlending,
      uniforms: { uTime: { value: 0 } },
      vertexShader: [
        'varying vec3 vN; varying vec3 vP;',
        'void main(){ vN = normalize(normalMatrix * normal);',
        ' vec4 mv = modelViewMatrix * vec4(position,1.0); vP = mv.xyz;',
        ' gl_Position = projectionMatrix * mv; }'
      ].join('\n'),
      fragmentShader: [
        'varying vec3 vN; varying vec3 vP; uniform float uTime;',
        'void main(){',
        '  vec3 V = normalize(-vP);',
        '  float f = pow(1.0 - max(dot(normalize(vN), V), 0.0), 2.0);',
        '  vec3 hot = mix(vec3(1.0, 0.95, 0.84), vec3(1.0, 0.60, 0.18), f);',
        '  float pulse = 0.93 + 0.07 * sin(uTime * 1.7);',
        '  gl_FragColor = vec4(hot * (0.55 + 1.5 * f) * pulse, clamp(0.5 + 1.3 * f, 0.0, 1.0));',
        '}'
      ].join('\n')
    }));
    S.core.renderOrder = 4;
    S.body.add(S.core);

    /* 吸积盘 */
    function makeDisk(count, rIn, rOut, color, alpha) {
      var g = new THREE.BufferGeometry();
      var pos = new Float32Array(count * 3), col = new Float32Array(count * 3), sz = new Float32Array(count);
      var base = new THREE.Color(color), white = new THREE.Color(0xffffff);
      for (var i = 0; i < count; i++) {
        var a = Math.random() * TAU;
        var t = Math.pow(Math.random(), 0.65);
        var r = rIn + (rOut - rIn) * t;
        pos[i * 3] = Math.cos(a) * r;
        pos[i * 3 + 1] = (Math.random() - 0.5) * (0.04 + 0.20 * t);
        pos[i * 3 + 2] = Math.sin(a) * r;
        var c = base.clone().lerp(white, Math.pow(1 - t, 2.0) * 0.9);
        col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
        sz[i] = 1.0 + Math.random() * 2.2;
      }
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      g.setAttribute('color', new THREE.BufferAttribute(col, 3));
      g.setAttribute('aSize', new THREE.BufferAttribute(sz, 1));
      var m = new THREE.Points(g, new THREE.ShaderMaterial({
        transparent: true, depthWrite: false, depthTest: true,
        blending: THREE.AdditiveBlending, vertexColors: true,
        uniforms: { uAlpha: { value: alpha }, uPix: { value: S.renderer.getPixelRatio() } },
        vertexShader: [
          'attribute float aSize; varying vec3 vC; uniform float uPix;',
          'void main(){ vC = color; vec4 mv = modelViewMatrix * vec4(position,1.0);',
          ' gl_PointSize = aSize * uPix * clamp(26.0 / max(-mv.z, 1.0), 0.6, 6.0);',
          ' gl_Position = projectionMatrix * mv; }'
        ].join('\n'),
        fragmentShader: [
          'uniform float uAlpha; varying vec3 vC;',
          'void main(){ vec2 d = gl_PointCoord - 0.5; float r = length(d);',
          ' float a = smoothstep(0.5, 0.02, r);',
          ' gl_FragColor = vec4(vC, a * a * uAlpha); }'
        ].join('\n')
      }));
      m.frustumCulled = false;
      m.renderOrder = 5;
      return m;
    }
    S.disk = makeDisk(2400, 1.45, 6.2, 0xff9a3c, 0.5);
    S.body.add(S.disk);

    S.updateBody = function (radius, isBlackHole) {
      S.core.visible = !isBlackHole;
      S.horizon.visible = isBlackHole;
      S.disk.visible = isBlackHole;
      S.horizon.scale.setScalar(radius);
      S.core.scale.setScalar(radius * 0.98);
      S.disk.scale.setScalar(Math.max(radius, 0.4));
    };

    /* -------------------------------------------------------- 双星成员球 */
    S.companions = [];
    for (var k = 0; k < 2; k++) {
      var mesh = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 24),
        new THREE.MeshBasicMaterial({ color: 0x000000 }));
      var halo = new THREE.Mesh(new THREE.SphereGeometry(1.6, 32, 24),
        new THREE.MeshBasicMaterial({ color: 0xffb066, transparent: true, opacity: 0.18,
                                      blending: THREE.AdditiveBlending, depthWrite: false, depthTest: false }));
      mesh.add(halo);
      mesh.visible = false;
      mesh.renderOrder = 6;
      S.scene.add(mesh);
      S.companions.push(mesh);
    }

    /* ------------------------------------------------------------ 轨道轨迹 */
    function makeTrail() {
      var N = 1100;
      var pos = new Float32Array(N * 3), col = new Float32Array(N * 3);
      var g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3).setUsage(THREE.DynamicDrawUsage));
      g.setAttribute('color', new THREE.BufferAttribute(col, 3).setUsage(THREE.DynamicDrawUsage));
      g.setDrawRange(0, 0);
      var l = new THREE.Line(g, new THREE.LineBasicMaterial({
        vertexColors: true, transparent: true, opacity: 0.92,
        blending: THREE.AdditiveBlending, depthWrite: false, depthTest: true
      }));
      l.frustumCulled = false;
      l.renderOrder = 7;
      S.scene.add(l);
      return { line: l, geo: g, pos: pos, col: col, cap: N, n: 0, head: 0, acc: 0 };
    }
    S.trailA = makeTrail();
    S.trailB = makeTrail();

    /* --------------------------------------------------------- 试验粒子群 */
    var PN = 2600;
    var pPos = new Float32Array(PN * 3), pCol = new Float32Array(PN * 3), pSz = new Float32Array(PN);
    var pg = new THREE.BufferGeometry();
    pg.setAttribute('position', new THREE.BufferAttribute(pPos, 3).setUsage(THREE.DynamicDrawUsage));
    pg.setAttribute('color', new THREE.BufferAttribute(pCol, 3).setUsage(THREE.DynamicDrawUsage));
    pg.setAttribute('aSize', new THREE.BufferAttribute(pSz, 1).setUsage(THREE.DynamicDrawUsage));
    S.particles = new THREE.Points(pg, new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, depthTest: true,
      blending: THREE.AdditiveBlending, vertexColors: true,
      uniforms: { uPix: { value: S.renderer.getPixelRatio() }, uScale: { value: 1 } },
      vertexShader: [
        'attribute float aSize; varying vec3 vC; uniform float uPix; uniform float uScale;',
        'void main(){ vC = color; vec4 mv = modelViewMatrix * vec4(position,1.0);',
        ' gl_PointSize = aSize * uPix * uScale * clamp(30.0 / max(-mv.z, 1.0), 0.5, 9.0);',
        ' gl_Position = projectionMatrix * mv; }'
      ].join('\n'),
      fragmentShader: [
        'varying vec3 vC;',
        'void main(){ vec2 d = gl_PointCoord - 0.5; float r = length(d);',
        ' float a = smoothstep(0.5, 0.0, r);',
        ' gl_FragColor = vec4(vC, a * a); }'
      ].join('\n')
    }));
    S.particles.frustumCulled = false;
    S.particles.renderOrder = 8;
    S.scene.add(S.particles);
    S.pBuf = { pos: pPos, col: pCol, sz: pSz, max: PN, n: 0 };

    /* ----------------------------------------------------------- 交互高度场 */
    S.sampleAt = function (x, z) {
      var u = S.uniforms;
      var cnt = u.uMassCount.value;
      var y = 0, gx = 0, gz = 0;
      for (var i = 0; i < cnt; i++) {
        var dx = x - u.uMassPos.value[i * 2], dz = z - u.uMassPos.value[i * 2 + 1];
        var s = dx * dx + dz * dz + 0.1225;
        var inv = 1 / Math.sqrt(s);
        y -= u.uMassM.value[i] * inv;
        var f = u.uMassM.value[i] * inv / s;
        gx += f * dx; gz += f * dz;
      }
      y *= u.uDepth.value; gx *= u.uDepth.value; gz *= u.uDepth.value;
      return { y: THREE.MathUtils.clamp(y, -CH, CH), gx: gx, gz: gz };
    };

    S.resize = function (w, h) {
      S.camera.aspect = w / h;
      S.camera.updateProjectionMatrix();
      S.renderer.setSize(w, h, false);
    };

    S.PLANE = PLANE; S.CH = CH;
    return S;
  }

  global.STScene = {
    create: create,
    PLANE: PLANE,
    CH: CH,
    WAVE_C: WAVE_C,
    MASS_MAX: MASS_MAX,
    VERT: VERT,
    FRAG: FRAG
  };
})(window);
