/* ============================================================================
 * 极简静态服务器（源码版预览用）
 *   node tools/serve.mjs [port]        port 省略或为 0 时自动挑空闲端口
 * 只依赖 Node 内置模块，用于本地打开 index.html（多文件版）。
 * 单文件版 curved-spacetime.html 不需要服务器，直接双击即可。
 * ========================================================================== */
import http from 'node:http';
import { readFileSync, existsSync, statSync } from 'node:fs';
import { resolve, dirname, extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const port = Number(process.argv[2] || 0);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.md': 'text/markdown; charset=utf-8'
};

const server = http.createServer((req, res) => {
  try {
    let p = decodeURIComponent((req.url || '/').split('?')[0]);
    if (p === '/') p = '/index.html';
    const file = normalize(join(root, p));
    if (!file.startsWith(root)) { res.writeHead(403); return res.end('403'); }
    if (!existsSync(file) || !statSync(file).isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('404 ' + p);
    }
    res.writeHead(200, {
      'Content-Type': MIME[extname(file).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-store'
    });
    res.end(readFileSync(file));
  } catch (e) {
    res.writeHead(500); res.end('500 ' + e.message);
  }
});

server.listen(port, '127.0.0.1', () => {
  const p = server.address().port;
  console.log('弯曲时空 · 源码版已启动');
  console.log('  http://127.0.0.1:' + p + '/index.html');
  console.log('  （单文件版不需要服务器：直接双击 curved-spacetime.html）');
  console.log('按 Ctrl+C 停止');
});
