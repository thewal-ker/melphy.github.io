/* ============================================================================
 * 单文件版离线验收：用 file:// 直接打开 curved-spacetime.html
 *   node tests/standalone.mjs
 * 验证点：真的离线可跑（file:// + 无服务器 + 无网络）、无控制台错误、
 *         着色器全部链接通过、画面确实渲染出内容。
 * ========================================================================== */
import { readFileSync, existsSync, writeFileSync, mkdirSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { resolve, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const __dir = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dir, '..');
const shots = resolve(root, 'shots');
mkdirSync(shots, { recursive: true });
const sleep = ms => new Promise(r => setTimeout(r, ms));

const target = resolve(root, 'curved-spacetime.html');
if (!existsSync(target)) { console.error('先运行 node tools/build-standalone.mjs'); process.exit(2); }

const CANDIDATES = [
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
  (process.env.LOCALAPPDATA || '') + '/Google/Chrome/Application/chrome.exe'
];
const exe = CANDIDATES.find(p => p && existsSync(p));
if (!exe) { console.error('找不到 Edge/Chrome'); process.exit(2); }

const CDP_PORT = 9600 + (process.pid % 300);
const args = [
  '--headless=new', '--no-sandbox', '--disable-gpu-sandbox',
  '--enable-unsafe-swiftshader', '--use-gl=angle', '--use-angle=swiftshader',
  '--hide-scrollbars', '--force-device-scale-factor=1', '--window-size=1440,860',
  '--user-data-dir=' + resolve(root, '.chrome-cdp-single'),
  '--remote-debugging-port=' + CDP_PORT,
  '--allow-file-access-from-files',
  '--no-first-run', '--no-default-browser-check',
  'about:blank'
];
const proc = spawn(exe, args, { stdio: 'ignore', windowsHide: true });

let wsUrl = null;
for (let i = 0; i < 60 && !wsUrl; i++) {
  await sleep(300);
  try {
    const r = await fetch('http://127.0.0.1:' + CDP_PORT + '/json/version');
    if (r.ok) wsUrl = (await r.json()).webSocketDebuggerUrl;
  } catch {}
}
if (!wsUrl) { console.error('CDP 未就绪'); proc.kill(); process.exit(2); }

const ws = new WebSocket(wsUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = () => rej(new Error('ws')); });
let id = 0; const pending = new Map();
const consoleMsgs = [];
ws.onmessage = ev => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) {
    const { res, rej } = pending.get(m.id); pending.delete(m.id);
    m.error ? rej(new Error(JSON.stringify(m.error))) : res(m.result);
  } else if (m.method === 'Runtime.exceptionThrown') {
    consoleMsgs.push('EXCEPTION: ' + (m.params.exceptionDetails.exception?.description || m.params.exceptionDetails.text));
  } else if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') {
    consoleMsgs.push('ERROR: ' + m.params.entry.text);
  }
};
const cdp = (method, params = {}, sessionId) => new Promise((res, rej) => {
  const i = ++id; pending.set(i, { res, rej });
  ws.send(JSON.stringify({ id: i, method, params, sessionId }));
  setTimeout(() => { if (pending.has(i)) { pending.delete(i); rej(new Error('timeout ' + method)); } }, 60000);
});

const { targetId } = await cdp('Target.createTarget', { url: 'about:blank' });
const { sessionId } = await cdp('Target.attachToTarget', { targetId, flatten: true });
const S = (m, p) => cdp(m, p, sessionId);
await S('Runtime.enable'); await S('Log.enable'); await S('Page.enable');

const fileUrl = pathToFileURL(target).href;
console.log('打开文件 :', fileUrl);
await S('Page.navigate', { url: fileUrl });
await sleep(4000);

const evalJs = async expr => {
  const r = await S('Runtime.evaluate', { expression: expr, returnByValue: true });
  return r.exceptionDetails ? { __error: r.exceptionDetails.exception?.description } : r.result.value;
};

const info = await evalJs(`(() => {
  const c = document.getElementById('gl');
  const app = window.STApp;
  return JSON.stringify({
    title: document.title,
    hasApp: !!app,
    renderer: !!(app && window.__REND__),
    canvas: c ? [c.width, c.height] : null,
    mode: app ? app.ST.mode : null,
    simTime: app ? +app.ST.simTime.toFixed(2) : null,
    fps: app ? +app.ST.fps.toFixed(1) : null,
    three: window.THREE ? window.THREE.REVISION || 'r128' : null,
    loadingHidden: document.getElementById('loading').classList.contains('hide'),
    // 真正的外部引用（data: URI 不算）
    externalRefs: Array.from(document.querySelectorAll('script[src], link[href]'))
      .filter(el => !/^data:/.test(el.getAttribute('src') || el.getAttribute('href') || '')).length
  });
})()`);
console.log('页面状态 :', info);

await sleep(6000);
const later = await evalJs(`JSON.stringify({
  simTime: +STApp.ST.simTime.toFixed(2),
  fps: +STApp.ST.fps.toFixed(1),
  r: +STApp.ST.orbit.r.toFixed(3),
  hud: document.getElementById('rRS').textContent + ' | ' + document.getElementById('rVel').textContent +
       ' | ' + document.getElementById('rPrec').textContent
})`);
console.log('6 秒后   :', later);

const shot = await S('Page.captureScreenshot', { format: 'png' });
writeFileSync(resolve(shots, 'standalone.png'), Buffer.from(shot.data, 'base64'));

console.log('\n控制台错误:', consoleMsgs.length ? consoleMsgs.slice(0, 8) : '无');
console.log('截图:', resolve(shots, 'standalone.png'));

const ok = info && !info.__error && /hasApp/.test(info) && JSON.parse(info).hasApp &&
           JSON.parse(info).loadingHidden && JSON.parse(info).externalRefs === 0 && consoleMsgs.length === 0;
console.log(ok ? '\n✓ 单文件离线版可独立运行' : '\n✗ 单文件版存在问题');

ws.close(); proc.kill();
await sleep(300);
process.exit(ok ? 0 : 1);
