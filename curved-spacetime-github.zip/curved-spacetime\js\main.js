/* ============================================================================
 * 弯曲时空模型 — 主程序 (Curved Spacetime — application)
 * ----------------------------------------------------------------------------
 * 三种演示：
 *   ① 单星测地线   — 行星在弯曲时空里沿测地线运行，可见近日点进动（罗塞塔轨迹）
 *   ② 双黑洞并合   — 间距按四极辐射衰减 d∝τ^{1/4}，向外辐射啁啾引力波
 *   ③ 时空曲率实验 — 点击时空网投掷试验粒子，观察束缚轨道 / 逃逸 / 坠入视界
 * ========================================================================== */
(function (global) {
  'use strict';

  var Ph = global.STPhysics;
  var TAU = Math.PI * 2;
  var DEG = 180 / Math.PI;

  /* ============================================================ 配置与状态 */
  var CFG = {
    depth: 1.9,           // 引力井深度系数
    noise: 0.35,          // 时空泡沫
    ripple: 1.6,          // 引力波幅度
    massSlider: 0.85,     // 中心天体质量（网格单位 / 世界单位）
    precession: 1.0,      // 1PN 强度
    timeScale: 1.0,       // 时间流速
    gridScale: 2.0,      // 网格密度
    segments: 256,        // 网格分辨率
    autoRotate: true,
    showTrail: true,
    showDisk: true,
    ellipse: 0.42,        // 轨道偏心率
    binStart: 3.0,        // 双星初始间距（单位：两体 r_s）
    animSeconds: 16,      // 一段啁啾在画面上占多少秒（×timeScale）
    orbitSeconds: 7,      // 一圈轨道在画面上占多少秒（×timeScale）
    maxPixelRatio: 2
  };

  var ST = {
    mode: 'single',
    paused: false,
    simTime: 0,
    realTime: 0,
    warpedTime: 0,
    gamma: 1,
    U: 1,                 // 啁啾参数：1 虚拟秒 = U 真实秒
    rS: 0.85,
    massKg: 0,
    depth: CFG.depth,
    orbit: null,
    fps: 60,
    // binary
    bin: { d: 6, d0: 6, dEnd: 4, phase: 0, tau: 1, merged: false, tMerge: 0, Tm: 1 },
    // interaction
    parts: [],
    lastOrbitHud: 0
  };

  var S, dom = {};

  /* ==========================================================================
   * 时间标度（本模型最需要小心的地方）
   * --------------------------------------------------------------------------
   * 几何单位下 1 网格长度 = r_s 量级、1 网格时间单位 = r_s/c。默认黑洞的质量
   * 落在 10⁶ M☉ 量级（r_s ≈ 1.2×10¹⁰ m），于是天文上真实的尺度是：
   *   近 ISCO 圆轨道周期 ~ 1 毫秒、并合时标 ~ 5 毫秒、引力波频率 ~ 百 Hz。
   * 直接按真实时间播放，画面在第一个采样点前就结束了。所以这里把两件事分开：
   *
   *   ① 所有读数（周期、频率、v/c、时间膨胀）一律用真实单位，由 T_GU 换算；
   *   ② 画面用"虚拟时间"播放：K_SLOW 是每模拟秒推进多少虚拟秒，只影响观感。
   *      并合模式的 K_SLOW 由"想看的动画时长"反推，所以不管双星从多远处开始，
   *      画面里都是一段十几秒的完整啁啾。
   *
   * 必须诚实说明的一点（可用上面的公式直接验证）：
   *   虚拟时间里的波速 c 与并合时标 T_m 满足 λ = c·T_m ≫ 网格尺度，
   *   也就是说"载波波纹铺满网格"在物理上是不可能的 —— 引力波的波长本来就是
   *   上百个史瓦西半径。所以画面上看到的是：随时间膨胀的啁啾包络、
   *   旋转的四极(l=2)方向图、以及并合前抛出的同心脉冲环，
   *   而不是把网格当成水波那样密密的涟漪。
   * ========================================================================== */
  var K_SLOW = 1.0;                      // 慢放系数（每模拟秒 → 虚拟秒），由动画时长反推
  var WAVE_CAL = 5.0;                    // 并合时的引力波波长 ≈ 5 网格单位（用于换算真实时间）

  /* ==========================================================================
   * 质量的两个角色（关键设计决定）
   * --------------------------------------------------------------------------
   * 画面上的井深 ∝ 质量，而轨道动力学里的唯一无量纲小参量是 M/r；两者共用
   * 一个"质量"会让 M/r ~ 0.3 掉进 1PN 截断的失效区：径向力在近星点变成净内向，
   * 轨道直接坠入视界（这个坑实测踩过，见 tests/physics.test.js 的强场回归）。
   *
   * 所以这里分开：
   *   M_WELL = 画面上引力井的深度（纯视觉，滑块控制）
   *   M_orb  = 真正参与轨道/并合动力学的质量，固定取得足够小，使
   *            M_orb/r ≪ 1（弱场），1PN 进动才是"缓慢进动的椭圆"。
   * 相对论效应的强弱改由滑块 K（1PN 耦合）显式控制，这样既能保持轨道稳定，
   * 又能看到明显的进动与引力波。
   * ========================================================================== */
  var M_orb = 0.025;
  /** 轨道质量：小到让 M/r ≪ 1，同时保证 6M²/h² 不过度偏离标准进动公式 */
  function massOrbit() { return M_orb; }

  /* ================================================================ 工具 */
  function $(id) { return document.getElementById(id); }
  function fmt(x, n) { return (Math.abs(x) < 1e-12 ? 0 : x).toFixed(n == null ? 2 : n); }

  /* ============================================================ 初始化流程 */
  function init() {
    dom.canvas = $('gl');
    dom.embed = $('embed');
    S = global.STScene.create({ canvas: dom.canvas, config: CFG });

    buildUI();
    onResize();
    window.addEventListener('resize', onResize);

    ST.rS = CFG.massSlider;                 // 几何单位下 r_s = M
    ST.massKg = massKgFromRsModel(ST.rS);

    setMode('single');
    S.updateBody(ST.rS, true);
    syncUniforms(0);
    readouts(true);

    dom.loading.classList.add('hide');
    requestAnimationFrame(frame);
    setInterval(function () { drawEmbed(); }, 90);
  }

  /* 长度/时间/速度的唯一映射（三者必须自洽，否则会出现 v/c > 1 的读数）：
     令 1 世界单位的长度 = M_vis·M☉ 的史瓦西半径，即 r_s(物理) = M_vis 世界单位：
       1 world unit = r_s_phys / M_vis                    [m]
       T_GU         = 2GM_phys/c³ = 4.461e-6 · M_vis      [s]
       1 gu/sim      = (1 world unit) / T_GU               [m/s] → 再除以 c 得 v/c
     默认 M_vis = 0.85 ⇒ 黑洞 ≈ 0.85 M☉、r_s ≈ 2.5 km、可见网格 ≈ 85 km。 */
  var T_GU_COEF = 4.461e-6;              // s per (world time unit) per M☉

  function rsMetersFor(mVis) { return Ph.rsFromMass(Math.max(mVis, 1e-3) * Ph.M_SUN); }
  function unitMeters(mVis) { return rsMetersFor(mVis) / Math.max(mVis, 1e-3); }
  function timeScaleFor(mVis) { return T_GU_COEF * Math.max(mVis, 1e-3); }
  function velocityScaleFor(mVis) {
    return unitMeters(mVis) / (Ph.C_LIGHT * timeScaleFor(mVis));
  }
  function virtToReal(mVis) {
    return WAVE_CAL * timeScaleFor(mVis) / Math.max(mVis, 1e-3);
  }
  function massKgFromRsModel(mVis) { return Math.max(mVis, 1e-3) * Ph.M_SUN; }
  /** 当前每模拟秒推进的虚拟秒数 */
  function virtPerSim() {
    if (ST.mode === 'binary') return K_SLOW / Math.max(CFG.timeScale, 1e-6);
    return 4.0 * CFG.timeScale;                  // 单星/实验模式：固定观感节奏
  }
  /** 慢放倍数（真实时间 / 画面时间），用于在 HUD 里诚实标注 */
  function slowFactor() {
    return virtToReal(CFG.massSlider) / Math.max(virtPerSim(), 1e-9);
  }

  /* ------------------------------------------------------------ 数字格式化 */
  var SUPS = { '-': '⁻', '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹' };
  function sup(n) { return String(n).split('').map(function (c) { return SUPS[c] || c; }).join(''); }

  /** 科学计数法：把指数转成上标，前端显示更干净 */
  function sci(x, digits) {
    if (!isFinite(x)) return '∞';
    if (x === 0) return '0';
    var e = Math.floor(Math.log10(Math.abs(x)));
    if (e >= -2 && e <= 3) return x.toFixed(Math.max(0, digits - 1 - e));
    var m = x / Math.pow(10, e);
    return m.toFixed(digits == null ? 2 : digits) + '×10' + sup(e);
  }
  /** 按量级自动选单位 */
  function autoUnit(x, units) {
    for (var i = 0; i < units.length; i++) {
      if (Math.abs(x) >= units[i][1] || i === units.length - 1) {
        return sci(x / units[i][1], 3) + ' ' + units[i][0];
      }
    }
  }
  var TIME_UNITS = [['s', 1], ['ms', 1e-3], ['µs', 1e-6], ['ns', 1e-9], ['ps', 1e-12]];
  var LEN_UNITS = [['km', 1e3], ['m', 1], ['mm', 1e-3], ['µm', 1e-6]];
  var MASS_UNITS = [['M☉', Ph.M_SUN], ['M_J', 1.898e27], ['M_E', 5.97224], ['kg', 1]];

  /* ================================================================ 面板 */
  function buildUI() {
    dom.loading = $('loading');
    dom.panel = $('panel');
    dom.hud = $('hud');
    dom.modeName = $('modeName');
    dom.hint = $('hint');
    dom.embed = $('embed');
    dom.embedWrap = $('embedWrap');
    dom.fps = $('fps');

    // 折叠
    $('panelToggle').addEventListener('click', function () {
      dom.panel.classList.toggle('collapsed');
      this.textContent = dom.panel.classList.contains('collapsed') ? '‹' : '›';
    });

    // 模式切换
    Array.prototype.forEach.call(document.querySelectorAll('[data-mode]'), function (b) {
      b.addEventListener('click', function () { setMode(b.dataset.mode); });
    });

    // 滑块绑定
    bindRange('mass', CFG.massSlider, function (v) {
      CFG.massSlider = v;
      ST.rS = v;
      ST.massKg = massKgFromRsModel(v);
      if (ST.mode === 'single') resetOrbit();
      else if (ST.mode === 'binary') setupBinary();
      readouts(true);
    });
    bindRange('depth', CFG.depth, function (v) { CFG.depth = v; syncUniforms(0); });
    bindRange('ripple', CFG.ripple, function (v) { CFG.ripple = v; syncUniforms(0); });
    bindRange('prec', CFG.precession, function (v) {
      CFG.precession = v;
      if (ST.orbit) ST.orbit.K = v;
    });
    bindRange('speed', CFG.timeScale, function (v) {
      CFG.timeScale = v;
      if (ST.mode === 'binary') setupBinary();     // 重算慢放系数
    });
    bindRange('ecc', CFG.ellipse, function (v) {
      CFG.ellipse = v;
      if (ST.mode === 'single') resetOrbit();
    });    bindRange('grid', CFG.gridScale, function (v) { CFG.gridScale = v; syncUniforms(0); });
    // 双星初始间距：决定啁啾从多低的频率开始（也就是持续多久）
    bindRange('sep', CFG.binStart, function (v) {
      CFG.binStart = v;
      if (ST.mode === 'binary') { setupBinary(); ST.simTime = 0; ST.warpedTime = 0; clearTrails(); }
    });

    // 开关
    bindCheck('autoRotate', CFG.autoRotate, function (v) { CFG.autoRotate = v; S.controls.autoRotate = v; });
    bindCheck('trail', CFG.showTrail, function (v) {
      CFG.showTrail = v;
      S.trailA.line.visible = v; S.trailB.line.visible = v;
    });
    bindCheck('disk', CFG.showDisk, function (v) { CFG.showDisk = v; S.disk.visible = v && ST.rS > 0; });

    // 画质
    Array.prototype.forEach.call(document.querySelectorAll('[data-q]'), function (b) {
      b.addEventListener('click', function () {
        Array.prototype.forEach.call(document.querySelectorAll('[data-q]'), function (x) { x.classList.remove('on'); });
        b.classList.add('on');
        S.buildGrid(parseInt(b.dataset.q, 10));
        dom.fps.textContent = '—';
      });
    });

    // 按钮
    $('btnRestart').addEventListener('click', function () { restart(); });
    $('btnView').addEventListener('click', function () { fitView(); });
    $('btnFull').addEventListener('click', function () {
      if (!document.fullscreenElement) document.documentElement.requestFullscreen();
      else document.exitFullscreen();
    });
    $('btnEmbed').addEventListener('click', function () {
      dom.embedWrap.classList.toggle('hide');
    });

    // 键盘
    window.addEventListener('keydown', function (e) {
      if (e.code === 'Space') { e.preventDefault(); ST.paused = !ST.paused; $('btnPause').textContent = ST.paused ? '继续' : '暂停'; }
      else if (e.key === '1') setMode('single');
      else if (e.key === '2') setMode('binary');
      else if (e.key === '3') setMode('interact');
      else if (e.key === 'r' || e.key === 'R') restart();
      else if (e.key === 'h' || e.key === 'H') dom.panel.classList.toggle('collapsed');
    });
    $('btnPause').addEventListener('click', function () {
      ST.paused = !ST.paused; this.textContent = ST.paused ? '继续' : '暂停';
    });
  }

  function bindRange(id, val, cb) {
    var el = $(id), out = $(id + 'Val');
    if (!el) return;
    el.value = val;
    dom[id + 'Out'] = out;
    var show = function (v) {
      if (out) out.textContent = (el.dataset.fmt === 'int') ? String(Math.round(v)) : Number(v).toFixed(2);
    };
    show(val);
    el.addEventListener('input', function () { var v = parseFloat(el.value); show(v); cb(v); });
  }
  function bindCheck(id, val, cb) {
    var el = $(id);
    if (!el) return;
    el.checked = val;
    el.addEventListener('change', function () { cb(el.checked); });
  }

  /* ================================================================ 模式 */
  function setMode(m) {
    ST.mode = m;
    Array.prototype.forEach.call(document.querySelectorAll('[data-mode]'), function (b) {
      b.classList.toggle('on', b.dataset.mode === m);
    });
    dom.modeName.textContent = m === 'single' ? '单星测地线' : (m === 'binary' ? '双黑洞并合 · 引力波' : '时空曲率实验');
    dom.hint.innerHTML = m === 'interact'
      ? '<b>点击时空网</b>投掷试验粒子 —— 看它是被弯曲时空束缚、绕行，还是逃逸/坠入视界'
      : (m === 'binary'
        ? '两个黑洞按四极辐射公式螺旋靠近，向外辐射<b>啁啾引力波</b>（可拖动滑块调节并合时长）'
        : '行星沿弯曲时空的测地线运行，轨迹每圈旋转一点 —— 这就是<b>近日点进动</b>');

    if (m === 'single') {
      resetOrbit();
      showCompanions(false);
      S.updateBody(ST.rS, true);
    } else if (m === 'binary') {
      setupBinary();
      showCompanions(true);
      clearTrails();
    } else {
      showCompanions(false);
      S.updateBody(ST.rS, true);
      ST.parts.length = 0;
      clearTrails();
    }
  }

  function showCompanions(on) {
    S.companions.forEach(function (c) { c.visible = on; });
    S.body.visible = true;
  }

  function restart() {
    ST.simTime = 0; ST.warpedTime = 0;
    if (ST.mode === 'single') { resetOrbit(); clearTrails(); }
    else if (ST.mode === 'binary') { setupBinary(); clearTrails(); }
    else { ST.parts.length = 0; clearTrails(); }
  }

  function resetOrbit() {
    // 轨道尺度固定取在 ISCO 之外（与井深解耦），保证 1PN 近似有效
    var r0 = 3.05;
    // 偏心率先夹紧：近日点必须留在 r_s 之外，否则轨道会直接穿进视界
    var eMax = Math.min(0.72, Math.max(0, 1 - 1.55 / r0));
    var ecc = Math.min(CFG.ellipse, eMax);
    if (ecc < CFG.ellipse - 1e-6 && dom.eccValOut) dom.eccValOut.textContent = fmt(ecc, 2) + '*';
    var o = new Ph.Orbit({ m: massOrbit(), K: CFG.precession, a: r0, e: ecc, substeps: 12 });
    o.reset();
    ST.orbit = o;
    ST.orbPeriod = o.elements().period;                 // 虚拟秒
    K_SLOW = Math.max(ST.orbPeriod / (CFG.orbitSeconds * Math.max(CFG.timeScale, 1e-6)), 0.05);
  }

  function clearTrails() {
    [S.trailA, S.trailB].forEach(function (t) {
      t.n = 0; t.head = 0;
      t.geo.setDrawRange(0, 0);
      t.geo.attributes.position.needsUpdate = true;
      t.geo.attributes.color.needsUpdate = true;
    });
  }

  function fitView() {
    S.camera.position.set(0, 13.5, 19.5);
    S.controls.target.set(0, -0.8, 0);
    S.controls.update();
  }

  /* ======================================================== 时间与物理推进 */
  function frame(now) {
    requestAnimationFrame(frame);
    var dtReal = Math.min((now - (frame.prev || now)) / 1000, 0.05);
    frame.prev = now;
    ST.realTime += dtReal;
    var dt = ST.paused ? 0 : dtReal * CFG.timeScale;

    if (dt > 0) {
      ST.simTime += dt;
      ST.warpedTime += dt * virtPerSim();
      if (ST.mode === 'single') stepSingle(dt);
      else if (ST.mode === 'binary') stepBinary(dt);
      else stepInteract(dt);
    }

    syncUniforms(ST.warpedTime);
    updateVisuals();
    S.controls.update();
    S.renderer.render(S.scene, S.camera);

    // FPS 与自动降级
    frame.acc = (frame.acc || 0) + dtReal;
    frame.cnt = (frame.cnt || 0) + 1;
    if (frame.acc > 0.5) {
      ST.fps = frame.cnt / frame.acc;
      dom.fps.textContent = ST.fps.toFixed(0);
      frame.acc = 0; frame.cnt = 0;
      if (ST.fps < 22 && CFG.segments > 140) {
        CFG.segments = 140; S.buildGrid(140);
        Array.prototype.forEach.call(document.querySelectorAll('[data-q]'), function (x) {
          x.classList.toggle('on', x.dataset.q === '140');
        });
      }
    }

    if (now - ST.lastOrbitHud > 120) { ST.lastOrbitHud = now; readouts(false); }
  }

  /* ---------------------------------------------------------- ① 单星测地线 */
  function stepSingle(dt) {
    var o = ST.orbit;
    if (!o) return;
    o.K = CFG.precession;
    o.m = massOrbit();
    o.step(dt);
    if (o.r <= ST.rS * 1.05 || o.r > 60) resetOrbit();   // 落入视界 → 重新注入
  }

  /* -------------------------------------------------------- ② 双黑洞并合 */
  /* 终态分离度取在 ISCO 附近（真实并合就发生在这个尺度），初态由滑块给出。
     四极辐射时标 T_m = τ_s·(d₀³-d_end³)/(64M³/5) 直接决定啁啾在虚拟时间里
     持续多久、以及起始频率多低 —— 这两件事是同一件事的两面，不能各自设。 */
  function setupBinary() {
    var Mv = CFG.massSlider;                            // 视觉/物理质量（决定史瓦西半径）
    var Mo = massOrbit();                               // 轨道动力学质量（弱场，保证 1PN 有效）
    var B = ST.bin;
    // 分离度用"两体史瓦西半径"为单位 → 与画面上看到的黑洞大小一致
    B.dEnd = Math.max(2.0 * Mv, 0.7);                   // 并合时（≈ 1 r_s,tot）
    B.d0 = Math.min(Math.max(CFG.binStart * Mv, B.dEnd * 2.2), 24);
    B.d = B.d0;
    B.tau = 1;
    B.Tm = Math.max(Ph.mergerTime(B.d0, Mo) * (1 - Math.pow(B.dEnd / B.d0, 4)), 0.05);
    /* 啁啾相位（与着色器同一式子）：d = d₀τ^{1/4} 且 dΦ/dt = 2Ω(d) ⇒ Φ ∝ τ^{5/8}
         Φ(t) = k·(τ^{5/8} - τ_end^{5/8}),  k = 8π·Ω(d₀)·T_m,  τ = 1 - t/T_m
       频率 = (5k/8T_m)·τ^{-3/8} ∝ τ^{-3/8} → 随时间升高（chirp），
       并合时 (τ=τ_end) 相位冻结在有限值，不会发散。 */
    B.kPhase = 8 * Math.PI * Ph.binaryOmega(2 * Mo, B.d0) * B.Tm;
    B.tauEnd = Math.pow(B.dEnd / B.d0, 4);
    B.cycles = B.kPhase * (Math.pow(1, 0.625) - Math.pow(B.tauEnd, 0.625)) / (2 * Math.PI);
    B.phase = 0; B.merged = false; B.tMerge = 0;
    // 让整段啁啾在画面上只占 animSeconds 秒（timeScale 大 → 动画更快）
    K_SLOW = Math.max(B.Tm / (CFG.animSeconds * Math.max(CFG.timeScale, 1e-6)), 0.02);
  }

  function stepBinary(dt) {
    var B = ST.bin;
    if (B.merged) return;
    B.tau = 1 - ST.warpedTime / B.Tm;
    if (B.tau <= 0) { B.tau = 0; B.merged = true; B.tMerge = ST.warpedTime; B.d = B.dEnd; return; }
    B.d = Ph.separationAt(B.tau, B.d0);
    // 轨道相位按虚拟时间推进（Ω 的单位是 1/虚拟秒），与波形的时间基准保持一致
    B.phase += Ph.binaryOmega(2 * massOrbit(), Math.max(B.d, 0.2)) * dt * virtPerSim();
  }

  /* -------------------------------------------------------- ③ 曲率实验 */
  function stepInteract(dt) {
    var M = massOrbit();
    for (var i = ST.parts.length - 1; i >= 0; i--) {
      var p = ST.parts[i];
      p.o.m = M; p.o.K = CFG.precession;
      p.o.step(dt);
      p.age += dt;
      var r = p.o.r;
      if (r <= ST.rS * 1.03 || r > 26 || p.age > 90) { ST.parts.splice(i, 1); continue; }
      // 轨迹采样
      p.acc += dt;
      if (p.acc > 0.012) {
        p.acc = 0;
        p.hist.push(p.o.x, p.o.z);
        if (p.hist.length > 2400) p.hist.splice(0, 2);
      }
    }
    if (ST.parts.length > 10) ST.parts.splice(0, ST.parts.length - 10);
  }

  /* ================================================================ uniform */
  function syncUniforms(tw) {
    var u = S.uniforms;
    u.uTime.value = tw;
    u.uDepth.value = CFG.depth;
    u.uNoise.value = CFG.noise;
    u.uRipple.value = CFG.ripple;
    u.uGrid.value = CFG.gridScale;
    u.uRS.value = ST.rS;

    var mp = u.uMassPos.value, mm = u.uMassM.value;
    if (ST.mode === 'binary') {
      var B = ST.bin;
      var half = B.d * 0.5;
      var cx = Math.cos(B.phase) * half, cz = Math.sin(B.phase) * half;
      var mEach = CFG.massSlider;
      u.uMergeT.value = Math.max(B.Tm, 0.02);
      // 啁啾强度 k = 8π·Ω(d₀)·T_m；着色器只用它的相位差
      u.uChirpPhase.value = Math.max(B.kPhase, 1e-6);
      u.uChirpAmp.value = 0.42 * Math.min(Math.max(CFG.ripple, 0), 3) / 1.6;
      if (B.merged) {
        mp[0] = 0; mp[1] = 0; mm[0] = Ph.remnantMass(2 * mEach);
        u.uMassCount.value = 1;
        u.uBinary.value = 0;                 // 并合后只剩衰减的脉冲环
      } else {
        mp[0] = cx; mp[1] = cz; mm[0] = mEach;
        mp[2] = -cx; mp[3] = -cz; mm[2] = mEach;
        u.uMassCount.value = 2;
        u.uBinary.value = 1;
      }
      u.uSrc.value.set(0, 0);
      u.uBurst.value = 0.22 * Math.min(Math.max(CFG.ripple, 0), 3) / 1.6;
    } else {
      mp[0] = 0; mp[1] = 0; mm[0] = CFG.massSlider;
      u.uMassCount.value = 1;
      u.uBinary.value = 0;
      u.uBurst.value = 0.0;
      u.uChirpAmp.value = 0.0;
    }
  }

  /* ============================================================== 视觉更新 */
  function updateVisuals() {
    S.stars.position.copy(S.camera.position);

    if (ST.mode === 'single') {
      var o = ST.orbit;
      S.body.visible = true;
      S.updateBody(ST.rS, true);                 // 恒为黑洞：核心球隐藏、盘显示
      S.core.visible = false;
      S.disk.visible = CFG.showDisk;
      S.particles.visible = false;
      placeMarker(o.x, o.z, Math.max(ST.rS * 0.14, 0.07), 0x9fe0ff);
      pushTrail(S.trailA, o.x, o.z, CFG.showTrail, [0.58, 0.86, 1.0]);
    } else if (ST.mode === 'binary') {
      var B = ST.bin;
      var half = B.d * 0.5;
      var cx = Math.cos(B.phase) * half, cz = Math.sin(B.phase) * half;
      S.body.visible = true;
      S.marker.visible = false;
      if (B.merged) {
        S.updateBody(Ph.remnantMass(2 * CFG.massSlider), true);
        S.core.visible = false;
        S.disk.visible = CFG.showDisk;
        S.companions.forEach(function (c) { c.visible = false; });
      } else {
        S.horizon.visible = false; S.core.visible = false; S.disk.visible = false;
        S.companions[0].visible = true; S.companions[1].visible = true;
        S.companions[0].position.set(cx, 0, cz);
        S.companions[1].position.set(-cx, 0, -cz);
        var rr = Math.max(CFG.massSlider * 0.9, 0.12);   // 与中心天体的视觉半径一致
        S.companions[0].scale.setScalar(rr);
        S.companions[1].scale.setScalar(rr);
      }
      S.particles.visible = false;
      pushTrail(S.trailA, cx, cz, CFG.showTrail && !B.merged, [0.66, 0.84, 1.0]);
      pushTrail(S.trailB, -cx, -cz, CFG.showTrail && !B.merged, [1.0, 0.74, 0.44]);
    } else {
      S.body.visible = true;
      S.updateBody(ST.rS, true);
      S.core.visible = false;
      S.disk.visible = CFG.showDisk;
      S.marker.visible = false;
      drawInteractionParticles();
    }
  }

  /* 行星标记（发光小球） */
  function placeMarker(x, z, r, color) {
    if (!S.marker) {
      var m = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 16),
        new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.95 }));
      var glow = new THREE.Mesh(new THREE.SphereGeometry(2.6, 20, 16),
        new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.14,
                                      blending: THREE.AdditiveBlending, depthWrite: false, depthTest: false }));
      m.add(glow);
      m.renderOrder = 9;
      S.scene.add(m);
      S.marker = m;
    }
    S.marker.visible = true;
    S.marker.position.set(x, sampleY(x, z) + r * 0.6, z);
    S.marker.scale.setScalar(r);
  }

  function sampleY(x, z) { return S.sampleAt(x, z).y; }

  /* 轨迹：环形缓冲 + 头部重采样（每 ~30 ms 采一点） */
  function pushTrail(t, x, z, on, rgb) {
    if (!on) return;
    t.acc = (t.acc || 0) + 1;
    if (t.acc < 2) return;
    t.acc = 0;
    var i = t.head;
    var y = sampleY(x, z) + 0.015;
    t.pos[i * 3] = x; t.pos[i * 3 + 1] = y; t.pos[i * 3 + 2] = z;
    t.head = (i + 1) % t.cap;
    if (t.n < t.cap) t.n++;
    var L = t.n;
    for (var k = 0; k < L; k++) {
      var idx = (t.head - 1 - k + t.cap * 2) % t.cap;
      var f = 0.06 + 0.94 * Math.pow(1 - k / L, 1.6);
      t.col[idx * 3] = rgb[0] * f;
      t.col[idx * 3 + 1] = rgb[1] * f;
      t.col[idx * 3 + 2] = rgb[2] * f;
    }
    t.geo.setDrawRange(t.head >= L ? 0 : t.head, L);
    t.geo.attributes.position.needsUpdate = true;
    t.geo.attributes.color.needsUpdate = true;
  }

  /* 交互模式的粒子：点 + 历史轨迹 */
  function drawInteractionParticles() {
    var buf = S.pBuf;
    var n = 0;
    for (var i = 0; i < ST.parts.length && n < buf.max; i++) {
      var p = ST.parts[i];
      var y = sampleY(p.o.x, p.o.z);
      buf.pos[n * 3] = p.o.x; buf.pos[n * 3 + 1] = y + 0.06; buf.pos[n * 3 + 2] = p.o.z;
      buf.col[n * 3] = p.color[0]; buf.col[n * 3 + 1] = p.color[1]; buf.col[n * 3 + 2] = p.color[2];
      buf.sz[n] = 1.6;
      n++;
    }
    // 拖尾用粒子画（点很便宜）
    for (var j = 0; j < ST.parts.length; j++) {
      var q = ST.parts[j];
      var step = Math.max(2, Math.floor(q.hist.length / 2 / Math.max(1, Math.floor(500 / Math.max(ST.parts.length, 1)))));
      for (var h = 0; h < q.hist.length - 1 && n < buf.max; h += step) {
        var hx = q.hist[h], hz = q.hist[h + 1];
        buf.pos[n * 3] = hx; buf.pos[n * 3 + 1] = sampleY(hx, hz) + 0.04; buf.pos[n * 3 + 2] = hz;
        var fade = h / q.hist.length;
        buf.col[n * 3] = q.color[0] * fade; buf.col[n * 3 + 1] = q.color[1] * fade; buf.col[n * 3 + 2] = q.color[2] * fade;
        buf.sz[n] = 0.8;
        n++;
      }
    }
    buf.n = n;
    S.particles.visible = n > 0;
    var g = S.particles.geometry;
    g.attributes.position.needsUpdate = true;
    g.attributes.color.needsUpdate = true;
    g.attributes.aSize.needsUpdate = true;
    g.setDrawRange(0, n);
  }

  /* ============================================================== 读数 HUD */
  function readouts(full) {
    var Mo = massOrbit();                  // 轨道动力学质量（周期/速度/进动/波频都用它）
    var Mv = CFG.massSlider;               // 视觉与物理质量（决定真实尺度）
    var T_GU = timeScaleFor(Mv);           // 1 世界时间单位 = T_GU 秒
    var vScale = velocityScaleFor(Mv);     // 网格速度 → v/c

    $('rRS').textContent = autoUnit(rsMetersFor(Mv), LEN_UNITS);
    // 主单位 + 太阳质量等价（恒星量级黑洞用 M☉ 更好读）
    $('rMass').textContent = autoUnit(ST.massKg, MASS_UNITS) +
      (ST.massKg < Ph.M_SUN && ST.massKg > 0.01 * Ph.M_SUN
        ? ' (' + fmt(ST.massKg / Ph.M_SUN, 2) + ' M☉)' : '');
    if (ST.mode === 'single' && ST.orbit) {
      var o = ST.orbit, el = o.elements();
      $('rDil').textContent = fmt(Ph.timeDilation(Mo, Math.max(o.r, 1e-6)), 5) + ' ×';
      $('rPrec').textContent = fmt(Ph.perihelionPrecession(Mo, Math.max(el.a, 1e-6), Math.min(el.e, 0.95)) * DEG, 2) + ' °/圈';
      var vOverC = el.v * vScale;
      $('rVel').textContent = fmt(vOverC, 3) + ' c';
      $('rVelTag').className = 'tag ' + (vOverC > 0.5 ? 'warn' : vOverC > 0.15 ? 'mid' : 'ok');
      $('rOrbit').textContent = fmt(el.a / (2 * Mo), 2) + ' rₛ (e=' + fmt(el.e, 2) + ')';
      $('rPeriod').textContent = autoUnit(el.period * T_GU, TIME_UNITS);
      $('rSweep').textContent = fmt(o.precession * DEG, 1) + '° / ' + o.periCount + ' 圈';
    } else if (ST.mode === 'binary') {
      var B = ST.bin;
      var d = Math.max(B.d, 1e-6);
      $('rDil').textContent = B.merged ? '已并合' : fmt(Ph.timeDilation(2 * Mo, d), 5) + ' ×';
      $('rPrec').textContent = B.merged ? '铃宕衰减中'
        : autoUnit(Ph.gwFrequency(2 * Mo, d) / T_GU, [['kHz', 1e3], ['Hz', 1], ['mHz', 1e-3]]);
      var beta = Ph.orbitalBeta(2 * Mo, d);
      $('rVel').textContent = fmt(beta, 3) + ' c';
      $('rVelTag').className = 'tag ' + (beta > 0.4 ? 'warn' : beta > 0.2 ? 'mid' : 'ok');
      $('rOrbit').textContent = fmt(d / (4 * Mo), 2) + ' rₛ (间距)';
      $('rPeriod').textContent = fmt((1 - B.tau) * 100, 1) + ' %  → 并合';
      $('rSweep').textContent = B.merged
        ? '余核 ' + fmt(Ph.remnantMass(2 * Mo) / Mo, 2) + ' × m'
        : fmt((B.phase * DEG) % 360, 0) + '° 相位';
    } else {
      $('rDil').textContent = fmt(Ph.timeDilation(Mo, 2 * Mo), 5) + ' ×';
      $('rPrec').textContent = ST.parts.length + ' 个粒子';
      $('rVel').textContent = '—';
      $('rVelTag').className = 'tag ok';
      $('rOrbit').textContent = fmt(Mv / (2 * Mo), 1) + ' × rₛ (井深/轨道尺度)';
      $('rPeriod').textContent = autoUnit(Ph.freeFallTime(Mo, 3) * T_GU, TIME_UNITS) + ' 自由落体';
      var bound = ST.parts.filter(function (p) { return p.bound; }).length;
      $('rSweep').textContent = bound + ' 束缚 / ' + ST.parts.length + ' 总数';
    }

    // 曲率强度 = 井深 × 视觉质量
    var curve = CFG.depth * CFG.massSlider;
    $('rCurv').textContent = fmt(curve, 2) + ' ×';
    $('bar').style.width = Math.min(curve / 3 * 100, 100) + '%';
    if (dom.fps) dom.fps.textContent = ST.fps ? ST.fps.toFixed(0) : '—';

    // 诚实标注：画面相对真实物理时间慢了多少（本演示就是慢动作回放）
    var sf = slowFactor();
    $('rSlow').textContent = '× ' + (sf >= 1000 ? sci(sf, 3) : fmt(sf, 1)) + ' 慢放';
  }

  /* ========================================================= 2D 嵌入图 */
  var embedCv = null, embedCtx = null;
  function drawEmbed() {
    if (!dom.embed || dom.embedWrap.classList.contains('hide')) return;
    var cv = dom.embed;
    if (!embedCv) {
      embedCv = document.createElement('canvas');
      embedCv.width = 128; embedCv.height = 128;
      embedCtx = embedCv.getContext('2d');
    }
    var W = cv.width, H = cv.height;
    var ctx = cv.getContext('2d');
    var N = 128, HALF = 11, R = 3.4;
    var img = embedCtx.createImageData(N, N);
    var u = S.uniforms;
    var masses = [];
    for (var i = 0; i < u.uMassCount.value; i++) {
      masses.push({ x: u.uMassPos.value[i * 2], z: u.uMassPos.value[i * 2 + 1], m: u.uMassM.value[i] });
    }
    var fade = u.uRipple.value * (ST.mode === 'binary' && u.uBinary.value > 0.5 ? 1 : 0) * 0.35;
    for (var j = 0; j < N; j++) {
      var z = -HALF + (j / (N - 1)) * 2 * HALF;
      for (var k = 0; k < N; k++) {
        var x = -HALF + (k / (N - 1)) * 2 * HALF;
        var rr = Math.sqrt(x * x + z * z);
        var s = Ph.surfaceAt(x, z, masses);
        var dep = Math.min(-s.y / 2.6, 1.2);
        var t = Ph.heightAt(x, z, masses) * CFG.depth * -1;   // 深度（正）
        t = Math.max(0, t);
        // 颜色：深 → 亮
        var lum = Math.min(Math.pow(t / 0.5, 1.2), 1.0);
        var co = makeColor(lum);
        // 网格线
        var gx = (k / (N - 1)) * 2 * HALF;
        var gz = (j / (N - 1)) * 2 * HALF;
        var onLine = (Math.abs((gx * 2) % 1) < 0.14) || (Math.abs((gz * 2) % 1) < 0.14);
        var idx = (j * N + k) * 4;
        var bright = onLine ? 1.0 : 0.35;
        // 视界内挖黑
        var inHole = rr < ST.rS;
        img.data[idx] = inHole ? 4 : co[0] * bright * 255;
        img.data[idx + 1] = inHole ? 6 : co[1] * bright * 255;
        img.data[idx + 2] = inHole ? 13 : co[2] * bright * 255;
        img.data[idx + 3] = 255;
      }
    }
    embedCtx.putImageData(img, 0, 0);
    ctx.clearRect(0, 0, W, H);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(embedCv, 0, 0, W, H);
    // 轨道投影
    if (ST.mode === 'single' && ST.orbit && ST.trailA.n > 1) {
      ctx.strokeStyle = 'rgba(120,190,255,0.85)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      for (var q = 0; q < ST.trailA.n; q++) {
        var px = (ST.trailA.pos[q * 3] / HALF * 0.5 + 0.5) * W;
        var py = (ST.trailA.pos[q * 3 + 2] / HALF * 0.5 + 0.5) * H;
        if (q === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      ctx.stroke();
    }
  }
  function makeColor(l) {
    var c = [0.10, 0.16, 0.30];
    var warm = [1.0, 0.68, 0.24], cool = [0.35, 0.72, 1.0];
    var t = Math.min(l * 1.6, 1);
    return [c[0] + (cool[0] * (1 - t) + warm[0] * t - c[0]) * l,
            c[1] + (cool[1] * (1 - t) + warm[1] * t - c[1]) * l,
            c[2] + (cool[2] * (1 - t) + warm[2] * t - c[2]) * l];
  }

  /* ================================================================ 交互 */
  function onResize() {
    var w = window.innerWidth, h = window.innerHeight;
    S.resize(w, h);
    var em = dom.embed;
    if (em) {
      em.width = Math.round(em.clientWidth * Math.min(window.devicePixelRatio || 1, 2));
      em.height = Math.round(em.clientHeight * Math.min(window.devicePixelRatio || 1, 2));
    }
    S.starsMat.uniforms.uPix.value = S.renderer.getPixelRatio();
  }

  function initPointer() {
    var down = null;
    dom.canvas.addEventListener('pointerdown', function (e) { down = { x: e.clientX, y: e.clientY, t: performance.now() }; });
    dom.canvas.addEventListener('pointerup', function (e) {
      if (!down) return;
      var moved = Math.hypot(e.clientX - down.x, e.clientY - down.y);
      var quick = performance.now() - down.t < 400;
      down = null;
      if (moved > 6 || !quick) return;
      if (ST.mode !== 'interact') return;
      spawnFromClick(e.clientX, e.clientY);
    });
  }

  function spawnFromClick(cx, cy) {
    var rect = dom.canvas.getBoundingClientRect();
    var ndc = new THREE.Vector2(
      ((cx - rect.left) / rect.width) * 2 - 1,
      -((cy - rect.top) / rect.height) * 2 + 1
    );
    var ray = new THREE.Raycaster();
    ray.setFromCamera(ndc, S.camera);
    var plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    var hit = new THREE.Vector3();
    if (!ray.ray.intersectPlane(plane, hit)) return;
    var x = hit.x, z = hit.z;
    var d = Math.hypot(x, z);
    if (d < ST.rS * 1.5 || d > 13) return;

    // 圆轨道速度 + 随机扰动（扰动越小越圆）；用轨道质量，保证与井深解耦
    var Mo = massOrbit();
    var vk = Math.sqrt(Mo / d) * (0.72 + Math.random() * 0.5);
    var ang = Math.random() * TAU;
    var vx = -Math.sin(Math.atan2(z, x)) * vk + Math.cos(ang) * vk * 0.06;
    var vz = Math.cos(Math.atan2(z, x)) * vk + Math.sin(ang) * vk * 0.06;

    var o = new Ph.Orbit({ m: Mo, K: CFG.precession, substeps: 8 });
    o.setInitial(x, z, vx, vz);

    // 能量判据：E = v²/2 - M/r < 0 → 束缚
    var E = (vx * vx + vz * vz) / 2 - Mo / d;
    var bound = E < 0;
    var col = bound ? [0.45, 0.85, 1.0] : [1.0, 0.42, 0.35];

    ST.parts.push({ o: o, hist: [], acc: 0, age: 0, color: col, bound: bound });
    if (ST.parts.length > 10) ST.parts.shift();
  }

  /* ================================================================ 启动 */
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
  function boot() { init(); initPointer(); }

  global.STApp = { CFG: CFG, ST: ST, restart: restart, setMode: setMode, spawnFromClick: spawnFromClick };
})(window);
