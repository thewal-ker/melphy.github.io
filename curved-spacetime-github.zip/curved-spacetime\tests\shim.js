/* ============================================================================
 * 注入式探针 shim.js
 * 放在所有脚本之前加载，用于在无头浏览器里回答"到底画出来没有"：
 *   - 捕获 window.onerror / unhandledrejection
 *   - 包装 THREE.WebGLRenderer 构造函数，记录着色器编译错误、绘制调用、画布尺寸
 *   - 包装 requestAnimationFrame，统计真实渲染帧数
 *   - 把 STApp 的状态快照挂到 window.__PROBE__
 * ========================================================================== */
(function () {
  'use strict';
  var errors = [];
  window.__ERRORS__ = errors;

  window.addEventListener('error', function (e) {
    errors.push('error: ' + (e.message || '') + ' @' + (e.filename || '') + ':' + (e.lineno || 0));
  });
  window.addEventListener('unhandledrejection', function (e) {
    errors.push('rejection: ' + (e.reason && e.reason.message ? e.reason.message : String(e.reason)));
  });

  var probe = {
    booted: false, shaderErrors: [], drawCalls: 0, rafCount: 0,
    rendererCanvas: null, glInfo: null, ticks: [], domChecks: {}
  };
  window.__PROBE__ = probe;

  /* ---- 包装 rAF 计数 ---- */
  var raf = window.requestAnimationFrame.bind(window);
  window.requestAnimationFrame = function (cb) {
    return raf(function (t) {
      probe.rafCount++;
      // 每秒记一次读数，用于判断"时间是否真的在走"
      var sec = Math.floor(t / 1000);
      if (probe.ticks.length === 0 || probe.ticks[probe.ticks.length - 1].t !== sec) {
        probe.ticks.push({ t: sec, snapshot: snap() });
      }
      return cb(t);
    });
  };

  /* ---- 包装渲染器 ---- */
  var patched = false;
  function patchThree() {
    if (patched || !window.THREE || !window.THREE.WebGLRenderer) return;
    patched = true;
    var Orig = window.THREE.WebGLRenderer;
    function Patched(params) {
      var r = new Orig(params);
      probe.rendererCreated = true;
      window.__RENDERER__ = r;
      try {
        probe.glInfo = {
          version: r.capabilities && r.capabilities.isWebGL2 ? 'WebGL2' : 'WebGL1',
          maxVertexUniforms: r.capabilities && r.capabilities.maxVertexUniforms,
          maxTextureSize: r.capabilities && r.capabilities.maxTextureSize,
          pixelRatio: r.getPixelRatio(),
          size: [r.domElement.width, r.domElement.height]
        };
        probe.rendererCanvas = r.domElement.id || '(canvas)';
      } catch (e) { errors.push('renderer probe: ' + e.message); }
      var origRender = r.render.bind(r);
      r.render = function (scene, cam) {
        probe.drawCalls++;
        try {
          origRender(scene, cam);
          if (!probe.afterFirstDraw) {
            probe.afterFirstDraw = {
              glError: r.getContext().getError(),
              programs: r.info && r.info.programs ? r.info.programs.length : -1,
              calls: r.info ? r.info.render.calls : -1,
              triangles: r.info ? r.info.render.triangles : -1,
              points: r.info ? r.info.render.points : -1
            };
          }
          if (probe.drawCalls === 30 && r.info && r.info.programs) {
            probe.programs = r.info.programs.map(function (p) {
              var diag = null;
              try {
                var gl = r.getContext();
                if (!p.program.diagnostics) {
                  gl.validateProgram(p.program);
                  var st = gl.getProgramParameter(p.program, gl.LINK_STATUS);
                  if (!st) diag = gl.getProgramInfoLog(p.program);
                }
              } catch (e) { diag = 'diag-fail ' + e.message; }
              return { name: p.name, diag: diag };
            });
          }
        } catch (e) {
          errors.push('render throw: ' + e.message);
        }
      };
      return r;
    }
    Patched.prototype = Orig.prototype;
    window.THREE.WebGLRenderer = Patched;
  }
  var iv = setInterval(function () { patchThree(); if (patched) clearInterval(iv); }, 5);
  patchThree();

  /* ---- 状态快照 ---- */
  function snap() {
    var A = window.STApp;
    if (!A) return null;
    var ST = A.ST, CFG = A.CFG;
    var s = {
      mode: ST.mode, simTime: +ST.simTime.toFixed(3), warped: +ST.warpedTime.toFixed(3),
      U: +ST.U.toFixed(6), fps: +(ST.fps || 0).toFixed(1), rS: ST.rS,
      depth: CFG.depth, ripple: CFG.ripple, mass: CFG.massSlider, seg: CFG.segments
    };
    if (ST.orbit) {
      s.orbit = {
        x: +ST.orbit.x.toFixed(3), z: +ST.orbit.z.toFixed(3), r: +ST.orbit.r.toFixed(3),
        peri: ST.orbit.periCount, precDeg: +(ST.orbit.precession * 180 / Math.PI).toFixed(2)
      };
    }
    s.bin = { d: +ST.bin.d.toFixed(3), tau: +ST.bin.tau.toFixed(3), phase: +ST.bin.phase.toFixed(3), merged: ST.bin.merged };
    s.parts = ST.parts.length;
    return s;
  }

  /* ---- 每 1.2 秒采样帧缓冲，做"像素是否变化"的判断 ----
     注意：不能用 drawImage(canvas)，因为 WebGL 默认 preserveDrawingBuffer=false，
     绘制缓冲在合成后即被清空。改用 gl.readPixels 直接读。 */
  var frames = [];
  window.__FRAMES__ = frames;
  function sampleCanvas() {
    try {
      var R = window.__RENDERER__;
      if (!R) { frames.push({ n: frames.length, err: 'no renderer' }); return; }
      var gl = R.getContext();
      var W = gl.drawingBufferWidth, H = gl.drawingBufferHeight;
      var w = Math.min(W, 220), h = Math.min(H, 124);
      var px = new Uint8Array(w * h * 4);
      gl.readPixels(Math.floor((W - w) / 2), Math.floor((H - h) / 2), w, h,
                    gl.RGBA, gl.UNSIGNED_BYTE, px);
      var sum = 0, lit = 0, mx = 0, colored = 0;
      for (var i = 0; i < px.length; i += 4) {
        var v = (px[i] + px[i + 1] + px[i + 2]) / 3;
        sum += v; if (v > 28) lit++; if (v > mx) mx = v;
        if (Math.max(px[i], px[i + 1], px[i + 2]) - Math.min(px[i], px[i + 1], px[i + 2]) > 24) colored++;
      }
      var n = px.length / 4;
      var rec = { n: frames.length, mean: +(sum / n).toFixed(2), lit: +(lit / n * 100).toFixed(1),
                  colored: +(colored / n * 100).toFixed(1), max: mx };
      frames.push(rec);
      var el = document.createElement('div');
      el.id = 'frameProbe' + frames.length;
      el.style.cssText = 'position:fixed;left:-9999px';
      el.textContent = JSON.stringify(rec);
      document.body.appendChild(el);
    } catch (e) { errors.push('sample: ' + e.message); }
  }
  setInterval(sampleCanvas, 1200);

  /* ---- DOM 读数检查 ---- */
  window.__DOMCHECK__ = function () {
    var ids = ['rCurv', 'rRS', 'rMass', 'rDil', 'rOrbit', 'rVel', 'rPrec', 'rPeriod', 'rSweep', 'fps', 'modeName', 'hint'];
    ids.forEach(function (id) {
      var el = document.getElementById(id);
      probe.domChecks[id] = el ? (el.textContent || '').slice(0, 60) : '(missing)';
    });
    probe.probeSnapshot = snap();
    probe.canvasSize = (function () {
      var c = document.getElementById('gl');
      return c ? [c.width, c.height, c.clientWidth, c.clientHeight] : null;
    })();
    return probe.domChecks;
  };
  window.__SETMODE__ = function (m) { if (window.STApp) window.STApp.setMode(m); };
  window.__CLICKAT__ = function (x, y) { if (window.STApp) window.STApp.spawnFromClick(x, y); };

  window.addEventListener('load', function () { probe.booted = true; });
})();
