/* ============================================================================
 * 物理内核验证 (node tests/physics.test.js)
 * 验证内容：
 *   1. 曲面位移与解析法向是否与数值差分一致（着色器光照正确性）
 *   2. 圆轨道周期是否符合开普勒第三定律
 *   3. 近日点进动是否复现解析公式 Δφ = 6πM/(a(1-e²))
 *   4. 引力波衰减是否符合 Peters(1964) a(t) ∝ τ^{1/4}
 *   5. 时间膨胀 / 史瓦西半径等基本关系
 * ========================================================================== */
'use strict';
const Ph = require('../js/physics.js');

let pass = 0, fail = 0;
function ok(name, cond, info) {
  if (cond) { pass++; console.log('  \u2713 ' + name + (info ? '   ' + info : '')); }
  else { fail++; console.log('  \u2717 ' + name + '   ' + (info || '')); }
}
function close(a, b, tol) { return Math.abs(a - b) <= tol * Math.max(1, Math.abs(b)); }

console.log('\n弯曲时空 — 物理内核验证\n' + '='.repeat(46));

/* ---------------------------------------------------------------- 1 曲面法向 */
console.log('\n[1] 时空曲面：解析法向 vs 数值差分');
{
  const masses = [{ x: 0, z: 0, m: 0.85 }, { x: 1.4, z: -0.7, m: 0.4 }];
  let worst = 0;
  for (const p of [[1.2, 0.4], [-0.8, 1.7], [2.5, -1.1], [0.35, 0.2], [-3, 3]]) {
    const s = Ph.surfaceAt(p[0], p[1], masses);
    const h = 1e-5;
    const dydx = (Ph.heightAt(p[0] + h, p[1], masses) - Ph.heightAt(p[0] - h, p[1], masses)) / (2 * h);
    const dydz = (Ph.heightAt(p[0], p[1] + h, masses) - Ph.heightAt(p[0], p[1] - h, masses)) / (2 * h);
    // 解析法向应满足 n ∝ (-dy/dx, 1, -dy/dz)
    const err = Math.max(Math.abs(s.nx / s.ny + dydx), Math.abs(s.nz / s.ny + dydz));
    worst = Math.max(worst, err);
  }
  ok('解析法向与差分一致 (最大误差 ' + worst.toExponential(2) + ')', worst < 1e-4);
}

/* ---------------------------------------------------------------- 2 开普勒 */
console.log('\n[2] 圆轨道周期 vs 开普勒第三定律');
{
  const M = 0.85;
  for (const r of [2, 4, 8]) {
    const T = Ph.orbitalPeriod(M, r);
    const circ = 2 * Math.PI * r / Math.sqrt(M / r);
    ok('r=' + r + '  T=' + T.toFixed(4), close(T, circ, 1e-9));
  }
  // 数值积分一个圆轨道，跑满一圈后应回到原点
  const o = new Ph.Orbit({ m: M, K: 0, a: 4, e: 0, substeps: 40 });
  const T = Ph.orbitalPeriod(M, 4);
  const steps = 4000;
  for (let i = 0; i < steps; i++) o.step(T / steps);
  const drift = Math.hypot(o.x - 4, o.z - 0);
  ok('数值积分一圈后闭合 (漂移 ' + drift.toExponential(2) + ')', drift < 2e-3);
}

/* ------------------------------------------------------------ 3 近日点进动 */
console.log('\n[3] 1PN 力场与近日点进动');
{
  /* 3a 力律逐点核对：a = -M/r² ·(1 + 3Kh²/r²)  —— 单位/幂次写错时会立刻暴露。
     这一条是"强场轨道被拉进视界"那个 bug 的回归测试。 */
  {
    const M = 0.85, K = 1;
    const h2 = M * 1.87 * (1 - 0.42 * 0.42);
    let worst = 0;
    for (const r of [0.9, 1.08, 1.5, 2.6, 5, 12]) {
      const a = Ph.accel(r, 0, 0, 1, M, K, h2);
      const expect = -M / (r * r) * (1 + 3 * K * h2 / (r * r));
      worst = Math.max(worst, Math.abs(a.ax - expect) / Math.abs(expect));
      // 方向必须指向中心
      if (a.ax > 0) worst = 1;
    }
    ok('加速度满足 a = -M/r²·(1+3Kh²/r²)（含强场 r<2rₛ）',
       worst < 1e-9, '(最大相对误差 ' + worst.toExponential(2) + ')');
  }
  // 3b 默认参数（与 index.html 一致）必须给出稳定的进动椭圆
  {
    const M = 0.025, rSvis = 0.85, e = 0.42, a0 = 3.05;   // M 为轨道质量，与井深解耦
    for (const K of [0, 1, 2, 4]) {
      const o = new Ph.Orbit({ m: M, K: K, a: a0, e: e, substeps: 12 });
      const P = o.elements().period;
      let rmin = 1e9, rmax = 0, plunged = false;
      for (let i = 0; i < 60 * P * 3; i++) {              // 跑 3 圈
        o.step(1 / 60);
        rmin = Math.min(rmin, o.r); rmax = Math.max(rmax, o.r);
        if (o.r <= rSvis * 1.05 || o.r > 40) { plunged = true; break; }
      }
      const pTheo = a0 * (1 - e), aTheo = a0 * (1 + e);
      // K 越大相对论吸引越强、远星点被压低；K≤2 时仍应接近开普勒值
      const aTol = K <= 2 ? 0.25 : 0.45;
      const okAll = !plunged &&
        Math.abs(rmax - aTheo) / aTheo < aTol &&
        Math.abs(rmin - pTheo) / pTheo < 0.05 && o.periCount >= 2;
      ok('K=' + K + ' 轨道稳定且为进动椭圆 (r∈[' + rmin.toFixed(2) + ',' + rmax.toFixed(2) + '] ' +
         o.periCount + ' 圈, 解析 ' + pTheo.toFixed(2) + '/' + aTheo.toFixed(2) + ')', okAll);
    }
  }
  // 3b2 强场失效的回归测试：M/a ~ 0.3（井深直接当质量用）时轨道必定坠落，
  //     这正是必须把"井深质量"与"轨道质量"解耦的原因。
  {
    const o = new Ph.Orbit({ m: 0.85, K: 1, a: 1.87, e: 0.42, substeps: 12 });
    let plunged = false;
    for (let i = 0; i < 60 * 60; i++) { o.step(1 / 60); if (o.r <= 0.85 * 1.05) { plunged = true; break; } }
    ok('强场耦合 (M/a≈0.45) 确实会坠落 —— 记录该失效边界', plunged);
  }

  /* 3c 与 φ 空间 Binet 数值基准交叉验证 */
  /* 参考解：在 φ 空间积分 Binet 方程 d²u/dφ² + u = M/h² + 3Ku²（u = 1/r），
     直接量出相邻两次近日点之间的角度。它与主积分器完全独立（不同自变量、
     不同方程形式），因此是可靠的交叉验证。 */
  function binetApsidal(M, a, e, K) {
    const h2 = M * a * (1 - e * e), h = Math.sqrt(h2);
    let u = 1 / (a * (1 - e)), du = 0, phi = 0, prevDu = 0;
    const dphi = 2e-6;
    const angles = [];
    for (let i = 0; i < 40e6 && angles.length < 3; i++) {
      const f = (uu, dd) => M / h2 * 1 + 3 * K * M * uu * uu - uu;
      const k1u = du, k1d = f(u, du);
      const k2u = du + 0.5 * dphi * k1d, k2d = f(u + 0.5 * dphi * k1u, du + 0.5 * dphi * k1d);
      const k3u = du + 0.5 * dphi * k2d, k3d = f(u + 0.5 * dphi * k2u, du + 0.5 * dphi * k2d);
      const k4u = du + dphi * k3d, k4d = f(u + dphi * k3u, du + dphi * k3d);
      u += dphi / 6 * (k1u + 2 * k2u + 2 * k3u + k4u);
      du += dphi / 6 * (k1d + 2 * k2d + 2 * k3d + k4d);
      phi += dphi;
      if (prevDu < 0 && du >= 0 && phi > 1) angles.push(phi);
      prevDu = du;
    }
    return angles.length >= 2 ? angles[1] - angles[0] - 2 * Math.PI : NaN;
  }

  for (const [M, a, e, K] of [[0.02, 1.2, 0.6, 1], [0.05, 2.0, 0.4, 1], [0.02, 1.5, 0.5, 2], [0.01, 3.0, 0.05, 1]]) {
    const o = new Ph.Orbit({ m: M, K: K, a: a, e: e, substeps: 40 });
    const T = Ph.orbitalPeriod(M, a);
    for (let i = 0; i < 6000 * 3; i++) o.step(T / 6000);
    const measured = o.precession / Math.max(o.periCount, 1);
    const ref = binetApsidal(M, a, e, K);
    const rel = Math.abs(measured - ref) / Math.abs(ref);
    ok('M=' + M + ' a=' + a + ' e=' + e + ' K=' + K +
       '  积分 ' + (measured * 180 / Math.PI).toFixed(4) + '° vs Binet ' + (ref * 180 / Math.PI).toFixed(4) + '°',
       rel < 0.01, '(' + (rel * 100).toFixed(3) + '% 偏差)');
  }

  // 弱场下必须回归标准 1PN 公式
  const Mw = 1e-4, aw = 2, ew = 0.4;
  const std = Ph.perihelionPrecession(Mw, aw, ew);
  const refw = binetApsidal(Mw, aw, ew, 1);
  ok('弱场极限回归 6πM/(a(1-e²))：' + (refw / std).toFixed(5) + ' ×',
     Math.abs(refw / std - 1) < 1e-3);
  const ol = Ph.perihelionPrecessionLinear(Mw, aw, ew);
  ok('近圆线性化解同样回归标准公式', Math.abs(ol / std - 1) < 1e-3);

  // K=0 必须闭合：残差随步长按 1/n 收敛（纯角度量化误差，无物理进动）
  let prevRes = Infinity, shrink = true, resList = [];
  for (const n of [6000, 30000, 150000]) {
    const oz = new Ph.Orbit({ m: 0.02, K: 0, a: 1.2, e: 0.6, substeps: 40 });
    const Tz = Ph.orbitalPeriod(0.02, 1.2);
    // 多跑几步：第 2 次近日点正好落在两圈边界上，需要留出余量
    for (let i = 0; i < n * 2 + 4; i++) oz.step(Tz / n);
    const res = Math.abs(oz.precession);
    resList.push((res * 180 / Math.PI).toExponential(2));
    if (res > prevRes / 2.5) shrink = false;
    prevRes = res;
  }
  // 判据：远小于 1PN 进动（~10°~35°），且随步长稳定下降
  ok('K=0 时轨道闭合，残差随步长按 1/n 收敛 [' + resList.join(' → ') + ']°',
     prevRes < 0.05 * Math.PI / 180 && shrink);
  // 更严格的闭合性：7/8 圈后位置与理论椭圆之差
  {
    const oz = new Ph.Orbit({ m: 0.02, K: 0, a: 1.2, e: 0.6, substeps: 60 });
    const Tz = Ph.orbitalPeriod(0.02, 1.2);
    for (let i = 0; i < 60000 * 0.875; i++) oz.step(Tz / 60000);
    const p = 1.2 * (1 - 0.36);
    const rTheory = p / (1 + 0.6 * Math.cos(oz.swept));      // 牛顿椭圆
    ok('K=0 时轨道形状符合牛顿椭圆 (Δr/r = ' +
       (Math.abs(oz.r - rTheory) / rTheory).toExponential(2) + ')',
       Math.abs(oz.r - rTheory) / rTheory < 1e-4);
  }
  ok('K=0 时两圈内正确识别 2 次近日点',
     (function () {
       const oz = new Ph.Orbit({ m: 0.02, K: 0, a: 1.2, e: 0.6, substeps: 40 });
       const Tz = Ph.orbitalPeriod(0.02, 1.2);
       for (let i = 0; i < 6000 * 2 + 4; i++) oz.step(Tz / 6000);
       return oz.periCount === 2;
     })());
}

/* --------------------------------------------------------- 4 引力波衰减 */
console.log('\n[4] 四极辐射：分离度衰减 a(t) = a₀(1-t/T_m)^{1/4}');
{
  const M = 1.7, a0 = 4.0;
  const Tm = Ph.mergerTime(a0, M);
  ok('并合时标 T_m = 5a₀⁴/(256M³) = ' + Tm.toFixed(4), Tm > 0 && isFinite(Tm));
  // 与数值积分 da/dt = -(64/5)M³/a³ 比对
  let a = a0, t = 0, dt = Tm / 20000;
  for (let i = 0; i < 20000 * 0.5; i++) {          // 积分到 t = T_m/2
    a += -(64 / 5) * Math.pow(M, 3) / Math.pow(a, 3) * dt;
    t += dt;
  }
  const analytic = Ph.separationAt(1 - t / Tm, a0);
  ok('t=T_m/2 时数值 ' + a.toFixed(5) + ' vs 解析 ' + analytic.toFixed(5),
     close(a, analytic, 2e-3));
  ok('τ 与分离度互逆', close(Ph.tauFromSeparation(analytic, a0), 1 - t / Tm, 1e-9));
  // 波频随接近并合而升高
  const f1 = Ph.gwFrequency(2 * M, 4.0), f2 = Ph.gwFrequency(2 * M, 1.5), f3 = Ph.gwFrequency(2 * M, 0.8);
  ok('波频单调升高 (chirp): ' + f1.toFixed(3) + ' → ' + f2.toFixed(3) + ' → ' + f3.toFixed(3) + ' Hz',
     f1 < f2 && f2 < f3);
}

/* --------------------------------------------- 4b 啁啾相位与频率的解析式 */
console.log('\n[4b] 啁啾相位 Φ 与轨道频率的一致性（着色器用的正是这条式子）');
{
  /* 严格解（着色器与 main.js 用的是同一条式子）：
       d = d₀τ^{1/4},  dΦ/dt = 2Ω(d)  ⇒  Φ = k(τ^{5/8} - τ_end^{5/8}),  k = 8πΩ₀T_m
     于是 dΦ/dt = (5k/8T_m)τ^{-3/8} ∝ τ^{-3/8} —— 频率随时间升高（chirp），
     并合时 (τ=τ_end) 相位冻结在有限值。下面逐项核对。 */
  const Mo = 0.025, a0 = 2.55, aEnd = 1.70;
  const Tm = Ph.mergerTime(a0, Mo) * (1 - Math.pow(aEnd / a0, 4));
  const tauEnd = Math.pow(aEnd / a0, 4);
  const k = 8 * Math.PI * Ph.binaryOmega(2 * Mo, a0) * Tm;
  const Phi = t => {
    const tau = Math.min(Math.max(1 - t / Tm, tauEnd), 1);
    return k * (1 - Math.pow(tau, 0.625));
  };
  // 解析导数 dΦ/dt = (5k/8T_m)·τ^{-3/8}
  const dPhi = t => {
    const tau = Math.min(Math.max(1 - t / Tm, tauEnd), 1);
    return (5 * k / (8 * Tm)) * Math.pow(tau, -0.375);
  };  {
    /* ① 频率与 2Ω(d) 的比值。解析上（Ω(d)=√(M_tot/d³) 为分离度 d 处的角频率）
         ω = (5k/8T_m)τ^{-3/8},  Ω(d) = Ω₀τ^{-3/8},  k = 8πΩ₀T_m
         ⇒ ω/Ω(d) = 5π ≈ 15.708，即 ω/(2Ω) = 5π/2 ≈ 7.854
       这个比值与 d₀、M 都无关，且不随时间变化 —— 正是"四极辐射、ω ∝ τ^{-3/8}"
       的签名（τ 的幂次完全相同）。 */
    const ratios = [];
    // 采样限制在 τ ≥ τ_end 的建模区间内（τ_end 以下本模型不再演化）
    for (const f of [0, 0.2, 0.4, 0.6, 0.75]) {
      const dNow = Ph.separationAt(1 - f, a0);
      ratios.push(dPhi(f * Tm) / (2 * Math.sqrt(2 * Mo / Math.pow(dNow, 3))));
    }
    const theoRatio = 5 * Math.PI / 2;
    const spread = Math.max(...ratios) / Math.min(...ratios);
    ok('ω ÷ 2Ω(d) = ' + ratios[0].toFixed(4) + ' ≈ 5π/2 = ' + theoRatio.toFixed(4) +
       '（离散度 ' + spread.toFixed(6) + '，≈1 表示 τ 幂次完全一致）',
       Math.abs(ratios[0] / theoRatio - 1) < 0.02 && spread < 1.001);
    ok('频率随时间升高：ω ∝ τ^{-3/8} 在并合前放大 ×' +
       Math.pow(1 / tauEnd, 0.375).toFixed(2),
       dPhi(0.99 * Tm) / dPhi(0.01 * Tm) > 1.5);
    // ② 解析导数与数值微分一致（用相对步长，避免灾难性抵消）
    const h = Tm * 1e-6, t0 = 0.5 * Tm;
    const num = (Phi(t0 + h) - Phi(t0 - h)) / (2 * h);
    ok('解析导数与数值微分一致 (' + (num / dPhi(t0)).toFixed(6) + ')',
       Math.abs(num / dPhi(t0) - 1) < 1e-3);
    // ③ 单调递增且并合处有限
    const v1 = Phi(0.2 * Tm), v2 = Phi(0.5 * Tm), v3 = Phi(0.9 * Tm);
    ok('Φ 单调递增 (' + v1.toFixed(0) + ' < ' + v2.toFixed(0) + ' < ' + v3.toFixed(0) + ' rad)',
       v1 < v2 && v2 < v3);
    const phiEnd = Phi(Tm);
    ok('并合时相位冻结在有限值 ' + phiEnd.toFixed(0) + ' rad ≈ ' +
       (phiEnd / (2 * Math.PI)).toFixed(1) + ' 圈', isFinite(phiEnd) && phiEnd > 0);
    // ④ 圈数只取决于 d₀/d_end（真实双星同样如此）
    const disp = phiEnd / (2 * Math.PI);
    const theo = k * (1 - Math.pow(tauEnd, 0.625)) / (2 * Math.PI);
    ok('展示圈数 ' + disp.toFixed(1) + ' = 解析值 ' + theo.toFixed(1), Math.abs(disp - theo) < 1e-9);
  }
  ok('啁啾总圈数 ≈ k/2π = ' + (k / (2 * Math.PI)).toFixed(1) + ' 圈（应为 O(10~1000)）',
     k / (2 * Math.PI) > 5 && k / (2 * Math.PI) < 1e5);
}

/* --------------------------------------------------------- 5 基本关系 */
console.log('\n[5] 史瓦西时空基本关系');
{
  const rsSun = Ph.rsFromMass(Ph.M_SUN);
  ok('太阳史瓦西半径 ≈ 2.95 km (' + (rsSun / 1000).toFixed(3) + ' km)', Math.abs(rsSun / 1000 - 2.953) < 0.02);
  const m = Ph.massFromRs(rsSun);
  ok('massFromRs / rsFromMass 互逆', close(m, Ph.M_SUN, 1e-9));
  ok('r = rₛ 时 dτ/dt = 0', Ph.timeDilation(1, 1) === 0);
  ok('r = 2rₛ 时 dτ/dt = √0.5', close(Ph.timeDilation(1, 2), Math.SQRT1_2, 1e-12));
  ok('远处 dτ/dt → 1', close(Ph.timeDilation(1, 1e9), 1, 1e-8));
  ok('自由落体时间 t = π/2·√(r₀³/2M)', close(Ph.freeFallTime(0.5, 3), Math.PI / 2 * Math.sqrt(27 / 1), 1e-12));
  ok('并合余核 < 总质量', Ph.remnantMass(2) < 2);
}

console.log('\n' + '='.repeat(46));
console.log((fail === 0 ? '全部通过' : '存在失败') + '：' + pass + ' passed, ' + fail + ' failed\n');
process.exit(fail === 0 ? 0 : 1);
