/* ============================================================================
 * 真实浏览器验收：CDP (Chrome DevTools Protocol) 直连
 *   node tests/probe.mjs
 *
 * 相比 --virtual-time-budget + --dump-dom，CDP 的好处：
 *   - 可以真正等待 N 秒（rAF 动画页面上虚拟时间会卡住）
 *   - 可以随时 Runtime.evaluate 读取页面状态、注入探针
 *   - 可以拿到逐帧截图，判断画面是否真的画出来了
 * 只用 Node 内置能力（WebSocket / fetch），无需 puppeteer。
 * ========================================================================== */
import http from 'node:http';
import { readFileSync, existsSync, mkdirSync, writeFileSync, statSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { resolve, dirname, extname, basename } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dir = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dir, '..');
const shots = resolve(root, 'shots');
mkdirSync(shots, { recursive: true });

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
               '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.json': 'application/json' };

const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ------------------------------------------------------------ 静态服务 */
const server = http.createServer((req, res) => {
  try {
    let p = decodeURIComponent(req.url.split('?')[0]);
    if (p === '/') p = '/index.html';
    const file = resolve(root, p.slice(1));
    if (!file.startsWith(root) || !existsSync(file) || !statSync(file).isFile()) {
      res.writeHead(404); return res.end('404 ' + p);
    }
    res.writeHead(200, { 'Content-Type': MIME[extname(file)] || 'application/octet-stream',
                         'Cache-Control': 'no-store' });
    res.end(readFileSync(file));
  } catch (e) { res.writeHead(500); res.end('500 ' + e.message); }
});
await new Promise(r => server.listen(0, '127.0.0.1', r));
const PORT = server.address().port;
const BASE = 'http://127.0.0.1:' + PORT;
console.log('静态服务 :', BASE);

/* ------------------------------------------------------- 启动浏览器 */
const CANDIDATES = [
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
  (process.env.LOCALAPPDATA || '') + '/Google/Chrome/Application/chrome.exe'
];
const exe = CANDIDATES.find(p => p && existsSync(p));
if (!exe) { console.error('找不到 Edge/Chrome'); process.exit(2); }

const CDP_PORT = 9333 + (process.pid % 200);
const profile = resolve(root, '.chrome-cdp');
const args = [
  '--headless=new', '--no-sandbox', '--disable-gpu-sandbox',
  '--enable-unsafe-swiftshader', '--use-gl=angle', '--use-angle=swiftshader',
  '--hide-scrollbars', '--force-device-scale-factor=1',
  '--window-size=1600,900', '--user-data-dir=' + profile,
  '--remote-debugging-port=' + CDP_PORT,
  '--no-first-run', '--no-default-browser-check', '--disable-extensions',
  'about:blank'
];
console.log('浏览器   :', basename(exe), '\n');
const proc = spawn(exe, args, { stdio: 'ignore', windowsHide: true });

/* ------------------------------------------------------------ CDP 客户端 */
let wsUrl = null;
for (let i = 0; i < 60 && !wsUrl; i++) {
  await sleep(300);
  try {
    const r = await fetch('http://127.0.0.1:' + CDP_PORT + '/json/version');
    if (r.ok) wsUrl = (await r.json()).webSocketDebuggerUrl;
  } catch { /* 还没起来 */ }
}
if (!wsUrl) { console.error('CDP 端口未就绪'); proc.kill(); server.close(); process.exit(2); }

const ws = new WebSocket(wsUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = e => rej(new Error('ws error')); });

let msgId = 0;
const pending = new Map();
const events = [];
ws.onmessage = ev => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) {
    const { res, rej } = pending.get(m.id);
    pending.delete(m.id);
    m.error ? rej(new Error(JSON.stringify(m.error))) : res(m.result);
  } else if (m.method) events.push(m);
};
function cdp(method, params = {}, sessionId) {
  return new Promise((res, rej) => {
    const id = ++msgId;
    pending.set(id, { res, rej });
    ws.send(JSON.stringify({ id, method, params, sessionId }));
    setTimeout(() => { if (pending.has(id)) { pending.delete(id); rej(new Error('CDP 超时 ' + method)); } }, 60000);
  });
}

/* 打开一个页面并 attach */
const { targetId } = await cdp('Target.createTarget', { url: 'about:blank' });
const { sessionId } = await cdp('Target.attachToTarget', { targetId, flatten: true });
const S = (m, p) => cdp(m, p, sessionId);

const consoleMsgs = [];
ws.addEventListener('message', ev => {
  const m = JSON.parse(ev.data);
  if (m.method === 'Runtime.consoleAPICalled' && m.sessionId === sessionId) {
    consoleMsgs.push(m.params.type + ': ' + m.params.args.map(a => a.value ?? a.description ?? a.type).join(' '));
  }
  if (m.method === 'Runtime.exceptionThrown' && m.sessionId === sessionId) {
    const d = m.params.exceptionDetails;
    consoleMsgs.push('EXCEPTION: ' + (d.exception?.description || d.text));
  }
  if (m.method === 'Log.entryAdded' && m.sessionId === sessionId) {
    const e = m.params.entry;
    if (e.level === 'error' || e.level === 'warning') consoleMsgs.push('LOG[' + e.level + ']: ' + e.text);
  }
});

await S('Runtime.enable');
await S('Log.enable');
await S('Page.enable');

/* 先注入探针（每次新文档都重新注入），再导航 */
const shim = readFileSync(resolve(__dir, 'shim.js'), 'utf8');
await S('Page.addScriptToEvaluateOnNewDocument', { source: shim });

const evalJs = async (expr, awaitPromise = false) => {
  const r = await S('Runtime.evaluate', { expression: expr, returnByValue: true,
                                          awaitPromise, userGesture: true });
  if (r.exceptionDetails) return { __error: r.exceptionDetails.exception?.description || r.exceptionDetails.text };
  return r.result.value;
};

const steps = [];
async function step(label, fn) {
  const t0 = Date.now();
  let out;
  try { out = await fn(); } catch (e) { out = { __error: e.message }; }
  steps.push({ label, ms: Date.now() - t0, out });
  console.log('· ' + label + '  (' + (Date.now() - t0) + 'ms)' +
    (out === undefined ? '' : '  → ' + (typeof out === 'object' ? JSON.stringify(out).slice(0, 220) : String(out).slice(0, 220))));
  return out;
}

const frames = [];
async function shoot(name) {
  const r = await S('Page.captureScreenshot', { format: 'png' });
  const buf = Buffer.from(r.data, 'base64');
  writeFileSync(resolve(shots, name + '.png'), buf);
  // 顺带统计像素：均值 / 非背景占比 / 最大值
  const stat = await evalJs(`(() => {
    const c = document.createElement('canvas'); c.width = 160; c.height = 90;
    const g = c.getContext('2d');
    const src = document.getElementById('gl');
    g.drawImage(src, 0, 0, 160, 90);
    const d = g.getImageData(0, 0, 160, 90).data;
    let s = 0, lit = 0, mx = 0;
    for (let i = 0; i < d.length; i += 4) {
      const v = (d[i] + d[i+1] + d[i+2]) / 3;
      s += v; if (v > 28) lit++; if (v > mx) mx = v;
    }
    const n = d.length / 4;
    return { mean: +(s/n).toFixed(2), litPct: +(lit/n*100).toFixed(1), max: mx };
  })()`);
  frames.push({ name, bytes: buf.length, ...(stat && !stat.__error ? stat : { statError: stat.__error }) });
  return frames[frames.length - 1];
}

try {
  await step('导航到 index.html', async () => {
    await S('Page.navigate', { url: BASE + '/index.html' });
    await sleep(2500);
    return await evalJs('document.title');
  });

  await step('探针是否就位', async () =>
    evalJs('JSON.stringify({probe: !!window.__PROBE__, raf: window.__PROBE__ && window.__PROBE__.rafCount, draws: window.__PROBE__ && window.__PROBE__.drawCalls})'));

  await step('等待 3.5s 累积动画帧', async () => { await sleep(3500); return await evalJs('window.__PROBE__.rafCount + " rAF / " + window.__PROBE__.drawCalls + " render"'); });

  const gl = await step('WebGL / 渲染器信息', async () =>
    evalJs('JSON.stringify(window.__PROBE__.glInfo) + " | firstDraw=" + JSON.stringify(window.__PROBE__.afterFirstDraw)'));
  await step('着色器程序链接自检', async () => evalJs('JSON.stringify(window.__PROBE__.programs ? window.__PROBE__.programs.filter(p=>p.diag) : "n/a")'));
  await step('控制台/异常巡检', async () =>
    evalJs('JSON.stringify((window.__ERRORS__||[]).concat(window.__CONSOLE__||[]))'));

  await shoot('01-single');

  const single = await step('模式① 单星测地线：状态快照', async () =>
    evalJs('JSON.stringify(window.__PROBE__.probeSnapshot || (window.__PROBE__.probeSnapshot = null)) + "|" + JSON.stringify(window.STApp && {mode: STApp.ST.mode, r: +STApp.ST.orbit.r.toFixed(3), peri: STApp.ST.orbit.periCount, prec: +(STApp.ST.orbit.precession*180/Math.PI).toFixed(2)})'));

  await step('运行 12s 观察进动累积', async () => { await sleep(12000); return await evalJs('JSON.stringify({simTime:+STApp.ST.simTime.toFixed(2), r:+STApp.ST.orbit.r.toFixed(3), peri:STApp.ST.orbit.periCount, precDeg:+(STApp.ST.orbit.precession*180/Math.PI).toFixed(2), fps:+STApp.ST.fps.toFixed(1)})'); });
  await step('HUD 读数', async () => evalJs('window.__DOMCHECK__()'));
  await shoot('02-single-later');

  await step('切到模式② 双黑洞并合', async () => { await evalJs('window.__SETMODE__("binary")'); await sleep(9000); return await evalJs('JSON.stringify({d:+STApp.ST.bin.d.toFixed(3), tau:+STApp.ST.bin.tau.toFixed(4), merged:STApp.ST.bin.merged, warped:+STApp.ST.warpedTime.toFixed(2), U:+STApp.ST.U.toFixed(6)})'); });
  await shoot('03-binary');
  await step('再等 12s（接近并合）', async () => { await sleep(12000); return await evalJs('JSON.stringify({d:+STApp.ST.bin.d.toFixed(3), tau:+STApp.ST.bin.tau.toFixed(4), merged:STApp.ST.bin.merged, warped:+STApp.ST.warpedTime.toFixed(2)})'); });
  await shoot('04-binary-late');

  await step('切到模式③ 并投掷粒子', async () => {
    await evalJs('window.__SETMODE__("interact")');
    await sleep(600);
    return await evalJs('(()=>{ const r=[]; const W=innerWidth,H=innerHeight; [[0.62,0.55],[0.35,0.62],[0.75,0.42]].forEach(([a,b])=>{ STApp.spawnFromClick(W*a,H*b); r.push(STApp.ST.parts.length); }); return JSON.stringify({spawned:r, bound: STApp.ST.parts.map(p=>p.bound)}); })()');
  });
  await step('粒子演化 8s', async () => { await sleep(8000); return await evalJs('JSON.stringify({n:STApp.ST.parts.length, r:STApp.ST.parts.map(p=>+p.o.r.toFixed(2))})'); });
  await shoot('05-interact');

  await step('切回模式②并强制收尾并合', async () => {
    await evalJs('window.__SETMODE__("binary")');
    await evalJs('STApp.ST.bin.tau = 0.02');
    await sleep(2500);
    return await evalJs('JSON.stringify({merged:STApp.ST.bin.merged, d:+STApp.ST.bin.d.toFixed(3)})');
  });
  await shoot('06-merged');

  await step('窗口缩放响应', async () => {
    await S('Emulation.setDeviceMetricsOverride', { width: 900, height: 620, deviceScaleFactor: 1, mobile: false });
    await sleep(1200);
    return await evalJs('JSON.stringify(window.__PROBE__.canvasSize) + " | " + (document.getElementById("gl").width + "x" + document.getElementById("gl").height)');
  });
  await shoot('07-small');
  await S('Emulation.clearDeviceMetricsOverride');

  await step('最终错误巡检', async () => evalJs('JSON.stringify((window.__ERRORS__||[]).slice(0,10))'));
} catch (e) {
  console.log('\n!! 探针流程异常：' + e.message);
}

const report = {
  url: BASE + '/index.html',
  frames, steps,
  console: consoleMsgs.slice(0, 80),
  errors: steps.map(s => s.out).filter(o => o && o.__error).length
};
writeFileSync(resolve(shots, 'probe-report.json'), JSON.stringify(report, null, 1), 'utf8');

/* --------------------------------------------------------------- 报告 */
console.log('\n================ 渲染验收 ================');
console.log('截图样本（mean=平均亮度, lit=非背景像素占比, max=最亮值）:');
frames.forEach(f => console.log('  ' + (f.name + '          ').slice(0, 18) +
  (f.bytes ? (f.bytes / 1024).toFixed(0) + ' KB' : 'FAIL') +
  (f.mean != null ? '   mean=' + f.mean + '  lit=' + f.litPct + '%  max=' + f.max : '')));
console.log('\n浏览器控制台:', consoleMsgs.length ? '' : '（无消息）');
consoleMsgs.slice(0, 25).forEach(m => console.log('  ' + m.slice(0, 220)));
const bad = steps.filter(s => s.out && (s.out.__error || /EXCEPTION|Uncaught/.test(String(s.out))));
console.log('\n报错步骤:', bad.length ? bad.map(b => b.label + ' → ' + JSON.stringify(b.out).slice(0, 200)).join('\n  ') : '无');
console.log('\n报告 JSON:', resolve(shots, 'probe-report.json'));
console.log('==========================================\n');

try { ws.close(); } catch {}
proc.kill();
server.close();
await sleep(300);
process.exit(0);
