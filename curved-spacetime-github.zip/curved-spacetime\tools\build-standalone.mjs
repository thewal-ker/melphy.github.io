/* ============================================================================
 * 构建单文件离线版
 *   node tools/build-standalone.mjs
 * 把 css / vendor / js 全部内联进一个 HTML，双击即可打开（无需服务器、无需联网）。
 * 输出：curved-spacetime.html（项目根目录）
 * ========================================================================== */
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dir = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dir, '..');
const R = p => resolve(root, p);
const read = p => {
  if (!existsSync(R(p))) throw new Error('缺少文件：' + p);
  return readFileSync(R(p), 'utf8');
};

/* 内联 <script> 时必须切断 "</script" 序列，否则 HTML 解析器会提前结束脚本 */
const safeJs = s => s.replace(/<\/script/gi, '<\\/script');

let html = read('index.html');

// 1) 样式
html = html.replace(/<link rel="stylesheet" href="([^"]+)">/g,
  (_, href) => '<style>\n' + read(href).trim() + '\n</style>');

// 2) 脚本
html = html.replace(/<script src="([^"]+)"><\/script>/g,
  (_, src) => '<script>\n/* ==== ' + src + ' ==== */\n' + safeJs(read(src).trim()) + '\n</script>');

if (/<script src=|<link rel="stylesheet"/.test(html)) {
  throw new Error('仍有未内联的外部资源，请检查 index.html');
}

// 3) 顶部加一条说明注释
const banner = `<!--
  弯曲时空 3D 模型 · Curved Spacetime  (单文件离线版，由 tools/build-standalone.mjs 生成)
  ----------------------------------------------------------------------------------
  本文件内联了 three.js r128 (MIT) 与全部源码，双击即可在浏览器中打开，无需联网。
  源码版见同目录 index.html + js/ + css/；物理内核的验证见 tests/physics.test.js。
-->
`;
html = html.replace('<!DOCTYPE html>', '<!DOCTYPE html>\n' + banner);

const out = R('curved-spacetime.html');
writeFileSync(out, html, 'utf8');
const kb = (Buffer.byteLength(html, 'utf8') / 1024).toFixed(0);
console.log('已生成单文件版：' + out + '  (' + kb + ' KB)');
console.log('校验：外部引用残留 = ' + (/<script src=|<link rel="stylesheet"/.test(html) ? '有' : '无'));
